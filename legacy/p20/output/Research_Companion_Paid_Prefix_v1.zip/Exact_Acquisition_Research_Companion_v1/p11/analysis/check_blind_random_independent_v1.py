#!/usr/bin/env python3
"""Independent stdlib replay primitives; producer modules are never imported."""
from fractions import Fraction as Q
from decimal import Decimal
from pathlib import Path
from collections import defaultdict,Counter
import hashlib,json,itertools,time
BASE=Path('p11/analysis');DATA=Path('p9/licence/apex_dataset')
EXPECTED_RAW={'Crystal':'bc2c652f89a70d0723aec19cae1f2dba6d2b56523d5c0b54805520a8de072711','RPL':'c987d6583288e157139f8d6b0253c2adb91abee7642eee28fcf99db311f8f746'}
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def dominates(q,p):return all(x<=y for x,y in zip(q,p)) and any(x<y for x,y in zip(q,p))
def supporting(p,qs):
    ds=[tuple(x-y for x,y in zip(q,p)) for q in qs];roots={Q(0),Q(1)}
    for x,y in ds:
        if x!=y:
            w=y/(y-x)
            if 0<=w<=1:roots.add(w)
    valid=[w for w in roots if all(w*x+(1-w)*y>=0 for x,y in ds)]
    return (min(valid),max(valid)) if valid else None

def load_archive(protocol,names):
    path=DATA/(protocol+'_results.json');assert sha(path)==EXPECTED_RAW[protocol]
    raw=json.loads(path.read_text(),parse_float=Decimal);grouped=defaultdict(list)
    for row in raw:grouped[tuple(sorted(row['params'].items()))].append(row)
    rows=[];ids=[]
    for key in sorted(grouped):
        group=sorted(grouped[key],key=lambda r:r['id']);assert len(group)==6
        ids.append([r['id'] for r in group])
        rows.append([tuple(1-Q(r['metrics']['reliability']) if n=='failure' else Q(r['metrics'][n]) for n in names) for r in group])
    assert len(rows)==(16 if protocol=='Crystal' else 36)
    assert len({v for group in ids for v in group})==6*len(rows)
    assert all(q[0]>=0 and 0<=q[1]<=1 for group in rows for q in group)
    return rows,ids

class State:
    def __init__(self,rows,target,rotation=0,ids=None):
        self.rows=rows;self.target=target;self.N=len(rows[0]);self.K=len(rows);self.rotation=rotation;self.ids=ids
        assert all(len(g)==self.N for g in rows)
        self.ns=[0]*self.K;self.sums=[[Q(0),Q(0)] for _ in rows];self.events=[]
    def lower(self,i):return tuple(x/self.N for x in self.sums[i])
    def reveal(self,i,reason):
        j=(self.ns[i]+self.rotation)%self.N;assert self.ns[i]<self.N
        q=self.rows[i][j];assert q[0]>=0 and 0<=q[1]<=1
        self.ns[i]+=1
        for d in range(2):self.sums[i][d]+=q[d]
        e={'configuration':i,'values':[str(x) for x in q],'reason':reason}
        if self.ids is not None:e['trial_id']=self.ids[i][j]
        self.events.append(e)
    def finish(self,i,reason):
        while self.ns[i]<self.N:self.reveal(i,reason)
    def complete_points(self):return [self.lower(i) for i in range(self.K) if i!=self.target and self.ns[i]==self.N]
    def p4(self):return supporting(self.lower(self.target),self.complete_points()) is None
    def H(self):
        self.finish(self.target,'candidate')
        p=self.lower(self.target)
        for i in range(self.K):
            if i==self.target:continue
            while self.ns[i]<self.N and dominates(self.lower(i),p):self.reveal(i,'P2')
            if dominates(self.lower(i),p):return False
        return True
    def pair_sets(self):
        p=self.lower(self.target);means=[tuple(sum(q[d] for q in g)/self.N for d in range(2)) for g in self.rows]
        pairs=[]
        for i in range(self.K):
            if i==self.target:continue
            for j in range(i+1,self.K):
                if j==self.target:continue
                if supporting(p,[means[i],means[j]]) is None:pairs.append((i,j))
        return pairs

def positive_H_audit():
    output=[]
    for protocol,names,target in [('Crystal',('energy','failure'),11),('Crystal',('latency','failure'),11),('RPL',('latency','failure'),21)]:
        rows,ids=load_archive(protocol,names)
        for rotation in range(6):
            s=State(rows,target,rotation,ids);assert s.H();H=len(s.events)
            residual=[s.N-n for n in s.ns];pairs=s.pair_sets()
            sets={tuple(i for i in pair if residual[i]) for pair in pairs}
            if () in sets:expected=Q(H);needed=[]
            else:
                assert len(sets)==1 and len(next(iter(sets)))==1
                needed=list(next(iter(sets)));i=needed[0]
                expected=Q(H)+residual[i]+sum((Q(residual[j]) for j in range(s.K) if j!=i),Q(0))/2
            output.append({'protocol':protocol,'objectives':list(names),'target':target,'rotation':rotation,'H':H,'counts_at_H':s.ns,'actual_witness_pairs':[list(p) for p in pairs],'needed_residual':needed,'R0_expectation':str(expected),'H_already_P4':s.p4()})
    return output
def finish_policy(state,policy,orderer):
    """Independent execution using only current sums and eligible labels."""
    state.finish(state.target,'candidate');p=state.lower(state.target)
    audit={'screening':None,'branch':None}
    if 0 in p:
        audit['reason']='PURE_AXIS_ZERO';return False,audit
    if not state.H():
        audit['reason']='CENSUSED_DOMINATOR';return False,audit
    H=len(state.events);counts=state.ns[:]
    nw=[i for i in range(state.K) if i!=state.target and state.lower(i)[0]<p[0] and state.lower(i)[1]>p[1]]
    se=[i for i in range(state.K) if i!=state.target and state.lower(i)[0]>p[0] and state.lower(i)[1]<p[1]]
    irrelevant=[i for i in range(state.K) if i!=state.target and i not in nw+se]
    sides={'NW':nw,'SE':se,'irrelevant':irrelevant}
    audit.update(H=H,counts_at_H=counts,NW=nw,SE=se)
    audit['screening']={'cost':H,'counts':counts,'lower':[[str(x) for x in state.lower(i)] for i in range(state.K)]}
    if state.p4():audit['reason']='P2_AND_STRICT_PAIR';return True,audit
    branch={'mode':'GENERAL','sides':sides,'singleton':None};audit['branch']=branch
    if policy=='R1' and (len(nw)==1 or len(se)==1):
        singleton,opposite=(nw[0],se) if len(nw)==1 else (se[0],nw)
        branch.update(mode='SINGLETON',singleton=singleton)
        state.finish(singleton,'singleton')
        if state.p4():audit['reason']='P2_AND_STRICT_PAIR';return True,audit
        eligible=[i for i in opposite if state.ns[i]<state.N]
    else:eligible=[i for i in range(state.K) if state.ns[i]<state.N]
    branch['eligible']=eligible[:]
    ordered=orderer(eligible)
    assert sorted(ordered)==sorted(eligible)
    for i in ordered:
        state.finish(i,'permutation')
        if state.p4():audit['reason']='P2_AND_STRICT_PAIR';return True,audit
    for i in range(state.K):state.finish(i,'fallback')
    assert not state.p4();audit['reason']='FULL_CENSUS_SUPPORTED'
    return False,audit

def hard_family_audit():
    fixturepath=Path('p11/theory/positive_competitive_fixtures_v1.json')
    fixtures=json.loads(fixturepath.read_text());report=[]
    for K,N in fixtures['parameters']:
        m=K-2;b=Q(1,2*N)
        rows=[[(Q(1),b)]*N,
              [(Q(3*N,2),Q(0))]+[(Q(0),Q(0))]*(N-1)]
        for i in range(m):
            final=(Q(0),Q(0)) if i==0 else (Q(3*N),Q(0))
            rows.append([(Q(0),Q(1))]+[(Q(0),Q(0))]*(N-2)+[final])
        H=N+K-1;D=K+3*N-3;T=K*N
        summaries={}
        for policy in ['R0','R1']:
            sums=0;trials=0
            # Enumerate all actual eligible orders: this is exact, not MC.
            prototype=State(rows,0);assert prototype.H()
            if policy=='R0':eligible=[i for i in range(K) if prototype.ns[i]<N]
            else:eligible=[1] if m==1 else list(range(2,K))
            for perm in itertools.permutations(eligible):
                state=State(rows,0)
                answer,meta=finish_policy(state,policy,lambda allowed,perm=perm:[i for i in perm if i in allowed])
                assert answer and meta['H']==H
                sums+=len(state.events);trials+=1
            expect=Q(sums,trials)
            required=Q(D)+Q(2,3)*(T-D) if policy=='R0' else Q(T+D,2)
            assert expect==required
            summaries[policy]={'exact_expectation':str(expect),'enumerated_permutations':trials}
        report.append({'K':K,'N':N,'H':H,'Cstar':D,'T':T,**summaries})
    return report

def build_case(case,controls):
    if case['kind']=='NATIVE_CONTROL':
        c=controls[case['name']];assert c['target']==case['target']
        rows=[[tuple(map(Q,p)) for p in group] for group in c['rows']]
        ids=[[str(i)+':'+str(j) for j in range(len(g))] for i,g in enumerate(rows)]
        return rows,ids,0
    rows,ids=load_archive(case['protocol'],case['objectives'])
    return rows,ids,case['rotation']

def full_truth(rows,target):
    N=len(rows[0]);points=[tuple(sum(q[d] for q in g)/N for d in range(2)) for g in rows]
    return not any(dominates(q,points[target]) for i,q in enumerate(points) if i!=target) and supporting(points[target],[q for i,q in enumerate(points) if i!=target]) is None

def control_order(control,K,target,eligible):
    full=[i for i in range(K) if i!=target]
    if control=='DESC':full.reverse()
    elif control=='ROT1':full=full[1:]+full[:1]
    else:assert control=='ASC'
    return [i for i in full if i in eligible]

def check_certificate(run,state):
    p=state.lower(state.target);cert=run['certificate'];reason=run['reason']
    if reason=='PURE_AXIS_ZERO':
        assert cert=={'axis':0 if p[0]==0 else 1} and p[cert['axis']]==0
    elif reason=='CENSUSED_DOMINATOR':
        assert set(cert)=={'index'};i=cert['index'];assert i!=state.target and state.ns[i]==state.N and dominates(state.lower(i),p)
    elif reason=='P2_AND_STRICT_PAIR':
        assert all(not dominates(state.lower(i),p) for i in range(state.K) if i!=state.target)
        assert set(cert)=={'indices','weights','gaps'}
        pair=cert['indices'];weights=list(map(Q,cert['weights']));assert len(pair)==len(set(pair))==2
        assert len(weights)==2 and min(weights)>0 and sum(weights)==1
        assert all(i!=state.target and state.ns[i]==state.N for i in pair)
        gap=tuple(sum(w*(state.lower(i)[d]-p[d]) for w,i in zip(weights,pair)) for d in range(2))
        assert all(x<0 for x in gap) and list(gap)==list(map(Q,cert['gaps']))
        assert supporting(p,[state.lower(i) for i in pair]) is None
    else:
        assert reason=='FULL_CENSUS_SUPPORTED' and cert is None and all(n==state.N for n in state.ns)
        assert supporting(p,state.complete_points()) is not None

def exact_expectation(case,method):
    rows,ids=load_archive(case['protocol'],case['objectives']);target=case['target'];s=State(rows,target,case['rotation'],ids)
    assert s.H();H=len(s.events);h=s.ns[:];pairs=s.pair_sets();assert pairs
    p=s.lower(target);indices=[i for i in range(s.K) if i!=target]
    nw=[i for i in indices if s.lower(i)[0]<p[0] and s.lower(i)[1]>p[1]]
    se=[i for i in indices if s.lower(i)[0]>p[0] and s.lower(i)[1]<p[1]]
    sides={'NW':nw,'SE':se,'irrelevant':[i for i in indices if i not in nw+se]}
    fixed={i for i in indices if h[i]==s.N};eligible=[i for i in indices if i not in fixed];B=H;singleton=None
    if not any(set(pair)<=fixed for pair in pairs) and method=='R1' and (len(nw)==1 or len(se)==1):
        singleton,opposite=(nw[0],se) if len(nw)==1 else (se[0],nw)
        B+=s.N-h[singleton];fixed.add(singleton);eligible=[i for i in opposite if i not in fixed]
    needed={tuple(i for i in pair if i not in fixed) for pair in pairs}
    if () in needed:expected=Q(B);required=[];form='ALREADY_CERTIFIED'
    else:
        assert len(needed)==1 and len(next(iter(needed)))==1
        required=list(next(iter(needed)));j=required[0];assert j in eligible
        expected=Q(B+s.N-h[j])+sum((Q(s.N-h[i]) for i in eligible if i!=j),Q(0))/2
        form='ONE_REQUIRED_GROUP_RELATIVE_ORDER_HALF'
    Cstar=H+min(sum(s.N-h[i] for i in pair) for pair in pairs)
    assert Cstar<=expected<=Cstar+Q(2,3)*(s.K*s.N-Cstar)
    return dict(H=H,h=h,sides=sides,fixed_singleton=singleton,eligible=eligible,valid_pairs=[list(p) for p in pairs],
      required_residual=required,form=form,C_star=Cstar,expected_rows=str(expected),ratio_to_C_star=str(expected/Cstar))

def main():
    start=time.monotonic();freeze=json.loads((BASE/'FREEZE_blind_random_v1.json').read_text());before={p:sha(p) for p in freeze['sha256']}
    assert before==freeze['sha256']
    source=json.loads((BASE/'blind_random_results_v1.json').read_text());assert source['freeze']==freeze
    transcriptpath=BASE/'blind_random_runs_v1.jsonl';assert sha(transcriptpath)==source['transcripts_sha256']
    native=json.loads((BASE/'synthetic_controls_v1.json').read_text());controls={c['name']:c for c in native['controls']}
    cases={r['case_id']:r for r in source['cases']};assert len(cases)==30
    counts=Counter();seen=set();run_summaries=[];costs=defaultdict(dict)
    stages={'candidate':'CANDIDATE','P2':'SCREEN','singleton':'SINGLETON','permutation':'PERMUTATION','fallback':'FALLBACK'}
    for line in transcriptpath.open():
        run=json.loads(line);cid=run['case_id'];case=run['case'];assert case==cases[cid]['case']
        rows,ids,rotation=build_case(case,controls);target=case['target'];state=State(rows,target,rotation,ids)
        assert run['K']==state.K and run['N']==state.N
        truth=full_truth(rows,target);assert run['truth'] is truth and cases[cid]['truth'] is truth
        method=run['method'];control=run['control'];assert method in ['R0','R1'] and control in ['ASC','DESC','ROT1']
        key=(cid,method,control);assert key not in seen;seen.add(key)
        answer,audit=finish_policy(state,method,lambda elig:control_order(control,state.K,target,elig))
        assert run['answer'] is answer is truth and run['reason']==audit['reason']
        assert run['screening']==audit['screening'] and run['branch']==audit['branch']
        assert run['counts']==state.ns and run['rows_revealed']==len(state.events)==len(run['transcript'])
        for own,event in zip(state.events,run['transcript']):
            expected={'configuration':own['configuration'],'trial_id':own['trial_id'],'values':own['values'],'stage':stages[own['reason']]}
            assert event==expected,(key,event,expected)
        check_certificate(run,state)
        counts['runs']+=1;counts['events']+=len(state.events);counts['true_runs' if truth else 'false_runs']+=1
        counts[run['reason']]+=1
        costs[cid].setdefault(method,[]).append((control,len(state.events)))
        run_summaries.append({'case_id':cid,'method':method,'control':control,'rows':len(state.events),'answer':answer,'reason':run['reason']})
    assert len(seen)==180 and counts['events']==source['prefix_events']==10569
    for cid in cases:
        for method in ['R0','R1']:
            found=dict(costs[cid][method]);assert [found[c] for c in ['ASC','DESC','ROT1']]==cases[cid]['control_costs'][method]
    p10=json.loads(Path('p10/analysis/all_candidates_results_v1.json').read_text())
    aggregate={m:{'cases':0,'expected_total':Q(0),'S_total':0,'U_total':0,'C_star_total':0,'vs_S':Counter()} for m in ['R0','R1']}
    expected_summaries=[];seen_expectations=set()
    for record in source['expectations']:
        cid=record['case_id'];case=cases[cid]['case'];method=record['method'];assert case['kind']=='APEX_POSITIVE'
        assert (cid,method) not in seen_expectations;seen_expectations.add((cid,method))
        expected=exact_expectation(case,method)
        for field,value in expected.items():assert record[field]==value,(cid,method,field,record[field],value)
        old=next(r for r in p10['cases'] if all(r[k]==case[k] for k in ['protocol','objectives','target']))
        oracle=next(r for r in p10['positive_certificate_oracles'] if all(r[k]==case[k] for k in ['protocol','objectives','target','rotation']))
        rot=case['rotation'];S=old['rows']['S'][rot];U=old['rows']['U'][rot]
        assert record['S']==S and record['U']==U and record['C_star']==oracle['C_star']
        a=aggregate[method];a['cases']+=1;a['expected_total']+=Q(expected['expected_rows']);a['S_total']+=S;a['U_total']+=U;a['C_star_total']+=expected['C_star']
        a['vs_S']['fewer' if Q(expected['expected_rows'])<S else 'more' if Q(expected['expected_rows'])>S else 'equal']+=1
        expected_summaries.append({'case_id':cid,'method':method,**expected,'S':S,'U':U})
    assert len(seen_expectations)==36
    for method,a in aggregate.items():
        a['expected_excess_over_S']=str(a['expected_total']-a['S_total']);a['expected_fractional_increase_over_S']=str((a['expected_total']-a['S_total'])/a['S_total']);a['expected_total']=str(a['expected_total']);a['vs_S']={k:a['vs_S'][k] for k in ['fewer','equal','more']}
        assert a==source['aggregate'][method],(a,source['aggregate'][method])
    fixtures=hard_family_audit()
    assert {p:sha(p) for p in before}==before
    report={'status':'PASS_INDEPENDENT_180_RUNS_10569_EVENTS_36_EXACT_EXPECTATIONS',
       'counts':dict(counts),'source_frozen_hashes_unchanged':True,'aggregate':aggregate,'cases':len(cases),
       'all_run_summaries':run_summaries,'all_exact_expectations':expected_summaries,'own_enumerated_hard_family_checks':fixtures,
       'mismatches':0,'input_and_source_sha256':{**before,str(transcriptpath):sha(transcriptpath),str(BASE/'blind_random_results_v1.json'):sha(BASE/'blind_random_results_v1.json'),__file__:sha(__file__)},
       'elapsed_seconds':time.monotonic()-start,'scope':[
       'All 180 transcripts and 10569 events independently recreated from raw archive numerals or own-native fixed fixtures. No producer module imported.',
       'Exact support check uses axes and all affine equality roots; Pareto equality is nondomination. Every positive mixture directly checked strictly negative in both coordinates.',
       'All 36 expectations are exact combinatorial integration for 18 already-known positive cases, not sample means of ASC/DESC/ROT1 controls.',
       'These are development cases, not held-out or independent physical trials. Six APEX negative and six synthetic controls establish only stated branch/boundary replay coverage.',
       'Both policies total1511 expected reveals versus S1310 and U2448; eight positive order cases worse than S and ten ties retained.',
       'No full-negative expectation, all-task empirical improvement, statistical significance or general randomized optimality claimed.']}
    (BASE/'check_blind_random_independent_v1.json').write_text(json.dumps(report,indent=2)+'\n')
    (BASE/'check_blind_random_independent_v1.txt').write_text('PASS: 180 runs, 10569 events and 36 exact positive-case expectations independently verified.\n'+json.dumps({'counts':dict(counts),'aggregate':aggregate,'hard_family_checks':fixtures},indent=2)+'\nAll frozen inputs unchanged; no producer imports. These already-known development cases provide no held-out/physical inference.\n')
    print(json.dumps({k:report[k] for k in ['status','counts','aggregate','elapsed_seconds']},indent=2))
if __name__=='__main__':main()
