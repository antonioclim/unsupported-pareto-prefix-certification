#!/usr/bin/env python3
"""Verify and reproduce the selected own exact scientific checks in isolation.

Python standard library only. Original sources, inputs and retained outputs are
never rewritten. No network, package installation, external project or device
is invoked. See README.txt for the deliberately excluded historical P12 main.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
import sys
import tempfile
import time

ROOT=Path(__file__).resolve().parent
MANIFEST='MANIFEST.json'
JOBS='REPLAY_JOBS.json'
VALIDATION='REPLAY_VALIDATION.json'


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def relative(name):
    if not isinstance(name,str) or not name or '\\' in name or any(ord(c)<32 for c in name):raise ValueError('Invalid path')
    p=PurePosixPath(name)
    if p.is_absolute() or any(x in ('','.','..') for x in name.split('/')):raise ValueError('Unsafe path '+name)
    return Path(*p.parts)

def manifest_check(root):
    root=Path(root);d=read(root/MANIFEST);rows=d.get('files')
    if not isinstance(rows,list) or not rows:raise ValueError('Missing manifest rows')
    names=set()
    for row in rows:
      name=relative(row['path']).as_posix();p=root/name
      if name in names or name in (MANIFEST,VALIDATION):raise ValueError('Duplicate/self manifest row '+name)
      names.add(name)
      if p.is_symlink() or not p.is_file() or p.stat().st_size!=row['bytes'] or sha(p)!=row['sha256']:raise ValueError('Manifest mismatch '+name)
    actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
    if any(p.is_symlink() for p in root.rglob('*')):raise ValueError('Symlink in companion')
    if actual - {MANIFEST,VALIDATION} != names:raise ValueError('Manifest coverage mismatch')
    return rows

def freeze_rows(root,name):
    path=Path(root)/relative(name);d=read(path)
    raw=next((d[k] for k in ('sha256','files','files_sha256','frozen_files','entries') if k in d),None)
    if isinstance(raw,list):raw={row['path']:row for row in raw}
    if not isinstance(raw,dict) or not raw:raise ValueError('Invalid freeze '+name)
    rows=[]
    for filename,row in raw.items():
      if isinstance(row,str):row={'sha256':row}
      p=relative(filename)
      if not re.match(r'p\d+/',filename):p=relative((Path(name).parent/p).as_posix())
      target=Path(root)/p
      if target.is_symlink() or not target.is_file() or sha(target)!=row['sha256']:raise ValueError('Frozen dependency mismatch '+str(p))
      if 'bytes' in row and target.stat().st_size!=row['bytes']:raise ValueError('Frozen size mismatch '+str(p))
      rows.append((p.as_posix(),row['sha256']))
    return rows

def job_check(root):
    root=Path(root);d=read(root/JOBS);jobs=d.get('jobs')
    if not isinstance(jobs,list) or len(jobs)!=31 or d.get('expected_output_count')!=35:raise ValueError('Unexpected scientific job set')
    names=set();ids=set();outnames=set()
    for job in jobs:
      script=relative(job['script']).as_posix()
      if script in names or job['id'] in ids or not script.startswith(('p13/','p14/','p15/','p16/','p17/','p18/')):raise ValueError('Duplicate/out-of-scope job')
      names.add(script);ids.add(job['id'])
      if sha(root/script)!=job['source_sha256']:raise ValueError('Job source differs '+script)
      if not isinstance(job['arguments'],list) or any(not isinstance(a,str) or '\x00' in a for a in job['arguments']):raise ValueError('Invalid arguments')
      if job['outputs'] != [r['path'] for r in job['expected_outputs']]:raise ValueError('Output rows differ')
      for row in job['expected_outputs']:
        name=relative(row['path']).as_posix();p=root/name
        if name in outnames or not name.startswith(Path(script).parts[0]+'/'):raise ValueError('Duplicate/out-of-phase output '+name)
        outnames.add(name)
        if sha(p)!=row['sha256'] or p.stat().st_size!=row['bytes']:raise ValueError('Retained expected output differs '+name)
        allowed=row['allowed_changed_top_level_metadata']
        if not isinstance(allowed,list) or len(allowed)!=len(set(allowed)) or not set(allowed)<={'elapsed_seconds','producer_result_sha256'}:raise ValueError('Undeclared comparison relaxation')
        if 'producer_result_sha256' in allowed and (name!='p14/applied/check_transform_sensitivity_results_v1.json' or row.get('regenerated_hash_dependency')!='p14/applied/transform_sensitivity_results_v1.json'):raise ValueError('Unexpected output dependency comparison')
    if len(outnames)!=35:raise ValueError('Unexpected scientific output count')
    frozen=[]
    for name in d['historical_scientific_freezes_checked']:
      if name.startswith('p12/'):raise ValueError('Historical P12 administrative anchors must not be represented as checked')
      frozen.extend((name,*row) for row in freeze_rows(root,name))
    return jobs,frozen

def compare_output(original,regenerated,row,retained_digests):
    old=original.read_bytes();new=regenerated.read_bytes();same=old==new
    fields=row['allowed_changed_top_level_metadata']
    if not fields:
      if not same:raise ValueError('Scientific output not byte-identical '+row['path'])
      return {'byte_identical':True,'metadata_fields_permitted':[],'metadata_fields_changed':[],'scientific_content_equal':True}
    before=json.loads(old);after=json.loads(new)
    if not isinstance(before,dict) or not isinstance(after,dict):raise ValueError('Metadata exception needs JSON objects')
    for field in fields:
      if field not in before or field not in after:raise ValueError('Metadata field absent '+field)
    if 'elapsed_seconds' in fields:
      for value in (before['elapsed_seconds'],after['elapsed_seconds']):
        if isinstance(value,bool) or not isinstance(value,(int,float)) or value<0:raise ValueError('Invalid timing metadata')
    if 'producer_result_sha256' in fields:
      dep=row['regenerated_hash_dependency']
      if before['producer_result_sha256']!=retained_digests[dep] or after['producer_result_sha256']!=sha(regenerated.parents[2]/dep):
        # regenerated is ROOT/p14/applied/file; parents[2] is isolated ROOT.
        raise ValueError('Producer hash dependency not linked to its actual bytes')
    a={k:v for k,v in before.items() if k not in fields};b={k:v for k,v in after.items() if k not in fields}
    if a!=b:raise ValueError('Scientific JSON content differs '+row['path'])
    changed=[f for f in fields if before[f]!=after[f]]
    return {'byte_identical':same,'metadata_fields_permitted':fields,'metadata_fields_changed':changed,'scientific_content_equal':True}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check-only',action='store_true',help='Only manifest and historical scientific freeze checks; no scientific execution')
    parser.add_argument('--validation-output',type=Path,help='Write a new validation record outside the manifest-covered inputs')
    args=parser.parse_args()
    rows=manifest_check(ROOT);jobs,frozen=job_check(ROOT)
    release_frozen=freeze_rows(ROOT,'RELEASE_SOURCE_FREEZE.json')
    input_hashes={r['path']:r['sha256'] for r in rows}
    result={'schema':'exact-acquisition-clean-replay-validation-v1','administrative_only':args.check_only,
      'manifest_sha256':sha(ROOT/MANIFEST),'runner_sha256':sha(Path(__file__)),
      'release_source_freeze_sha256':sha(ROOT/'RELEASE_SOURCE_FREEZE.json'),'release_source_freeze_entries_verified':len(release_frozen),
      'manifest_files_verified':len(rows),'historical_scientific_freeze_entries_verified':len(frozen),
      'historical_sources_and_inputs_unchanged':True,'P12_historical_main_executed':False,
      'new_physical_measurements':0,'external_project_code_executions':0,'network_or_installs':False}
    records=[]
    if not args.check_only:
      original_outputs={r['path']:r for j in jobs for r in j['expected_outputs']}
      expected_digests={n:r['sha256'] for n,r in original_outputs.items()}
      with tempfile.TemporaryDirectory(prefix='exact_acquisition_clean_replay_') as temp:
        isolated=Path(temp)
        for row in rows:
          src=ROOT/relative(row['path']);dst=isolated/relative(row['path']);dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(src.read_bytes())
        for name in original_outputs:(isolated/name).unlink()
        env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
        for job in jobs:
          print('Replaying '+job['id']+' '+job['script'],flush=True)
          args2=[str(isolated/job['outputs'][int(a.removeprefix('NEW_OUTPUT_'))]) if a.startswith('NEW_OUTPUT_') else a for a in job['arguments']]
          start=time.monotonic()
          run=subprocess.run([sys.executable,'-B',str(isolated/job['script']),*args2],cwd=isolated,env=env,capture_output=True,text=True,timeout=job['timeout_seconds'])
          if run.returncode:raise RuntimeError(job['script']+' failed:\n'+run.stdout[-5000:]+'\n'+run.stderr[-5000:])
          compared=[]
          for output in job['expected_outputs']:
            name=output['path'];p=isolated/name
            if not p.is_file() or p.is_symlink():raise ValueError('Missing scientific output '+name)
            c=compare_output(ROOT/name,p,output,expected_digests)
            compared.append({'path':name,'retained_sha256':expected_digests[name],'regenerated_sha256':sha(p),**c})
          records.append({'id':job['id'],'script':job['script'],'source_sha256':job['source_sha256'],'exit_code':run.returncode,'replay_elapsed_seconds':round(time.monotonic()-start,4),'outputs':compared})
          print('PASS '+job['id'],flush=True)
        for name,digest in input_hashes.items():
          if name not in original_outputs and sha(isolated/name)!=digest:raise ValueError('Isolated input/source changed '+name)
        if [x for name in read(ROOT/JOBS)['historical_scientific_freezes_checked'] for x in freeze_rows(isolated,name)] != [x[1:] for x in frozen]:raise ValueError('Isolated scientific freezes changed')
    if manifest_check(ROOT)!=rows or sha(ROOT/MANIFEST)!=result['manifest_sha256']:raise ValueError('Original companion changed during replay')
    result.update(status='PASS_MANIFEST_AND_SCIENTIFIC_FREEZES_ONLY' if args.check_only else 'PASS_CLEAN_RESEARCH_COMPANION_ISOLATED_REPLAY',
      scientific_jobs_executed=len(records),scientific_outputs_regenerated=sum(len(j['outputs']) for j in records),
      byte_identical_outputs=sum(o['byte_identical'] for j in records for o in j['outputs']),
      scientific_content_equal_outputs=sum(o['scientific_content_equal'] for j in records for o in j['outputs']),
      outputs_with_declared_metadata_changes=sum(bool(o['metadata_fields_changed']) for j in records for o in j['outputs']),results=records,
      limitations=['Finite controls do not execute the infinite Ramsey proof or establish historical priority.',
        'P12 original historical main retains private administrative ZIP/report anchors and is not part of this clean automatic replay.',
        'Only top-level elapsed_seconds and one verified regenerated-producer hash may vary where explicitly predeclared; raw retained outputs are preserved.',
        'No data acquisition, physical wireless experiment, external research software or public deposition is performed.'])
    if args.validation_output:
      p=args.validation_output.resolve();protected={(ROOT/r['path']).resolve() for r in rows}|{(ROOT/MANIFEST).resolve()}
      if p in protected:raise ValueError('Validation output would overwrite protected input')
      p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
