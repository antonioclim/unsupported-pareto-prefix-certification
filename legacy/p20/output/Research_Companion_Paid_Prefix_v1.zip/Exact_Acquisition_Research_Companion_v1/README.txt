Research companion for Exact Acquisition Costs for Certifying Unsupported Configurations
Antonio Clim
23 October 2026

Purpose and result scope

This companion contains the exact arithmetic programs, fixed fixtures, original
APEX data and retained computational results used in the article and supplement.
It separates the reusable scientific material from the author's phase-by-phase
editorial and audit history. Files below p9 through p18 keep their original
relative paths because the unchanged programs use those paths. These labels
record provenance; running the companion does not require the older phase ZIPs.

The automatic release replay selects 31 own scientific programs with 35 retained
JSON/CSV outputs. It covers balanced search and its ordinal controls, raw-row
embeddings, bounded certificates, finite precision controls, the three-by-three
lower and upper examples, finite-alphabet completion checks, the numeric codec,
joint row domains, the triangle policy, common setup charges, synthetic tariff
stress tests, APEX subcatalogues and the unrestricted-row/prefix counterexample.
REPLAY_JOBS.json gives every exact source, command, expected output and allowed
metadata difference. The infinite Ramsey argument is analytic and is not executed
by these finite programs. Their success neither establishes historical priority
nor substitutes for reading the article's proofs.

The paper reports adverse wireless outcomes. In particular, all 41 positive tasks
in the fixed 1,536-task APEX replay require all nine disclosures. Those results
remain included. Synthetic cases are separately identified and do not represent
new radio measurements or independent physical replications.

How to verify without running scientific programs

Use Python 3.12 or a compatible later Python 3 installation. The selected checks
use only the standard library. No third-party package, installation, network,
credential, firmware, external research framework or hardware is needed.

1. Extract the companion ZIP into a new folder.
2. Open a terminal in the folder containing this README and reproduce.py.
3. Run:

   python3 reproduce.py --check-only

On Windows, the equivalent command with a registered Python launcher is:

   py -3 reproduce.py --check-only

This verifies all manifest-covered bytes and the selected historical scientific
freezes. It does not rerun the scientific calculations or regenerate outputs.

How to reproduce the selected scientific calculations

From the same folder, run:

   python3 reproduce.py --validation-output REPLAY_VALIDATION.json

On Windows:

   py -3 reproduce.py --validation-output REPLAY_VALIDATION.json

The runner copies the manifest-covered files into a disposable temporary folder,
deletes only the 35 expected output copies there and invokes the declared programs
in dependency order. All manifest-covered original files remain unchanged. Each program
has a 600-second timeout; total time depends on the computer. Progress is printed
before and after every job. The validation record is new release bookkeeping and
is excluded from its own input manifest to avoid a circular hash dependency.

Most outputs must match the retained files byte for byte. A small explicitly
declared subset has a top-level elapsed_seconds field. That field is checked as
nonnegative timing metadata and excluded from scientific JSON equality. For the
independent objective-transform check, producer_result_sha256 is additionally
required to match the actual regenerated producer bytes, while its retained value
must match the retained producer bytes. No scientific result, probability,
measurement, witness, transcript or fixture is normalised. Exact raw retained
outputs are preserved. The codec's documented metadata timestamp is supplied as
an explicit replay argument, distinct from the actual release replay time.

Do not execute the individual original scripts in this source folder: several
write fixed filenames and overwrite outputs; one refuses existing destinations.
The isolated runner handles their output paths and dependency order. It never
executes the retained failed or exploratory versions as if they were final checks.

One explicit historical replay limit

The retained P12 adverse comparison contains 18 already-known APEX controls:
1,511 expected accesses versus 1,310 for policy S and 2,448 for census, with eight
losses and ten ties. Its results, event transcripts, fixtures, unchanged sources
and failure/correction provenance remain included. The unchanged original P12
main also hashes a private P11 phase ZIP and audit report as administrative
anchors. Those administrative files are deliberately absent here. Consequently,
the historical P12 main is provenance-only in this clean companion and is not
advertised as a runnable selected job. The source and its computational primitive
dependencies are retained for inspection; the manifest verifies their exact bytes.
The complete private author dossier preserves the original anchored replay.

Provenance and failed attempts

HISTORICAL_BYTE_PROVENANCE.json maps every selected inherited file to its exact
SHA256 and size recovered from the immutable author dossier. The own source was
copied without modification. Historical protocol/freeze timestamps describe their
original units, not prospective registration of discoveries. The three-by-three
independent check initially failed because a cost-seven class was missing; both
failed source and failure record are retained alongside the corrected v2. The
known-slot comparison's tuple/list harness incident and correction are retained.
Exploratory sources and post-discovery retention of the subset counterexample are
identified. The release wrapper is new; its own source and job descriptor are
frozen separately before its first scientific release execution.

The supplied Source_Version_Notes_v1.txt identifies the author-declared earlier
manuscripts and bibliographic version limits. It does not clear historical
priority or license third-party articles for redistribution. No external paper
PDF, PostScript, firmware, research-framework source, private rendered page,
service credential or editorial/AI reviewer conversation is redistributed here.

Data attribution and licensing

See LICENSE_AND_ATTRIBUTION.txt before reuse or public redistribution. The two
original APEX JSONs and creator README are unchanged CC BY 4.0 material. Derived
outputs apply the transformations and deterministic selections documented in the
scientific protocols. The upstream dataset licence does not automatically license
all new code, generated material or this entire companion. Selection of a licence
for the author's new material and approval of public deposition remain with the
author; no DOI or public repository release is invented by this package.
