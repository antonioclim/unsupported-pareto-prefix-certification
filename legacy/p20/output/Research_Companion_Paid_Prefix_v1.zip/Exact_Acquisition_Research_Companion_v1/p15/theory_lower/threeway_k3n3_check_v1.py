#!/usr/bin/env python3
"""Own independent exact interval and full-prefix Bellman confirmation."""
import hashlib
import itertools
import json
from fractions import Fraction as F
from functools import lru_cache
from pathlib import Path

ROOT=Path(__file__).resolve().parent


def true_prefix(table,ns):
    lower=[];upper=[]
    for group,n in zip(table,ns):
        p=tuple(sum(row[d] for row in group[:n])/3 for d in (0,1))
        lower.append(p);upper.append(tuple(v+F(3-n,3) for v in p))
    if any(p[0]<=upper[0][0] and p[1]<=upper[0][1] and p!=upper[0] for p in lower[1:]):
        return False
    lo,hi=F(0),F(1)
    for p in upper[1:]:
        dx,dy=p[0]-lower[0][0],p[1]-lower[0][1]
        slope=dx-dy
        if slope>0:lo=max(lo,-dy/slope)
        elif slope<0:hi=min(hi,-dy/slope)
        elif dy<0:return True
    return lo>hi


def main():
    fixture_path=ROOT/'threeway_k3n3_fixtures_v1.json'
    fixture=json.loads(fixture_path.read_text())
    worlds=[tuple(tuple(tuple(F(v) for v in row) for row in group) for group in x['rows']) for x in fixture['worlds']]
    result_worlds=[]
    for src,table in zip(fixture['worlds'],worlds):
        assert all(0<=v<=1 for group in table for row in group for v in row)
        trues=[ns for ns in itertools.product(range(4),repeat=3) if true_prefix(table,ns)]
        assert [list(s) for s in trues]==src['expected_TRUE_prefixes']
        minimum=min(map(sum,trues));assert minimum==src['expected_C_B']
        result_worlds.append({'id':src['id'],'C_B':minimum,'TRUE_prefixes':[list(s) for s in trues]})
    root_actions={}

    @lru_cache(None)
    def V(ns,ids):
        if true_prefix(worlds[ids[0]],ns):return F(0)
        values={}
        for g in range(3):
            if ns[g]==3:continue
            buckets={}
            for wid in ids:buckets.setdefault(worlds[wid][g][ns[g]],[]).append(wid)
            nn=tuple(n+(q==g) for q,n in enumerate(ns))
            values[g]=1+sum(F(len(wids),len(ids))*V(nn,tuple(wids)) for wids in buckets.values())
        assert values
        if ns==(0,0,0):root_actions.update({str(g):str(v) for g,v in values.items()})
        return min(values.values())

    optimum=V((0,0,0),(0,1,2))
    assert optimum==F(fixture['expected_uniform_Bayes_cost'])
    assert optimum/8==F(fixture['expected_ratio_lower'])
    out={'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
         'fixture_sha256':hashlib.sha256(fixture_path.read_bytes()).hexdigest(),
         'worlds':result_worlds,'prefix_states_enumerated':192,
         'uniform_Bayes_optimum':str(optimum),'ratio_lower':str(optimum/8),
         'Bellman_states':V.cache_info().currsize,'root_action_values':root_actions,
         'discovery_provenance':fixture['discovery_provenance'],'all_pass':True,
         'scope':'Finite full-prefix sound-stop game; supports global lower, not global equality.'}
    (ROOT/'threeway_k3n3_check_v1.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))


if __name__=='__main__':main()
