#!/usr/bin/env python3
"""Own frozen exact confirmation of asymmetric two-world ratio lower."""
import hashlib
import itertools
import json
from fractions import Fraction as F
from functools import lru_cache
from pathlib import Path

ROOT=Path(__file__).resolve().parent


def true_prefix(table,ns):
    lower=[];upper=[]
    for group,n in zip(table,ns):
        p=tuple(sum(r[d] for r in group[:n])/3 for d in (0,1))
        lower.append(p);upper.append(tuple(v+F(3-n,3) for v in p))
    if any(p[0]<=upper[0][0] and p[1]<=upper[0][1] and p!=upper[0] for p in lower[1:]):return False
    lo,hi=F(0),F(1)
    for p in upper[1:]:
        dx,dy=p[0]-lower[0][0],p[1]-lower[0][1];s=dx-dy
        if s>0:lo=max(lo,-dy/s)
        elif s<0:hi=min(hi,-dy/s)
        elif dy<0:return True
    return lo>hi


def main():
    fixture_path=ROOT/'twoworld25_k3n3_fixtures_v1.json'
    f=json.loads(fixture_path.read_text())
    worlds=[tuple(tuple(tuple(F(v) for v in row) for row in group) for group in w['rows']) for w in f['worlds']]
    weights=tuple(F(w['raw_cost_prior']) for w in f['worlds'])
    assert sum(weights)==1
    descriptions=[]
    for src,table in zip(f['worlds'],worlds):
        assert all(0<=v<=1 for group in table for row in group for v in row)
        trues=[ns for ns in itertools.product(range(4),repeat=3) if true_prefix(table,ns)]
        assert [list(s) for s in trues]==src['expected_TRUE_prefixes']
        cb=min(map(sum,trues));assert cb==src['expected_C_B']
        descriptions.append({'id':src['id'],'C_B':cb,'TRUE_prefixes':[list(s) for s in trues]})
    root_actions={}

    @lru_cache(None)
    def V(ns,ids):
        if true_prefix(worlds[ids[0]],ns):return F(0)
        mass=sum(weights[w] for w in ids)
        actions={}
        for g in range(3):
            if ns[g]==3:continue
            buckets={}
            for wid in ids:buckets.setdefault(worlds[wid][g][ns[g]],[]).append(wid)
            nn=tuple(n+(q==g) for q,n in enumerate(ns))
            actions[g]=1+sum(sum(weights[w] for w in bucket)/mass*V(nn,tuple(bucket)) for bucket in buckets.values())
        assert actions
        if ns==(0,0,0):root_actions.update({str(g):str(v) for g,v in actions.items()})
        return min(actions.values())

    raw=V((0,0,0),(0,1))
    ratio_mass=sum(F(w['ratio_weight'])/w['expected_C_B'] for w in f['worlds'])
    assert ratio_mass==F(f['ratio_mass'])
    assert all(F(w['ratio_weight'])/w['expected_C_B']/ratio_mass==weights[q] for q,w in enumerate(f['worlds']))
    assert raw==F(f['expected_raw_Bayes_cost'])
    value=raw*ratio_mass;assert value==F(f['expected_ratio_value'])
    p=F(16,23)
    a_ratio=(8+p)/8;d_ratio=(9-2*p)/7
    assert a_ratio==d_ratio==value
    out={'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
         'fixture_sha256':hashlib.sha256(fixture_path.read_bytes()).hexdigest(),
         'worlds':descriptions,'prefix_states_enumerated':128,'Bellman_states':V.cache_info().currsize,
         'raw_cost_prior':[str(x) for x in weights],'raw_Bayes_optimum':str(raw),
         'ratio_weights':[w['ratio_weight'] for w in f['worlds']], 'ratio_mass':str(ratio_mass),
         'ratio_value':str(value),'matching_mix_P_probability':str(p),'root_action_values':root_actions,
         'discovery_provenance':f['discovery_provenance'],'all_pass':True,
         'scope':'Exact fixed-family lower; global equality additionally uses independent upper proof.'}
    (ROOT/'twoworld25_k3n3_check_v1.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))


if __name__=='__main__':main()
