#!/usr/bin/env python3
"""EXPLORATORY, not pre-registered: asymmetric three-way + cheap fourth world.
Own stdlib exact count-frontier search; no universal claim from a family.
"""
import hashlib
import itertools
import json
from fractions import Fraction as F
from functools import lru_cache
from pathlib import Path

ROOT=Path(__file__).resolve().parent
COMMON=[[(F(9,20),F(9,10))]*2,[(F(0),F(93,100))]*2,
        [(F(93,100),F(0)),(F(57,100),F(0))]]
CG=(F(51,100),F(3,100));LG=(F(0),F(99,100));RG=(F(9,20),F(0));BAD=(F(1),F(1))
TAILS=[[(F(0),F(0)),LG,RG],[CG,BAD,RG],[CG,LG,BAD],[(F(0),F(9,10)),LG,RG]]
WORLDS=tuple(tuple(tuple(COMMON[g]+[tail[g]]) for g in range(3)) for tail in TAILS)


def good(table,ns):
    low=[];up=[]
    for group,n in zip(table,ns):
        p=tuple(sum(r[d] for r in group[:n])/3 for d in (0,1))
        low.append(p);up.append(tuple(v+F(3-n,3) for v in p))
    if any(p[0]<=up[0][0] and p[1]<=up[0][1] and p!=up[0] for p in low[1:]):return False
    lo,hi=F(0),F(1)
    for p in up[1:]:
        dx,dy=p[0]-low[0][0],p[1]-low[0][1];s=dx-dy
        if s>0:lo=max(lo,-dy/s)
        elif s<0:hi=min(hi,-dy/s)
        elif dy<0:return True
    return lo>hi


def prune(vectors):
    out=[]
    for v in sorted(set(vectors),key=lambda v:(sum(v),v)):
        if not any(all(a<=b for a,b in zip(u,v)) for u in out):out.append(v)
    return tuple(out)


@lru_cache(None)
def frontier(ns,ids):
    if good(WORLDS[ids[0]],ns):return ((0,)*4,)
    vectors=[]
    for g in range(3):
        if ns[g]==3:continue
        buckets={}
        for wid in ids:buckets.setdefault(WORLDS[wid][g][ns[g]],[]).append(wid)
        nn=tuple(n+(q==g) for q,n in enumerate(ns))
        branches=[frontier(nn,tuple(wids)) for wids in buckets.values()]
        for combo in itertools.product(*branches):
            v=[sum(u[q] for u in combo)+(q in ids) for q in range(4)]
            vectors.append(tuple(v))
    return prune(vectors)


def main():
    descriptions=[]
    denominators=[]
    for name,table in zip('ABCD',WORLDS):
        trues=[ns for ns in itertools.product(range(4),repeat=3) if good(table,ns)]
        cb=min(map(sum,trues));denominators.append(cb)
        descriptions.append({'id':name,'C_B':cb,'TRUE_prefixes':[list(s) for s in trues]})
    fronts=frontier((0,0,0),(0,1,2,3))
    # Coarse rational prior grid is exploration, not an LP or optimality proof.
    grid=60
    best=(F(0),None,None)
    for a in range(grid+1):
        for b in range(grid-a+1):
            for c in range(grid-a-b+1):
                d=grid-a-b-c
                weights=(a,b,c,d)
                value=min(sum(F(w*v,grid*den) for w,v,den in zip(weights,vec,denominators)) for vec in fronts)
                if value>best[0]:best=(value,weights,None)
    out={'status':'EXPLORATORY_COMPLETE','source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
         'worlds':descriptions,'nondominated_deterministic_cost_vectors':[list(v) for v in fronts],
         'frontier_states':frontier.cache_info().currsize,'prior_grid_denominator':grid,
         'best_grid_lower':str(best[0]),'best_grid_weights':best[1],
         'scope':'Exploratory finite-family minimax search; grid optimum is not exact LP proof.'}
    (ROOT/'fourway_explore_v1.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))


if __name__=='__main__':main()
