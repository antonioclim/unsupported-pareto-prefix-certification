#!/usr/bin/env python3
"""Independent exact prefix/Bellman audit of P15's K3,N3 claims.

Reuses only the older independently derived closed-support-interval oracle.
Does not import either new theorem author's producer or Bellman code.
"""
from fractions import Fraction as Q
from pathlib import Path
from itertools import product,permutations
from functools import lru_cache
import hashlib,importlib.util,json

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('old_interval_oracle',ROOT/'p13/theory/bounded_comparator_independent_check.py')
oracle=importlib.util.module_from_spec(spec);spec.loader.exec_module(oracle)

def parse(rows):return [[tuple(Q(x) for x in r) for r in g] for g in rows]
def true(rows,counts):return oracle.force_true(rows,0,counts,Q(1))
def safe(rows,counts,g):
    bs=oracle.corners(rows,counts,Q(1))
    return not oracle.dominates(bs[g][0],bs[0][1])

def policy_a(rows,tail_order,deterministic=False):
    n=[3,0,0]
    for g in (1,2):
        while not safe(rows,n,g):
            if n[g]==3:return sum(n),False,n
            n[g]+=1
    if true(rows,n):return sum(n),True,n
    if deterministic:
        for g in (1,2):n[g]=3
        return sum(n),true(rows,n),n
    # Bounded TRUE test at H precedes all prefetch, as required by the proof.
    for g in (1,2):
        while n[g]<2:
            n[g]+=1
            if true(rows,n):return sum(n),True,n
    for g in tail_order:
        if n[g]<3:
            n[g]+=1
            if true(rows,n):return sum(n),True,n
    return sum(n),true(rows,n),n

def policy_b(rows):
    n=[2,3,3]
    if true(rows,n):return 8,True,n
    n[0]=3
    return 9,true(rows,n),n

def common(rows,counts):
    return tuple(tuple(tuple(r) for r in g[:n]) for g,n in zip(rows,counts))

def family_bellman(worlds):
    visits=0
    @lru_cache(None)
    def V(ids,counts):
        nonlocal visits
        visits+=1
        # Stopping must be sound over the full continuous domain.
        if true(worlds[ids[0]],counts):
            assert all(true(worlds[i],counts) for i in ids)
            return Q(0)
        options=[]
        for g in range(3):
            if counts[g]==3:continue
            branches={}
            for i in ids:branches.setdefault(worlds[i][g][counts[g]],[]).append(i)
            nxt=list(counts);nxt[g]+=1
            options.append(1+sum((Q(len(ids2),len(ids))*V(tuple(ids2),tuple(nxt)) for ids2 in branches.values()),Q(0)))
        assert options
        return min(options)
    value=V(tuple(range(3)),(0,0,0))
    return value,visits

def ratio_bellman(worlds,prior,denoms):
    visits=0
    @lru_cache(None)
    def V(ids,counts):
        nonlocal visits
        visits+=1
        if true(worlds[ids[0]],counts):
            assert all(true(worlds[i],counts) for i in ids)
            return Q(0)
        mass=sum((prior[i] for i in ids),Q(0))
        increment=sum((prior[i]/denoms[i] for i in ids),Q(0))/mass
        options=[]
        for g in range(3):
            if counts[g]==3:continue
            branches={}
            for i in ids:branches.setdefault(worlds[i][g][counts[g]],[]).append(i)
            nxt=list(counts);nxt[g]+=1
            options.append(increment+sum((sum((prior[i] for i in branch),Q(0))/mass*V(tuple(branch),tuple(nxt)) for branch in branches.values()),Q(0)))
        assert options
        return min(options)
    value=V(tuple(range(len(worlds))),(0,0,0))
    return value,visits

def main():
    frozen=json.loads((HERE/'independent_k3n3_FREEZE_v2.json').read_text())
    for name,digest in frozen['sha256'].items():assert sha(ROOT/name)==digest,name
    fixture=json.loads((HERE/'independent_k3n3_fixtures_v2.json').read_text())
    lower=json.loads((ROOT/'p15/theory_lower/threeway_k3n3_fixtures_v1.json').read_text())
    worlds=[parse(w['rows']) for w in lower['worlds']]
    matching=json.loads((ROOT/'p15/theory_lower/twoworld25_k3n3_fixtures_v1.json').read_text())
    matching_rows=[parse(w['rows']) for w in matching['worlds']]
    catalogue=[('matching_'+w['id'],rows) for w,rows in zip(matching['worlds'],matching_rows)]
    for w,rows in zip(lower['worlds'],worlds):catalogue.append(('threeway_'+w['id'],rows))
    points=[tuple(Q(x) for x in p) for p in fixture['constant_points']]
    for i,pts in enumerate(product(points,repeat=3)):
        catalogue.append(('constant_'+str(i),[[p]*3 for p in pts]))
    common_rows=parse(fixture['common_two_rows'])
    for i,tails in enumerate(product(*fixture['tail_options'])):
        rows=[g+[tuple(Q(x) for x in t)] for g,t in zip(common_rows,tails)]
        catalogue.append(('tail_control_'+str(i),rows))
    cases=[];categories={};states=0
    for name,rows in catalogue:
        assert all(0<=x<=1 and 0<=y<=1 for g in rows for x,y in g)
        positives=[]
        for n in product(range(4),repeat=3):
            states+=1
            if true(rows,n):positives.append(n)
        cb=min((sum(n) for n in positives),default=None)
        mins=[list(n) for n in positives if sum(n)==cb]
        outcome=true(rows,(3,3,3))
        assert (cb is not None)==outcome
        ca=[policy_a(rows,order) for order in ((1,2),(2,1))]
        cd=policy_a(rows,(1,2),True);b=policy_b(rows)
        assert all(z[1]==outcome and z[0]<=9 for z in ca+[cd,b]),name
        ea=Q(ca[0][0]+ca[1][0],2)
        mixed=Q(16,23)*ea+Q(7,23)*b[0]
        if cb is None:category='FALSE'
        elif cb==7:
            category='CB7'
            assert cd[0]==ea==7 and mixed/cb<=Q(25,23),(name,mins,cd,ea,mixed)
        elif cb==8:
            partial=[2,3,3] in mins
            full=any(n[0]==3 for n in mins)
            category='CB8_'+('both' if partial and full else 'partial_only' if partial else 'full_only')
            if full:assert ea<=Q(17,2),(name,mins,ea)
            if partial:assert b[0]==8,(name,mins,b)
            assert cd[0]/Q(cb)<=Q(9,8) and mixed/cb<=Q(25,23),(name,mins,ea,b,mixed)
        else:
            category='CB9';assert cb==9 and mixed<=9 and cd[0]<=9
        categories[category]=categories.get(category,0)+1
        cases.append({'id':name,'C_B':cb,'minimum_prefixes':mins,'category':category,
            'deterministic_cost':cd[0],'A_expected_cost':str(ea),'B_cost':b[0],
            'mixed_expected_cost':str(mixed),'mixed_ratio':str(mixed/cb) if cb else None})
    assert {'CB7','CB8_partial_only','CB8_full_only','CB8_both','CB9','FALSE'}<=set(categories)
    for w,rows in zip(lower['worlds'],worlds):
        alltrue=[list(n) for n in product(range(4),repeat=3) if true(rows,n)]
        assert alltrue==w['expected_TRUE_prefixes']
    bayes,visits=family_bellman(worlds);assert bayes==Q(26,3)
    for w,rows in zip(matching['worlds'],matching_rows):
        alltrue=[list(n) for n in product(range(4),repeat=3) if true(rows,n)]
        assert alltrue==w['expected_TRUE_prefixes']
        rec=next(z for z in cases if z['id']=='matching_'+w['id'])
        assert Q(rec['mixed_ratio'])==Q(25,23)
    ratio_value,ratio_states=ratio_bellman(matching_rows,[Q(16,23),Q(7,23)],[Q(8),Q(7)])
    assert ratio_value==Q(25,23)

    permutation_costs=[]
    for rows in worlds:
        costs=[]
        for order in permutations(range(3)):
            n=[2,2,2]
            for g in order:
                n[g]+=1
                if true(rows,n):break
            costs.append(sum(n))
        assert sum(costs,Q(0))/len(costs)==Q(26,3)
        permutation_costs.append(costs)
    for name,digest in frozen['sha256'].items():assert sha(ROOT/name)==digest,name
    out={'status':'PASS_INDEPENDENT_K3N3_EXACT_RANDOMISED_AND_DETERMINISTIC_CONTROLS',
        'source_sha256':sha(Path(__file__)),'catalogue_tables':len(catalogue),
        'prefix_states':states,'categories':categories,'threeway_family_Bayes_cost':str(bayes),
        'Bellman_states':visits,'threeway_tail_permutation_costs':permutation_costs,
        'global_randomised_lower':'25/23','global_randomised_upper':'25/23',
        'absolute_bracket_width':'0',
        'relative_upper_lower_gap':'0','matching_family_ratio_Bellman':str(ratio_value),'matching_Bellman_states':ratio_states,'matching_ratio_prior':['16/23','7/23'],'historical_threeway_family_ratio':'13/12',
        'deterministic_exact':'9/8','records':cases,
        'scope':['Finite native exact controls do not prove universal policy inequalities; analytic proof is separate',
        'Only earlier independent closed-interval geometric oracle imported; no new author producer imported',
        'Full-domain stopping retained in finite-family Bellman; no positive promise',
        'These are synthetic mathematical controls, not wireless measurements or independent physical replications']}
    (HERE/'independent_k3n3_results_v2.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k!='records'},indent=2))

if __name__=='__main__':main()
