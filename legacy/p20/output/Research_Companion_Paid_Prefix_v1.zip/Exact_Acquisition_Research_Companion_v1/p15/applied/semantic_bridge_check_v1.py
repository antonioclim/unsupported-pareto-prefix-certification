#!/usr/bin/env python3
"""Own exact finite controls for the P15 operational domain-transfer note.

No external project code, old production oracle or network is imported.
This enumerates actual completion rectangles; it is not a radio experiment.
"""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
import json,hashlib

HERE=Path(__file__).resolve().parent

def dominates(q,p):
    return all(q[j]<=p[j] for j in (0,1)) and any(q[j]<p[j] for j in (0,1))

def supported(p,others):
    lo,hi=F(0),F(1)
    for q in others:
        dx,dy=q[0]-p[0],q[1]-p[1]
        a,b=dx-dy,dy
        if a>0:lo=max(lo,-b/a)
        elif a<0:hi=min(hi,-b/a)
        elif b<0:return False
        if lo>hi:return False
    return True

def robust_good(values,N,prefix):
    lowers=[tuple(p[j]*n/N for j in (0,1)) for p,n in zip(values,prefix)]
    uppers=[tuple(p[j]*n/N+F(N-n,N) for j in (0,1)) for p,n in zip(values,prefix)]
    return not any(dominates(q,uppers[0]) for q in lowers[1:]) and not supported(lowers[0],uppers[1:])

def main():
    raw=(HERE/'semantic_bridge_fixtures_v1.json').read_bytes();j=json.loads(raw)
    results=[];states=0
    for K,N in j['cases']:
        values=[(F(3,5),F(3,5)),(F(0),F(1)),(F(1),F(0))]+[(F(1),F(1))]*(K-3)
        best=K*N;minima=[];count=0
        assert not any(dominates(q,values[0]) for q in values[1:])
        assert not supported(values[0],values[1:])
        for prefix in product(range(N+1),repeat=K):
            states+=1
            if robust_good(values,N,prefix):
                count+=1;cost=sum(prefix)
                if cost<best:best=cost;minima=[prefix]
                elif cost==best:minima.append(prefix)
        assert best>=K+2*N-2
        correlated_best=K
        assert best>=correlated_best
        results.append({'K':K,'N':N,'constant_rows_domain_C_star':correlated_best,
            'product_square_C_star':best,'universal_product_lower_bound':K+2*N-2,
            'exact_comparator_gap_ratio':str(F(best,K)),'product_TRUE_states':count,
            'minimum_prefixes':[list(x) for x in minima]})
    # Deadline-censoring algebra controls: values are normalised packet times,
    # failures are assigned one; successful latencies are strictly below one.
    packet_states=0;strict_coupling=0
    for M in j['packet_counts']:
        for xs in product((F(0),F(1,2),F(1)),repeat=M):
            failure=F(sum(x==1 for x in xs),M);cost=sum(xs,F(0))/M
            assert 0<=failure<=cost<=1
            packet_states+=1;strict_coupling+=int(failure<cost)
    result={'status':'PASS_EXACT_SYNTHETIC_SEMANTIC_CONTROLS',
        'fixture_sha256':hashlib.sha256(raw).hexdigest(),'constant_archive_cases':len(results),
        'enumerated_product_prefix_states':states,'cases':results,
        'deadline_packet_sequences':packet_states,'strict_failure_cost_couplings':strict_coupling,
        'impossible_product_row_example':{'cost':'0','failure':'1'},
        'scope':['Finite arithmetic illustrations; universal transfer inequalities proved in accompanying note',
            'Known constant-row domain is a mathematical counterexample, not a claim about APEX',
            'No remote service, transport, firmware or radio measurement was executed']}
    out=HERE/'semantic_bridge_results_v1.json';out.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='cases'},indent=2))

if __name__=='__main__':main()
