#!/usr/bin/env python3
"""Own exact finite Bayesian 2x2 chain-graph game, not external code.
A policy may stop only after querying both endpoints of an actual strict edge.
This relaxes a universally sound positive-certificate policy and yields a lower bound.
"""
from fractions import Fraction as Q
from functools import lru_cache
from pathlib import Path
import hashlib,json,time

def worlds(M):
    result=[]
    for t in range(1,M+1):
        for leftswap in range(2):
            for rightswap in range(2):
                left=[2*t+1,2*t+3];right=[2*t,2*t+2]
                if leftswap:left.reverse()
                if rightswap:right.reverse()
                result.append(tuple(left+right))
    assert len(set(result))==len(result)==4*M
    return tuple(result)

def edge(observed):
    return any(observed[i] is not None and observed[j] is not None and observed[i]<observed[j]
               for i in [0,1] for j in [2,3])

def game(M):
    inputs=worlds(M);visited={}
    @lru_cache(None)
    def value(observed):
        if edge(observed):return Q(0)
        posterior=[w for w in inputs if all(v is None or v==w[i] for i,v in enumerate(observed))]
        assert posterior
        options={}
        for i,v in enumerate(observed):
            if v is not None:continue
            buckets={}
            for w in posterior:buckets.setdefault(w[i],0);buckets[w[i]]+=1
            score=Q(1)
            for reveal,n in buckets.items():
                updated=list(observed);updated[i]=reveal
                score+=Q(n,len(posterior))*value(tuple(updated))
            options[i]=score
        assert options
        best=min(options.values());visited[observed]={'posterior':len(posterior),'value':str(best),'actions':{str(i):str(v) for i,v in options.items()}}
        return best
    result=value((None,)*4)
    first_states=[]
    for v in sorted({w[0] for w in inputs}):
        obs=(v,None,None,None);first_states.append({'observed_L0':v,**visited.get(obs,{'value':str(value(obs))})})
    return {'M':M,'world_count':len(inputs),'optimal_expected_vertex_queries':str(result),
      'claimed_formula':str(Q(13,4)-Q(1,4*M)),
      'strictly_above_three':result>3,'root_actions':visited[(None,)*4]['actions'],
      'states_cached':value.cache_info().currsize,'first_L_states':first_states}

def supported(p,points):
    differences=[(x-p[0],y-p[1]) for x,y in points];roots={Q(0),Q(1)}
    for x,y in differences:
        if x!=y:
            w=y/(y-x)
            if 0<=w<=1:roots.add(w)
    return any(all(w*x+(1-w)*y>=0 for x,y in differences) for w in roots)

def embedding(world,N,M):
    assert N>=2;L=2*M+3;b=Q(1,2*N)
    target=[(Q(1),b)]*N;groups=[target]
    for i,t in enumerate(world):
        if i<2:
            group=[(Q(0),Q(1))]+[(Q(0),Q(0))]*(N-2)+[(Q(0),Q(t,4*L))]
        else:
            x=1+1/(1+Q(t,2*L))
            group=[(Q(3*N,2),Q(0))]+[(Q(0),Q(0))]*(N-2)+[(N*x-Q(3*N,2),Q(0))]
        groups.append(group)
    return groups

def check_embedding(M,N):
    inspected=0
    for w in worlds(M):
        groups=embedding(w,N,M);p=(Q(1),Q(1,2*N))
        means=[tuple(sum(r[d] for r in g)/N for d in range(2)) for g in groups]
        assert means[0]==p
        for g in groups:
            assert len(g)==N and all(x>=0 and 0<=y<=1 for x,y in g)
        for i,g in enumerate(groups[1:],1):
            lower=tuple(v/N for v in g[0])
            assert lower[0]>p[0] or lower[1]>p[1]
            assert not(means[i][0]<=p[0] and means[i][1]<=p[1])
        pairs=[]
        for i in range(2):
            for j in range(2,4):
                q,r=means[i+1],means[j+1]
                geometric=not supported(p,[q,r]);assert geometric==(w[i]<w[j])
                if geometric:pairs.append((i,j))
        assert len(pairs)==1 and not supported(p,means[1:])
        # A table with both NW values high and both SE values low is FALSE,
        # sharing the same target/first/intermediate rows: no positive promise.
        false=embedding((2*M+3,2*M+3,1,1),N,M)
        fq=[tuple(sum(r[d] for r in g)/N for d in range(2)) for g in false[1:]]
        assert supported(p,fq)
        inspected+=1
    return inspected

def main():
    start=time.monotonic();games=[game(M) for M in [1,2,3,4,8,16,32]]
    # Test the proposed closed form; retain discrepancy rather than assuming it.
    for row in games:row['formula_matches_exact_DP']=row['optimal_expected_vertex_queries']==row['claimed_formula']
    checks=sum(check_embedding(M,N) for M in [1,2,4] for N in [2,3,6])
    result={'status':'PASS_EXACT_FINITE_BAYESIAN_DP_AND_RATIONAL_ROW_EMBEDDING',
      'games':games,'embedding_worlds_checked':checks,
      'scope':['Finite fixed-input distribution; direct exhaustive Bellman recursion, exact rational arithmetic.',
       'Stopping requires an observed strict edge, even though every prior-supported world is positive.',
       'No producer imports, external code, external data or random simulation. General asymptotic proof separate.'],
      'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'elapsed_seconds':time.monotonic()-start}
    Path(__file__).with_name('lower_shift_game_v1.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ['status','embedding_worlds_checked','elapsed_seconds']}))
    for row in games:print(row['M'],row['optimal_expected_vertex_queries'],row['claimed_formula'],row['formula_matches_exact_DP'],row['states_cached'])
if __name__=='__main__':main()
