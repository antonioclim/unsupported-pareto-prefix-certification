#!/usr/bin/env python3
"""Own R2 replay; imports only earlier own checker primitives, never a producer."""
from pathlib import Path
from fractions import Fraction as Q
import importlib.util,itertools,json,hashlib,time,collections,math,sys
sys.dont_write_bytecode=True
BASE=Path('p12/analysis');PRIMITIVE=Path('p11/analysis/check_blind_random_independent_v1.py')
spec=importlib.util.spec_from_file_location('own_r2_arithmetic',PRIMITIVE)
own=importlib.util.module_from_spec(spec);spec.loader.exec_module(own)
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def classify_sides(s):
    p=s.lower(s.target);out={'NW':[],'SE':[],'irrelevant':[]}
    for i in range(s.K):
        if i==s.target:continue
        q=s.lower(i)
        side='NW' if q[0]<p[0] and q[1]>p[1] else 'SE' if q[0]>p[0] and q[1]<p[1] else 'irrelevant'
        out[side].append(i)
    return out

def execute(rows,target,rotation,ids,slot_factory):
    s=own.State(rows,target,rotation,ids);audit={'screening':None,'sides':None,'activations':[],'mode':None,'singleton':None}
    s.finish(target,'CANDIDATE');p=s.lower(target)
    if 0 in p:audit['reason']='PURE_AXIS_ZERO';return False,s,audit
    # The own H implementation uses the same sorted first-safe-prefix rule.
    screened=s.H()
    for e in s.events:
        e['reason']='CANDIDATE' if e['reason']=='candidate' else 'SCREEN' if e['reason']=='P2' else e['reason']
    if not screened:audit['reason']='CENSUSED_DOMINATOR';return False,s,audit
    sides=classify_sides(s);audit['sides']=sides
    audit['screening']={'cost':len(s.events),'counts':s.ns[:],'lower':[[str(v) for v in s.lower(i)] for i in range(s.K)],'sides':sides}
    if s.p4():audit['reason']='P2_AND_STRICT_PAIR';return True,s,audit
    if len(sides['NW'])==1 or len(sides['SE'])==1:
        singleton_side='NW' if len(sides['NW'])==1 else 'SE'
        singleton=sides[singleton_side][0];audit.update(mode='SINGLETON',singleton=singleton)
        s.finish(singleton,'SINGLETON')
        if s.p4():audit['reason']='P2_AND_STRICT_PAIR';return True,s,audit
        opposite='SE' if singleton_side=='NW' else 'NW'
        eligible=[i for i in sides[opposite] if s.ns[i]<s.N]
        slots=slot_factory('SINGLETON',sides,eligible)
    elif sides['NW'] and sides['SE']:
        audit['mode']='ALTERNATING';slots=slot_factory('ALTERNATING',sides,None)
    else:
        audit['mode']='NO_PAIR_SIDE';slots=[]
    for side,label in slots:
        dummy=isinstance(label,int) and label<0
        audit['activations'].append({'side':side,'label':label,'dummy':dummy,'already_censused':False if dummy else s.ns[label]==s.N})
        if dummy:continue
        assert label in sides[side] and label!=target
        if s.ns[label]==s.N:continue
        s.finish(label,'SINGLETON_SEARCH' if audit['mode']=='SINGLETON' else 'ALTERNATE')
        if s.p4():audit['reason']='P2_AND_STRICT_PAIR';return True,s,audit
    for i in range(s.K):s.finish(i,'FALLBACK')
    assert not s.p4();audit['reason']='FULL_CENSUS_SUPPORTED'
    return False,s,audit


def nth_permutation(labels,rank):
    # Enumerate lexicographic permutations lazily, distinct from producer's
    # factoradic/Lehmer decoder. Native ranks <=5; APEX always rank zero.
    assert type(rank) is int and 0<=rank<math.factorial(len(labels))
    assert rank<=5 or len(labels)<=3
    return list(next(itertools.islice(itertools.permutations(labels),rank,rank+1)))

def make_slot_factory(ordinal,plan_holder):
    assert len(ordinal)==3 and ordinal[2] in [0,1]
    def slots(mode,sides,eligible):
        if mode=='SINGLETON':
            singleton_side='NW' if len(sides['NW'])==1 else 'SE';opposite='SE' if singleton_side=='NW' else 'NW'
            rank=ordinal[0 if opposite=='NW' else 1];ordered=nth_permutation(eligible,rank)
            plan_holder['plan']={'mode':'SINGLETON','singleton':sides[singleton_side][0],'opposite':opposite,'order':ordered}
            return [(opposite,i) for i in ordered]
        assert mode=='ALTERNATING' and min(len(sides['NW']),len(sides['SE']))>=2
        size=max(len(sides['NW']),len(sides['SE']));lists={}
        for side,index in [('NW',0),('SE',1)]:
            labels=sides[side]+[-1-j for j in range(size-len(sides[side]))]
            assert len(labels)==len(set(labels))==size
            lists[side]=nth_permutation(labels,ordinal[index])
        names=['NW','SE'] if ordinal[2]==0 else ['SE','NW']
        ordered=[(side,lists[side][j]) for j in range(size) for side in names]
        plan_holder['plan']={'mode':'PADDED_ALTERNATING','s':size,'lists':lists,'start':ordinal[2],'slots':[[side,i] for side,i in ordered]}
        return ordered
    return slots

def native_case_rows(case):
    rows=[[tuple(map(Q,q)) for q in g] for g in case['rows']]
    ids=[[str(i)+':'+str(j) for j in range(len(g))] for i,g in enumerate(rows)]
    assert all(x>=0 and 0<=y<=1 for g in rows for x,y in g)
    return rows,ids

def main():
    started=time.monotonic();freeze=json.loads((BASE/'FREEZE_alternating_v1.json').read_text())
    hashes={p:sha(p) for p in freeze['sha256']};assert hashes==freeze['sha256']
    resultpath=BASE/'alternating_results_v1.json';result=json.loads(resultpath.read_text());assert result['freeze']==freeze
    transcriptpath=BASE/'alternating_runs_v1.jsonl';assert sha(transcriptpath)==result['transcripts_sha256']
    fixtures=json.loads((BASE/'alternating_fixtures_v1.json').read_text())['cases'];assert len(fixtures)==32
    native={r['name']:r for r in fixtures};summaries={r['case_id']:r for r in result['cases']};assert len(summaries)==50
    # Independently verify exhaustive ensemble plans and their fixed row arrays.
    shifted=0;padded=0
    spec2=importlib.util.spec_from_file_location('own_r2_lower_embedding',Path('p12/theory/lower_shift_game_v1.py'))
    lower=importlib.util.module_from_spec(spec2);spec2.loader.exec_module(lower)
    for case in fixtures:
        if case['kind']=='NATIVE_SHIFT_COMPLETE_ENSEMBLE':
            expected=[list(p) for p in itertools.product(range(2),range(2),range(2))]
            assert case['plans']==expected;N=int(case['name'].split('_')[1][1:]);worldindex=int(case['name'].split('world')[1])
            rows,_=native_case_rows(case);assert rows==lower.embedding(lower.worlds(2)[worldindex],N,2)
            shifted+=1
        elif case['kind']=='NATIVE_PADDED_COMPLETE_ENSEMBLE':
            assert case['plans']==[list(p) for p in itertools.product(range(6),range(6),range(2))];padded+=1
        else:assert case['kind']=='NATIVE_BOUNDARY_CONTROL' and case['plans']==[[0,0,0]]
    assert shifted==24 and padded==2
    counts=collections.Counter();bycase=collections.defaultdict(list);seen=set();runs=[]
    for line in transcriptpath.open():
        run=json.loads(line);cid=run['case_id'];case=run['case'];ordinal=run['ordinal'];summary=summaries[cid]
        assert summary['case']==case
        if case['kind'].startswith('APEX'):
            rows,ids=own.load_archive(case['protocol'],case['objectives']);rotation=case['rotation'];assert ordinal==[0,0,0]
        else:
            fixed=native[case['name']];assert {k:v for k,v in fixed.items() if k not in ['rows','plans']}==case
            assert ordinal in fixed['plans'];rows,ids=native_case_rows(fixed);rotation=0
        key=(cid,tuple(ordinal));assert key not in seen;seen.add(key)
        truth=own.full_truth(rows,case['target']);assert run['truth'] is truth is summary['truth']
        holder={'plan':None};answer,state,audit=execute(rows,case['target'],rotation,ids,make_slot_factory(ordinal,holder))
        assert run['K']==state.K==summary['K'] and run['N']==state.N==summary['N']
        assert answer is truth is run['answer'] and run['reason']==audit['reason']
        assert run['screen']==audit['screening'] and run['plan']==holder['plan']
        assert run['counts']==state.ns and run['rows_revealed']==len(state.events)==len(run['transcript'])
        for event,original in zip(state.events,run['transcript']):
            checked={'configuration':event['configuration'],'trial_id':event['trial_id'],'values':event['values'],'stage':event['reason']}
            assert checked==original,(key,checked,original)
        own.check_certificate(run,state)
        counts['runs']+=1;counts['paid_events']+=len(state.events);counts['true_runs' if truth else 'false_runs']+=1;counts[run['reason']]+=1
        counts['dummy_slots_visited']+=sum(x['dummy'] for x in audit['activations'])
        counts['already_censused_slots_visited']+=sum(x['already_censused'] for x in audit['activations'])
        counts['plan_'+(holder['plan']['mode'] if holder['plan'] else 'NONE')]+=1
        bycase[cid].append((ordinal,len(state.events)))
        runs.append({'case_id':cid,'ordinal':ordinal,'rows':len(state.events),'answer':answer,'reason':run['reason']})
    assert len(seen)==result['runs']==360 and counts['paid_events']==result['paid_prefix_events']==7141
    ensembles=[]
    for cid,summary in summaries.items():
        costs=[cost for ordinal,cost in bycase[cid]];assert len(costs)==summary['runs'] and costs==summary['costs']
        case=summary['case']
        if case['kind'] in ['NATIVE_SHIFT_COMPLETE_ENSEMBLE','NATIVE_PADDED_COMPLETE_ENSEMBLE']:
            fixed=native[case['name']];assert [p for p,cost in bycase[cid]]==fixed['plans']
            E=Q(sum(costs),len(costs));assert str(E)==summary['exact_uniform_expected_rows']
            entry={'case_id':cid,'name':case['name'],'plans':len(costs),'exact_expectation':str(E)}
            if summary['truth']:
                rows,ids=native_case_rows(fixed);state=own.State(rows,case['target'],0,ids);assert state.H()
                H=len(state.events);pairs=state.pair_sets();C=H+min(sum(state.N-state.ns[i] for i in pair) for pair in pairs)
                sides=classify_sides(state);size=max(len(sides['NW']),len(sides['SE']))
                bound=Q(C)+(Q(2,3)-Q(1,12*size))*(state.K*state.N-C)
                assert summary['H']==H and summary['C_star']==C and summary['exact_bound']==str(bound) and summary['ratio_to_C_star']==str(E/C)
                assert E==bound
                entry.update(H=H,C_star=C,exact_bound=str(bound),ratio_to_C_star=str(E/C))
            ensembles.append(entry)
    # APEX exact law: RPL or late Crystal already certified at H; other Crystal
    # has a previously known singleton SE and all unfinished groups on NW.
    p10=json.loads(Path('p10/analysis/all_candidates_results_v1.json').read_text());apex=[];totalE=Q(0);totalS=0;totalU=0;vsS=collections.Counter()
    for cid,summary in summaries.items():
        case=summary['case']
        if not case['kind'].startswith('APEX'):continue
        rows,ids=own.load_archive(case['protocol'],case['objectives']);state=own.State(rows,case['target'],case['rotation'],ids);assert state.H()
        sides=classify_sides(state)
        if not state.p4():
            assert len(sides['SE'])==1 and state.ns[sides['SE'][0]]==state.N
            assert set(i for i,n in enumerate(state.ns) if n<state.N)==set(i for i in sides['NW'] if state.ns[i]<state.N)
        expected=own.exact_expectation(case,'R1');E=Q(expected['expected_rows'])
        old=next(r for r in p10['cases'] if all(r[k]==case[k] for k in ['protocol','objectives','target']))
        S=old['rows']['S'][case['rotation']];U=old['rows']['U'][case['rotation']]
        totalE+=E;totalS+=S;totalU+=U;vsS['fewer' if E<S else 'more' if E>S else 'equal']+=1
        apex.append({'case_id':cid,'case':case,'H':expected['H'],'C_star':expected['C_star'],'R2_exact_expected_rows':str(E),'R1_exact_expected_rows':str(E),'single_plan_cost':summary['costs'][0],'S':S,'U':U})
    assert len(apex)==18 and totalE==1511 and totalS==1310 and totalU==2448 and vsS['equal']==10 and vsS['more']==8 and vsS['fewer']==0
    p11check=json.loads(Path('p11/analysis/check_blind_random_independent_v1.json').read_text());assert p11check['aggregate']['R1']['expected_total']==str(totalE)
    assert {p:sha(p) for p in hashes}==hashes
    dependencies=[str(PRIMITIVE),'p12/theory/lower_shift_game_v1.py','p11/analysis/check_blind_random_independent_v1.json','p10/analysis/all_candidates_results_v1.json']
    report={'status':'PASS_INDEPENDENT_R2_360_RUNS_7141_EVENTS_AND_26_COMPLETE_ENSEMBLES','counts':dict(counts),
      'frozen_inputs_unchanged':True,'cases':len(summaries),'mismatches':0,'native_exact_ensembles':ensembles,'all_run_summaries':runs,
      'APEX_exact_law':{'cases':18,'R2_expected_total':str(totalE),'R1_expected_total':str(totalE),'S_total':totalS,'U_total':totalU,'vs_S':{k:vsS[k] for k in ['fewer','equal','more']},'cases_detail':apex},
      'input_and_source_sha256':{**hashes,**{p:sha(p) for p in dependencies},str(resultpath):sha(resultpath),str(transcriptpath):sha(transcriptpath),__file__:sha(__file__)},
      'elapsed_seconds':time.monotonic()-started,'scope':[
      'No producer module imported. Own P11 parser/state/root-support/certificate checker and own P12 lower embedding reused without modification.',
      'Every paid event, stage, value, trial ID, fixed-prefix order, screen, side partition, ordinal plan, dummy skip, counts and terminal certificate reproduced.',
      'Permutation orders independently enumerated lazily, not producer factoradic decoding. Native complete2x2 and padded2x3 ensembles contain each permutation/start plan once.',
      'Only full8/72-plan native ensembles supply exact expectations. The18 APEX single-plan runs are correctness controls, not random samples or expectation estimates.',
      'R2 equals R1 exact law on these already-known APEX cases only:1511 versus S1310, with8worse and10ties retained.',
      'No Monte Carlo, new physical data, held-out inference, bounded-cost theorem transfer, generalK>=6 optimum or empirical-improvement claim.']}
    (BASE/'check_alternating_independent_v1.json').write_text(json.dumps(report,indent=2)+'\n')
    (BASE/'check_alternating_independent_v1.txt').write_text('PASS independent R2 replay:360runs,7141paid events,26complete native ensembles,18APEX controls.\n'+json.dumps({'counts':dict(counts),'APEX_R2_exact_expected_total':str(totalE),'S_total':totalS,'U_total':totalU,'vs_S':dict(vsS)},indent=2)+'\nAll frozen hashes unchanged; no producer imports. APEX single plans are not expectation estimates.\n')
    print(json.dumps({k:report[k] for k in ['status','counts','APEX_exact_law','elapsed_seconds']},indent=2))
if __name__=='__main__':main()
