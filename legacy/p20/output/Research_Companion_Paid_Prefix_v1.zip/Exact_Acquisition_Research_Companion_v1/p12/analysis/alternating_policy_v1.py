#!/usr/bin/env python3
"""Own blind R2 policy. Exact native evaluation; see frozen protocol."""
from fractions import Fraction as Q
from pathlib import Path
import hashlib,itertools,json,math,secrets,sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT/'p9/analysis'))
import finite_reveal_v1 as geometry

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dom(a,b):return all(x<=y for x,y in zip(a,b)) and any(x<y for x,y in zip(a,b))

def permutation_at(labels,rank):
    remaining=list(labels);result=[]
    assert 0<=rank<math.factorial(len(remaining))
    while remaining:
        unit=math.factorial(len(remaining)-1);i,rank=divmod(rank,unit)
        result.append(remaining.pop(i))
    return result

class OrdinalDraw:
    def __init__(self,plan):self.plan=plan
    def permute(self,labels,side):return permutation_at(labels,self.plan[0 if side=='NW' else 1])
    def bit(self):return self.plan[2]

class UniformDraw:
    """Standard unbiased integer draws; the theorem uses their ideal uniform law."""
    def permute(self,labels,side):
        labels=list(labels)
        for j in range(len(labels)-1,0,-1):
            i=secrets.randbelow(j+1);labels[j],labels[i]=labels[i],labels[j]
        return labels
    def bit(self):return secrets.randbelow(2)

def r2(K,N,target,reveal,draw=None):
    """Only reveal(i,n) accesses archived row values. Other inputs are public."""
    draw=UniformDraw() if draw is None else draw
    ns=[0]*K;sums=[[Q(),Q()] for _ in range(K)];events=[]
    competitors=[i for i in range(K) if i!=target]
    screen=None;plan=None
    def lo(i):return tuple(s/N for s in sums[i])
    def take(i,stage):
        assert ns[i]<N
        label,values=reveal(i,ns[i]);values=tuple(Q(v) for v in values)
        assert values[0]>=0 and 0<=values[1]<=1
        ns[i]+=1;sums[i]=[s+v for s,v in zip(sums[i],values)]
        events.append({'configuration':i,'trial_id':label,'values':list(map(str,values)),'stage':stage})
    def finish(i,stage):
        while ns[i]<N:take(i,stage)
    def witness():
        return geometry.strict_mix([(i,tuple(lo(i)[j]-p[j] for j in range(2))) for i in competitors if ns[i]==N])
    def answer(value,reason,certificate=None):
        return {'answer':value,'reason':reason,'certificate':certificate,'rows_revealed':len(events),'counts':ns,'screen':screen,'plan':plan,'transcript':events}
    finish(target,'CANDIDATE');p=lo(target)
    if p[0]==0 or p[1]==0:return answer(False,'PURE_AXIS_ZERO',{'axis':0 if p[0]==0 else 1})
    for i in competitors:
        while dom(lo(i),p) and ns[i]<N:take(i,'SCREEN')
        if dom(lo(i),p):return answer(False,'CENSUSED_DOMINATOR',{'index':i})
    sides={'NW':[],'SE':[],'irrelevant':[]}
    for i in competitors:
        x,y=lo(i)
        z='NW' if x<p[0] and y>p[1] else 'SE' if x>p[0] and y<p[1] else 'irrelevant'
        sides[z].append(i)
    screen={'cost':len(events),'counts':list(ns),'lower':[list(map(str,lo(i))) for i in range(K)],'sides':sides}
    w=witness()
    if w:return answer(True,'P2_AND_STRICT_PAIR',w)
    if len(sides['NW'])==1 or len(sides['SE'])==1:
        side='NW' if len(sides['NW'])==1 else 'SE';singleton=sides[side][0]
        finish(singleton,'SINGLETON')
        w=witness()
        if w:return answer(True,'P2_AND_STRICT_PAIR',w)
        other='SE' if side=='NW' else 'NW'
        order=draw.permute([i for i in sides[other] if ns[i]<N],other)
        plan={'mode':'SINGLETON','singleton':singleton,'opposite':other,'order':order}
        for i in order:
            finish(i,'SINGLETON_SEARCH');w=witness()
            if w:return answer(True,'P2_AND_STRICT_PAIR',w)
    elif sides['NW'] and sides['SE']:
        s=max(len(sides['NW']),len(sides['SE']));lists={}
        for side in ('NW','SE'):
            padded=sides[side]+[-j-1 for j in range(s-len(sides[side]))]
            lists[side]=draw.permute(padded,side)
        bit=draw.bit();assert bit in (0,1)
        names=('NW','SE') if bit==0 else ('SE','NW')
        order=[(side,lists[side][j]) for j in range(s) for side in names]
        plan={'mode':'PADDED_ALTERNATING','s':s,'lists':lists,'start':bit,'slots':order}
        for side,i in order:
            if i<0 or ns[i]==N:continue
            finish(i,'ALTERNATE');w=witness()
            if w:return answer(True,'P2_AND_STRICT_PAIR',w)
    for i in competitors:finish(i,'FALLBACK')
    assert not witness()
    return answer(False,'FULL_CENSUS_SUPPORTED')

def grade(K,N,target,reveal):
    points=[tuple(sum((reveal(i,n)[1][j] for n in range(N)),Q())/N for j in range(2)) for i in range(K)]
    p=points[target];others=[i for i in range(K) if i!=target]
    return not any(dom(points[i],p) for i in others) and geometry.interval([tuple(points[i][j]-p[j] for j in range(2)) for i in others]) is None

def main():
    freeze=json.loads((HERE/'FREEZE_alternating_v1.json').read_text())
    assert all(sha(ROOT/p)==h for p,h in freeze['sha256'].items())
    fixtures=json.loads((HERE/'alternating_fixtures_v1.json').read_text())['cases']
    archives={p:geometry.Archive(ROOT/'p9/licence/apex_dataset'/f'{p}_results.json') for p in geometry.EXPECTED}
    cases=list(fixtures)
    for protocol,names,target in [('Crystal',['energy','failure'],11),('Crystal',['latency','failure'],11),('RPL',['latency','failure'],21)]:
        for rotation in range(6):cases.append({'kind':'APEX_KNOWN_POSITIVE_CONTROL','name':f'{protocol}_{names[0]}_{rotation}','protocol':protocol,'objectives':names,'target':target,'rotation':rotation,'plans':[[0,0,0]]})
    summaries=[];nruns=events=0
    with (HERE/'alternating_runs_v1.jsonl').open('x') as out:
        for cid,c in enumerate(cases):
            if c['kind'].startswith('APEX'):
                a=archives[c['protocol']];K,N=len(a.keys),6
                def reveal(i,n):return a.reveal(i,n,c['rotation'],c['objectives'])
            else:
                rows=c['rows'];K,N=len(rows),len(rows[0])
                def reveal(i,n):return f'{i}:{n}',tuple(Q(v) for v in rows[i][n])
            truth=grade(K,N,c['target'],reveal);costs=[]
            if c['kind'].startswith('APEX'):assert truth
            for ordinal in c['plans']:
                r=r2(K,N,c['target'],reveal,OrdinalDraw(ordinal));assert r['answer']==truth
                row={'case_id':cid,'case':{k:v for k,v in c.items() if k not in ('rows','plans')},'K':K,'N':N,'truth':truth,'ordinal':ordinal}|r
                out.write(json.dumps(row,separators=(',',':'))+'\n');nruns+=1;events+=r['rows_revealed'];costs.append(r['rows_revealed'])
            summary={'case_id':cid,'case':{k:v for k,v in c.items() if k not in ('rows','plans')},'K':K,'N':N,'truth':truth,'runs':len(costs),'costs':costs}
            if c['kind'] in ('NATIVE_SHIFT_COMPLETE_ENSEMBLE','NATIVE_PADDED_COMPLETE_ENSEMBLE'):
                E=Q(sum(costs),len(costs));summary['exact_uniform_expected_rows']=str(E)
                if truth:
                    H=N+K-1;C=H+2*(N-1);s=2 if K==5 else 3
                    bound=Q(C)+(Q(2,3)-Q(1,12*s))*(K*N-C)
                    assert E==bound
                    summary.update(H=H,C_star=C,exact_bound=str(bound),ratio_to_C_star=str(E/C))
            summaries.append(summary)
    assert len(cases)==50 and nruns==360
    result={'status':'PASS_R2_PRODUCER_FROZEN_INPUTS_AND_NATIVE_TRUTH','date':'2026-10-22','runs':nruns,'paid_prefix_events':events,'cases':summaries,'freeze':freeze,'transcripts_sha256':sha(HERE/'alternating_runs_v1.jsonl'),'limits':['Native proof fixtures and already-seen APEX controls','Only full finite plan ensembles give exact expectations','No Monte Carlo or physical/statistical inference','GeneralK>=6 optimum not established','Bounded-cost extension is a separate model']}
    assert all(sha(ROOT/p)==h for p,h in freeze['sha256'].items())
    (HERE/'alternating_results_v1.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ('status','runs','paid_prefix_events')},indent=2))

if __name__=='__main__':main()
