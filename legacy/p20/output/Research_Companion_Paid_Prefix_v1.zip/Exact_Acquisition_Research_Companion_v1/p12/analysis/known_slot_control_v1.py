#!/usr/bin/env python3
"""Additional frozen native control for already-censused alternating slots.

Runs the frozen producer and the independently written replayer separately;
does not change either implementation or the original 360-run cohort.
"""
from pathlib import Path
from fractions import Fraction as Q
import hashlib,itertools,json,sys
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(HERE))
import alternating_policy_v1 as producer
import check_alternating_independent_v1 as checker

ROWS=[[[1,'1/4'],[1,'1/4']],[[0,0],[0,1]],[[0,1],[0,1]],[[3,0],[0,0]],[[3,0],[3,0]]]

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    freeze=json.loads((HERE/'FREEZE_known_slot_v1.json').read_text())
    assert all(sha(ROOT/p)==h for p,h in freeze['sha256'].items())
    rows,ids=checker.native_case_rows({'rows':ROWS})
    def reveal(i,n):return ids[i][n],rows[i][n]
    runs=[];known=0
    for ordinal in itertools.product(range(2),range(2),range(2)):
        ordinal=list(ordinal)
        r=producer.r2(5,2,0,reveal,producer.OrdinalDraw(ordinal))
        holder={'plan':None};answer,state,audit=checker.execute(rows,0,0,ids,checker.make_slot_factory(ordinal,holder))
        assert answer is True is r['answer']
        assert r['screen']==audit['screening'] and r['plan']==holder['plan']
        assert r['counts']==state.ns and r['reason']==audit['reason']
        assert r['rows_revealed']==len(state.events)
        for event,original in zip(state.events,r['transcript']):
            assert {'configuration':event['configuration'],'trial_id':event['trial_id'],'values':event['values'],'stage':event['reason']}==original
        checker.own.check_certificate(r,state)
        nknown=sum(v['already_censused'] for v in audit['activations']);known+=nknown
        runs.append({'ordinal':ordinal,'known_slots_skipped':nknown,**r})
    assert known>0 and all(r['screen']['counts']==[2,2,1,1,1] for r in runs)
    E=Q(sum(r['rows_revealed'] for r in runs),len(runs));assert E==9
    assert all(sha(ROOT/p)==h for p,h in freeze['sha256'].items())
    result={'status':'PASS_KNOWN_WITNESS_ZERO_COST_SLOT_END_TO_END','rows':ROWS,'runs':runs,'run_count':8,'paid_events':sum(r['rows_revealed'] for r in runs),'known_slots_skipped':known,'H':7,'C_star':8,'T':10,'exact_uniform_expected_rows':str(E),'one_unfinished_witness_half_bound':'9','freeze':freeze,'scope':'Additional native coverage after the frozen360-run cohort; same unchanged producer and independently written replayer; no random simulation or physical data'}
    (HERE/'known_slot_control_results_v1.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ('status','run_count','paid_events','known_slots_skipped','exact_uniform_expected_rows')}))

if __name__=='__main__':main()
