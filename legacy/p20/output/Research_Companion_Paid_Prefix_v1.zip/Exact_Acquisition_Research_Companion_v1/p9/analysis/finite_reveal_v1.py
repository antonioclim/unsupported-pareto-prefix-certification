#!/usr/bin/env python3
"""Own finite-table deterministic reveal demonstration; see frozen protocol."""
import argparse
from collections import defaultdict
from fractions import Fraction as Q
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
CASES = [('Crystal','energy','failure',11), ('Crystal','latency','failure',11),
         ('RPL','latency','failure',21), ('Crystal','energy','latency',0),
         ('RPL','energy','failure',0), ('RPL','energy','latency',0)]
EXPECTED = {'Crystal':'bc2c652f89a70d0723aec19cae1f2dba6d2b56523d5c0b54805520a8de072711',
            'RPL':'c987d6583288e157139f8d6b0253c2adb91abee7642eee28fcf99db311f8f746'}

def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def interval(diffs):
    lo, hi = Q(0), Q(1)
    for x,y in diffs:
        a = x-y
        if a > 0: lo = max(lo, -y/a)
        elif a < 0: hi = min(hi, -y/a)
        elif y < 0: return None
    return (lo, hi) if lo <= hi else None

def strict_mix(points):
    for i,(x,y) in points:
        if x < 0 and y < 0:
            return {'indices':[i], 'weights':['1'], 'gaps':[str(x),str(y)]}
    for pos,(i,(x,y)) in enumerate(points):
        for j,(u,v) in points[pos+1:]:
            lo, hi = Q(0),Q(1)
            for a,b in ((x,u),(y,v)):
                if a > b: hi=min(hi, -b/(a-b))
                elif a < b: lo=max(lo, -b/(a-b))
                elif b >= 0: lo,hi=Q(1),Q(0)
            if lo < hi:
                q=(lo+hi)/2; z=(q*x+(1-q)*u,q*y+(1-q)*v)
                if all(t<0 for t in z):
                    return {'indices':[i,j], 'weights':[str(q),str(1-q)], 'gaps':list(map(str,z))}
    return None

def dominates(a,b):
    return all(x<=y for x,y in zip(a,b)) and any(x<y for x,y in zip(a,b))

def check(bounds,target):
    low, high = bounds[target]
    others=[i for i in range(len(bounds)) if i!=target]
    p2=None; p4=None; detail={}
    safe=[]
    for i in others:
        l,u=bounds[i]
        safe.append(any(h is not None and t>h for t,h in zip(l,high)) or
                    all(h is not None and t==h for t,h in zip(l,high)))
        if all(t is not None for t in u) and dominates(u,low):
            p2=False; detail['P2_dominator']=i
    if p2 is None and all(safe): p2=True
    points=[(i,tuple(bounds[i][1][j]-low[j] for j in range(2))) for i in others
            if all(t is not None for t in bounds[i][1])]
    if points and interval([p for _,p in points]) is None:
        w=strict_mix(points); assert w is not None
        p4=True; detail['P4_mixture']=w
    if all(t is not None for t in high):
        ss=interval([tuple(bounds[i][0][j]-high[j] for j in range(2)) for i in others])
        if ss is not None:
            assert p4 is not True
            p4=False; detail['P4_support_weight_interval']=list(map(str,ss))
    if p4 is None:
        for j in range(2):
            if high[j] is not None and all(bounds[i][0][j]>=high[j] for i in others):
                p4=False; detail['P4_support_weight_interval']=['1','1'] if j==0 else ['0','0'];break
    decision=True if p2 is True and p4 is True else False if p2 is False or p4 is False else None
    return decision,p2,p4,detail

class Archive:
    def __init__(self,path):
        raw=json.loads(path.read_text(),parse_float=Q)
        grouped=defaultdict(list)
        for r in raw: grouped[tuple(sorted(r['params'].items()))].append(r)
        self.keys=sorted(grouped)
        self.rows=[sorted(grouped[k],key=lambda r:r['id']) for k in self.keys]
        assert all(len(r)==6 for r in self.rows)
        assert len({r['id'] for rs in self.rows for r in rs})==len(raw)
        for rs in self.rows:
            for r in rs:
                m=r['metrics']; assert 0<=m['reliability']<=1 and m['energy']>=0 and m['latency']>=0

    def reveal(self,i,n,rotation,names):
        r=self.rows[i][(n+rotation)%6];m=r['metrics']
        value=tuple(1-Q(m['reliability']) if k=='failure' else Q(m[k]) for k in names)
        return r['id'],value

    def grade(self,names,target):
        means=[tuple(sum(self.reveal(i,n,0,names)[1][j] for n in range(6))/6 for j in range(2))
               for i in range(len(self.keys))]
        p2=not any(dominates(m,means[target]) for i,m in enumerate(means) if i!=target)
        p4=interval([tuple(m[j]-means[target][j] for j in range(2)) for i,m in enumerate(means) if i!=target]) is None
        return {'P2':p2,'P4':p4,'GOOD':p2 and p4}

def run(archive,names,target,rotation,method):
    k=len(archive.keys); ns=[0]*k; sums=[[Q(0),Q(0)] for _ in range(k)]; transcript=[]
    schedule=([target]*6 if method=='T' else [])
    schedule += [i for _ in range(6) for i in range(k) if method!='T' or i!=target]
    for i in schedule:
        trial,values=archive.reveal(i,ns[i],rotation,names)
        ns[i]+=1; sums[i]=[s+v for s,v in zip(sums[i],values)]
        transcript.append({'configuration':i,'trial_id':trial,'values':list(map(str,values))})
        bounds=[]
        for t in range(k):
            lo=tuple(s/6 for s in sums[t])
            hi=tuple(s/6 if ns[t]==6 else (s+6-ns[t])/6 if name=='failure' else None
                     for s,name in zip(sums[t],names))
            bounds.append((lo,hi))
        answer,p2,p4,cert=check(bounds,target)
        if answer is not None:
            return {'method':method,'rotation':rotation,'rows_revealed':len(transcript),'census_rows':6*k,
                    'answer':answer,'P2':p2,'P4':p4,'counts':ns,'certificate':cert,'transcript':transcript}
    raise AssertionError('No Boolean answer at census')

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--data-dir',type=Path,required=True);parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();code_hash=digest(Path(__file__));protocol_hash=digest(HERE/'PROTOCOL_v1.txt')
    archives={};inputs={}
    for name,sha in EXPECTED.items():
        path=args.data_dir/(name+'_results.json'); assert digest(path)==sha
        archives[name]=Archive(path);inputs[name]={'sha256':sha,'bytes':path.stat().st_size}
    results=[]
    for protocol,a,b,target in CASES:
        archive=archives[protocol];truth=archive.grade((a,b),target);runs=[]
        for rotation in range(6):
            for method in ('U','T'):
                r=run(archive,(a,b),target,rotation,method);assert r['answer']==truth['GOOD'];runs.append(r)
        results.append({'protocol':protocol,'objectives':[a,b],'target':target,'truth':truth,'runs':runs})
    assert digest(Path(__file__))==code_hash and digest(HERE/'PROTOCOL_v1.txt')==protocol_hash
    for name,sha in EXPECTED.items():assert digest(args.data_dir/(name+'_results.json'))==sha
    summary=[]
    for c in results:
        rows={m:[r['rows_revealed'] for r in c['runs'] if r['method']==m] for m in ('U','T')}
        summary.append({k:v for k,v in c.items() if k!='runs'}|{'rows':rows,
            'T_vs_U':{'fewer':sum(a<b for a,b in zip(rows['T'],rows['U'])),
                       'equal':sum(a==b for a,b in zip(rows['T'],rows['U'])),
                       'more':sum(a>b for a,b in zip(rows['T'],rows['U']))}})
    result={'status':'PASS_PRODUCER_GRADING_AND_FROZEN_HASHES','scope':'Exploratory deterministic finite-archive Boolean certification; fixed schedules; not live or population inference',
            'code_sha256':code_hash,'protocol_sha256':protocol_hash,'inputs':inputs,'runs':72,'summary':summary,'cases':results}
    args.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'summary':summary},indent=2))

if __name__=='__main__':main()
