#!/usr/bin/env python3
"""Own exhaustive raw-row grid check of proposed K=3,N=2 optimal policy.

Each coordinate is 0,1/2,1. Integers below represent four times each mean.
Every one of the 9^6 complete tables is visited. No sampling/tolerances.
"""
import hashlib
import itertools
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
ROWS=tuple(itertools.product(range(3),repeat=2))
GROUPS=tuple((r,s) for r in ROWS for s in ROWS)


def dom(u,v):
    return u[0]<=v[0] and u[1]<=v[1] and u!=v


def true_state(ls,us,ns):
    la,ua=ls[0][ns[0]],us[0][ns[0]]
    if any(dom(ls[g][ns[g]],ua) for g in (1,2)): return False
    u,v=us[1][ns[1]],us[2][ns[2]]
    d,e=(u[0]-la[0],u[1]-la[1]),(v[0]-la[0],v[1]-la[1])
    if d[0]>0 and d[1]<0: d,e=e,d
    return d[0]<0 and d[1]>0 and e[0]>0 and e[1]<0 and (-d[0])*(-e[1])>d[1]*e[0]


def main():
    arrays=[]
    for r,s in GROUPS:
        total=(r[0]+s[0],r[1]+s[1])
        arrays.append((((0,0),r,total),((4,4),(r[0]+2,r[1]+2),total)))
    tables=true_tables=checked_prefixes=0
    histogram={}
    examples={}
    for groups in itertools.product(range(len(GROUPS)),repeat=3):
        tables+=1
        ls=[arrays[g][0] for g in groups]
        us=[arrays[g][1] for g in groups]
        if not true_state(ls,us,(2,2,2)): continue
        true_tables+=1
        minimum=7
        for ns in itertools.product(range(3),repeat=3):
            checked_prefixes+=1
            if true_state(ls,us,ns): minimum=min(minimum,sum(ns))
        assert minimum in (5,6)
        ns=[2,1,1]
        p=ls[0][2]
        # Mandatory P2 acquisition, then sound TRUE test; census fallback.
        for g in (1,2):
            if dom(ls[g][1],p): ns[g]=2
        if not true_state(ls,us,ns):
            for g in (1,2):
                if ns[g]==1:
                    ns[g]=2
                    if true_state(ls,us,ns): break
        assert true_state(ls,us,ns)
        assert sum(ns)==minimum
        histogram[str(minimum)]=histogram.get(str(minimum),0)+1
        if str(minimum) not in examples:
            examples[str(minimum)]={"rows_half_units":[GROUPS[g] for g in groups],"policy_final_prefixes":ns}
    out={"source_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
         "raw_row_coordinate_grid":["0","1/2","1"],"tables":tables,
         "TRUE_tables":true_tables,"all_prefix_states_checked_on_TRUE_tables":checked_prefixes,
         "comparator_histogram":histogram,"examples":examples,"all_pass":True,
         "scope":"Finite exhaustive fixture; general K3,N2 statement requires analytic proof."}
    (ROOT/'lower_k3n2_check_v1.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k!='examples'},indent=2))


if __name__=='__main__': main()
