#!/usr/bin/env python3
"""Targeted exact N2 dichotomy checks, including the cheap certificate branch."""
import hashlib
import importlib.util
import itertools
import json
from fractions import Fraction as F
from pathlib import Path

ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent.parent
HELPER=ROOT/'lower_bounded_check_v1.py'
spec=importlib.util.spec_from_file_location('p14_own_lower_helper',HELPER)
helper=importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)


def input_cases():
    cases=[]
    for name in ('p13/theory/bounded_comparator_independent_fixtures_v1.json',
                 'p14/analysis/bounded_bridge_fixtures_v1.json'):
        source=BASE/name
        data=json.loads(source.read_text())
        for case in data['cases']:
            if len(case['rows'][0]) != 2: continue
            B=F(case['B'])
            table=[tuple((F(c)/B,F(f)) for c,f in group) for group in case['rows']]
            target=case.get('target',0)
            table=[table[target]]+table[:target]+table[target+1:]
            cases.append((name+':'+case['id'],table))
    for K in range(3,9):
        p=(F(1,4),F(15,16))
        table=[(p,p),((F(0),F(1)),)*2,
               ((F(3,4),F(0)),(F(1),F(1)))]+[((F(1),F(1)),)*2]*(K-3)
        cases.append(('own_sharp_cost5plus_K'+str(K),table))
        cases.append(('own_sharp_swapped_K'+str(K),[tuple((f,c) for c,f in group) for group in table]))
    for m,n in ((1,1),(1,2),(1,3),(2,2),(2,3)):
        k=m+n
        for kind in ('consecutive','powers_two'):
            ts=tuple(helper.phi(F(q+1 if kind=='consecutive' else 2**q),2) for q in range(k))
            left,right=(ts[n-1],)+ts[n+1:],ts[:n-1]+(ts[n],)
            for index,(l,r) in enumerate(itertools.product(itertools.permutations(left),itertools.permutations(right))):
                p=(F(1,4),F(1,4))
                table=[(p,p)]+[helper.hard_rows('L' if q<m else 'R',t,2) for q,t in enumerate(l+r)]
                cases.append((f'scaled_hard_{m}_{n}_{kind}_{index}',table))
    return cases


def check_case(name,table):
    K=len(table)
    ls,us=helper.arrays(table)
    positive=helper.state_true(ls,us,(2,)*K)
    if not positive:
        return {'id':name,'TRUE':False,'scope':'FALSE control retained; no positive ratio evaluated'}
    p=ls[0][2]
    h=[2]
    for g in range(1,K):
        li=ls[g][1]
        unsafe=li[0]<=p[0] and li[1]<=p[1] and li!=p
        h.append(2 if unsafe else 1)
    H=sum(h)
    Htrue=helper.state_true(ls,us,h)
    cb,states=helper.exhaustive_min(table)
    pair_costs=[]
    for i in range(1,K):
        for j in range(i+1,K):
            points=[p,ls[i][2],ls[j][2]]
            if helper.true_corners(points,points):
                pair_costs.append(H+2-h[i]+2-h[j])
    assert pair_costs
    cu=min(pair_costs)
    if Htrue: assert cb==H
    else: assert cb==cu and cb>=K+3
    # For K3 the simple screen/census policy must achieve exact C*_B.
    policy_cost=None
    if K==3:
        ns=list(h)
        if not helper.state_true(ls,us,ns):
            for g in (1,2):
                if ns[g]==1:
                    ns[g]=2
                    if helper.state_true(ls,us,ns): break
        policy_cost=sum(ns)
        assert policy_cost==cb
    return {'id':name,'TRUE':True,'K':K,'H':H,'screen_TRUE':Htrue,
            'C_B':cb,'C_U':cu,'prefix_states':states,'K3_policy_cost':policy_cost}


def main():
    cases=[check_case(name,table) for name,table in input_cases()]
    pos=[x for x in cases if x['TRUE']]
    result={'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'cases':cases,'case_count':len(cases),'TRUE_cases':len(pos),
            'FALSE_controls':len(cases)-len(pos),
            'screen_TRUE_branch_cases':sum(x['screen_TRUE'] for x in pos),
            'screen_not_TRUE_branch_cases':sum(not x['screen_TRUE'] for x in pos),
            'sum_exhaustive_prefix_states':sum(x['prefix_states'] for x in pos),
            'cheap_K3_comparator5_cases':sum(x['K']==3 and x['C_B']==5 for x in pos),
            'all_pass':True,'scope':'Targeted finite support for analytic N2 dichotomy; not universal theorem by enumeration.'}
    (ROOT/'lower_n2_dichotomy_check_v1.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='cases'},indent=2))


if __name__=='__main__': main()
