#!/usr/bin/env python3
"""Exact confirmation after explicitly recorded exploratory discovery.
Independent interval robust test, all prefix states, finite Bayes Bellman.
"""
import hashlib
import itertools
import json
from fractions import Fraction as F
from functools import lru_cache
from pathlib import Path

ROOT=Path(__file__).resolve().parent


def bounds(table,ns):
    low=[];up=[]
    for group,n in zip(table,ns):
        point=tuple(sum(row[d] for row in group[:n])/3 for d in (0,1))
        low.append(point)
        up.append(tuple(v+F(3-n,3) for v in point))
    return low,up


def robust_true(table,ns):
    low,up=bounds(table,ns)
    for p in low[1:]:
        if p[0]<=up[0][0] and p[1]<=up[0][1] and p!=up[0]: return False
    lo,hi=F(0),F(1)
    for p in up[1:]:
        dx,dy=p[0]-low[0][0],p[1]-low[0][1]
        c=dx-dy
        if c>0: lo=max(lo,-dy/c)
        elif c<0: hi=min(hi,-dy/c)
        elif dy<0: return True
    return lo>hi


def main():
    fixture_path=ROOT/'lower_k3n3_fixtures_v1.json'
    data=json.loads(fixture_path.read_text())
    worlds=[tuple(tuple(tuple(F(v) for v in row) for row in group) for group in world['rows'])
            for world in data['worlds']]
    summaries=[]
    for source,table in zip(data['worlds'],worlds):
        assert all(0<=v<=1 for group in table for row in group for v in row)
        states=[ns for ns in itertools.product(range(4),repeat=3) if robust_true(table,ns)]
        minimum=min(map(sum,states))
        minimizers=[list(ns) for ns in states if sum(ns)==minimum]
        assert minimum==source['expected_C_B']
        assert minimizers==source['expected_minimum_prefixes']
        summaries.append({'id':source['id'],'C_B':minimum,'minimum_prefixes':minimizers,
                          'all_TRUE_prefixes':[list(ns) for ns in states]})

    @lru_cache(None)
    def V(ns,ids):
        representative=worlds[ids[0]]
        if robust_true(representative,ns): return F(0)
        actions=[]
        for g in range(3):
            if ns[g]==3: continue
            buckets={}
            for wid in ids:
                row=worlds[wid][g][ns[g]]
                buckets.setdefault(row,[]).append(wid)
            next_ns=tuple(n+(q==g) for q,n in enumerate(ns))
            actions.append(1+sum(F(len(bucket),len(ids))*V(next_ns,tuple(bucket))
                                 for bucket in buckets.values()))
        assert actions
        return min(actions)

    optimum=V((0,0,0),(0,1))
    assert optimum==F(data['expected_uniform_Bayes_cost'])
    result={'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'fixture_sha256':hashlib.sha256(fixture_path.read_bytes()).hexdigest(),
            'discovery_provenance':data['discovery_provenance'],
            'worlds':summaries,'prefix_states_enumerated':128,
            'uniform_Bayes_optimum':str(optimum),'Bellman_states':V.cache_info().currsize,
            'randomised_full_problem_ratio_lower':'17/16',
            'deterministic_full_problem_ratio_lower':'9/8','all_pass':True,
            'scope':'Exact finite lower; full bounded finite-K minimax remains unknown.'}
    (ROOT/'lower_k3n3_check_v1.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__': main()
