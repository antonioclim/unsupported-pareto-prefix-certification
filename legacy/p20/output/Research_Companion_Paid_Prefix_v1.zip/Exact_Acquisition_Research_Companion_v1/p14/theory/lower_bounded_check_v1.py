#!/usr/bin/env python3
"""Own native exact fixtures for the bounded-domain lower report."""
import hashlib
import itertools
import json
from fractions import Fraction as F
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def true_corners(lower, upper):
    pa, ua = lower[0], upper[0]
    for li in lower[1:]:
        if li[0] <= ua[0] and li[1] <= ua[1] and li != ua:
            return False
    lo, hi = F(0), F(1)
    for ui in upper[1:]:
        dx, dy = ui[0]-pa[0], ui[1]-pa[1]
        c = dx-dy
        if c == 0:
            if dy < 0:
                return True
        elif c > 0:
            lo = max(lo, -dy/c)
        else:
            hi = min(hi, -dy/c)
    return lo > hi


def arrays(table):
    N = len(table[0])
    ls, us = [], []
    for group in table:
        sums = [(F(0), F(0))]
        for row in group:
            assert all(0 <= v <= 1 for v in row)
            sums.append(tuple(sums[-1][d]+row[d] for d in (0, 1)))
        lower = [tuple(v/N for v in s) for s in sums]
        upper = [tuple(v+F(N-n, N) for v in lower[n]) for n in range(N+1)]
        ls.append(lower)
        us.append(upper)
    return ls, us


def state_true(ls, us, state):
    return true_corners([ls[g][n] for g, n in enumerate(state)],
                        [us[g][n] for g, n in enumerate(state)])


def exhaustive_min(table):
    ls, us = arrays(table)
    N, K = len(table[0]), len(table)
    best = K*N+1
    states = 0
    for ns in itertools.product(range(N+1), repeat=K):
        states += 1
        if sum(ns) < best and state_true(ls, us, ns):
            best = sum(ns)
    return best, states


def triple_checks():
    feasible = infeasible = 0
    fixed_a_checks = 0
    for N in range(1, 13):
        for a in range(1, N+1):
            best = None
            for i in range(1, N+1):
                for j in range(1, N+1):
                    condition = (2*N-a)*(i+j) < i*i+i*j+j*j
                    if not condition:
                        infeasible += 1
                        continue
                    feasible += 1
                    best = min(best if best is not None else i+j, i+j)
                    ta, ti, tj = F(N-a, N), F(N-i, N), F(N-j, N)
                    low = (ta+tj)/(1-ti)
                    high = 1-(ta+ti)/(1-tj)
                    lam = (low+high)/2
                    xb, yb = 1-tj-ta, 1-ti-ta
                    gx = xb-(lam*ti+(1-lam)*(xb+ta+tj))
                    gy = yb-(lam*(yb+ta+ti)+(1-lam)*tj)
                    eps = min(xb, yb, gx, gy)/4
                    assert eps > 0 and 0 < lam < 1
                    x, y = xb-eps, yb-eps
                    lower = [(x,y), (F(0),y+ta+eps/2), (x+ta+eps/2,F(0))]
                    upper = [tuple(v+ta for v in lower[0]),
                             tuple(v+ti for v in lower[1]),
                             tuple(v+tj for v in lower[2])]
                    assert true_corners(lower, upper)
                    for count, point in zip((a, i, j), lower):
                        assert all(0 <= c <= F(count, N) for c in point)
                    assert 2*a+i+j > 3*N
            d = N-a
            rs = [r for r in range(1, N+1) if r*r > d*(N+r)]
            target = N+min(rs) if rs else None
            assert best == target
            assert (best is not None) == (2*a > N)
            fixed_a_checks += 1
    return {"constructive_feasible_triples": feasible,
            "analytically_infeasible_count_triples_not_numerically_searched": infeasible,
            "fixed_candidate_prefix_minimum_count_checks": fixed_a_checks,
            "scope": "Checks constructive sufficiency and count algebra; universal necessity rests on proof."}


def sharp_min_checks():
    all_cases, exhaustive = [], []
    for N in range(1, 13):
        for K in range(3, 9):
            p = (F(1,2*N),1-F(1,4*N*N))
            table = [(p,)*N, ((F(0),F(1)),)*N,
                     ((F(3,4),F(0)),)+((F(1),F(1)),)*(N-1)]
            table += [((F(1),F(1)),)*N]*(K-3)
            ls, us = arrays(table)
            state = (N,N)+(1,)*(K-2)
            assert state_true(ls,us,state)
            assert sum(state) == K+2*N-2
            all_cases.append({"N":N,"K":K,"certificate_cost":sum(state)})
            if N <= 4 and K <= 4:
                minimum, count = exhaustive_min(table)
                assert minimum == K+2*N-2
                exhaustive.append({"N":N,"K":K,"minimum":minimum,"states":count})
    return {"explicit_certificate_cases":all_cases,"exhaustive_minimum_cases":exhaustive}


def phi(z,N):
    return (F(3,5)+z/(5*(z+1)))/N


def hard_rows(side,t,N):
    if side == "L":
        return ((F(0),F(1)),)+((F(0),F(0)),)*(N-2)+((F(0),N*t-F(1,2)),)
    return ((F(3,4),F(0)),)+((F(0),F(0)),)*(N-2)+(((F(1,2*N)/t-F(1,2))/2,F(0)),)


def hard_family_checks():
    worlds = noedge = exhaustive_states = exhaustive_worlds = 0
    cases = []
    for N in (2,3,7):
        for m,n in ((1,1),(1,2),(1,3),(2,2),(2,3)):
            k,K = m+n,m+n+1
            for kind in ("consecutive","powers_two"):
                zs = [F(i+1 if kind == "consecutive" else 2**i) for i in range(k)]
                ts = tuple(phi(z,N) for z in zs)
                left,right = (ts[n-1],)+ts[n+1:],ts[:n-1]+(ts[n],)
                case_worlds = 0
                for l in itertools.permutations(left):
                    for r in itertools.permutations(right):
                        thresholds = l+r
                        p = (F(1,2*N),F(1,2*N))
                        table = [(p,)*N]+[hard_rows("L" if q < m else "R",t,N)
                                          for q,t in enumerate(thresholds)]
                        ls,us = arrays(table)
                        means = [group[-1] for group in ls]
                        edges = [(i,j) for i in range(m) for j in range(m,k)
                                 if thresholds[i] < thresholds[j]]
                        assert len(edges) == 1
                        for a in range(N):
                            # Explicit bounded FALSE completion: raise just one
                            # unread candidate row to (1,1), preserve other rows.
                            counter = tuple((a*p[d]+1+(N-a-1)*p[d])/N for d in (0,1))
                            assert means[m+1][0] < F(1,N) <= counter[0]
                            assert means[m+1][1] == 0 < counter[1]
                        for group in range(1,K):
                            assert not (ls[group][1][0] <= p[0] and ls[group][1][1] <= p[1])
                            assert all(all(v > p[d] for d,v in enumerate(us[group][count]))
                                       for count in range(N))
                        state = [1]*K
                        state[0] = N
                        for q in edges[0]: state[q+1] = N
                        assert state_true(ls,us,state)
                        assert sum(state) == K+3*N-3
                        if N == 2 and kind == "consecutive":
                            minimum,count = exhaustive_min(table)
                            assert minimum == K+3*N-3
                            exhaustive_states += count
                            exhaustive_worlds += 1
                        for mask in range(1 << k):
                            if all(mask & (1<<q) for q in edges[0]): continue
                            observed = [q for q in range(k) if mask & (1<<q)]
                            lo,hi = F(3,5*N),F(4,5*N)
                            lower = max([lo]+[thresholds[q] for q in observed if q >= m])
                            upper = min([hi]+[thresholds[q] for q in observed if q < m])
                            cut = (lower+upper)/2
                            completed = [thresholds[q] if q in observed else
                                         ((cut+hi)/2 if q < m else (lo+cut)/2) for q in range(k)]
                            amended = [(p,)*N]+[hard_rows("L" if q < m else "R",t,N)
                                                for q,t in enumerate(completed)]
                            als,aus = arrays(amended)
                            assert not state_true(als,aus,(N,)*K)
                            for q in range(k):
                                assert amended[q+1][:-1] == table[q+1][:-1]
                                if q in observed: assert amended[q+1] == table[q+1]
                            noedge += 1
                        worlds += 1
                        case_worlds += 1
                cases.append({"N":N,"m":m,"n":n,"thresholds":kind,"worlds":case_worlds})
    return {"cases":cases,"worlds":worlds,"noedge_subsets_with_legal_FALSE_completion":noedge,
            "exhaustive_comparator_worlds":exhaustive_worlds,"exhaustive_prefix_states":exhaustive_states}


def main():
    result = {"source_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "triple":triple_checks(),"sharp_minimum":sharp_min_checks(),
              "scaled_P13_hard_family":hard_family_checks(),"all_pass":True}
    (ROOT/'lower_bounded_check_v1.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({"all_pass":result['all_pass'],"triple":result['triple'],
                      "sharp_certificate_cases":len(result['sharp_minimum']['explicit_certificate_cases']),
                      "sharp_minimum_exhaustive_cases":len(result['sharp_minimum']['exhaustive_minimum_cases']),
                      "hard_family":{k:v for k,v in result['scaled_P13_hard_family'].items() if k != 'cases'}},indent=2))


if __name__ == '__main__': main()
