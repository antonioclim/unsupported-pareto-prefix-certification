#!/usr/bin/env python3
"""Own exact finite-archive transformation audit; no earlier producer imports."""
from fractions import Fraction as F
from decimal import Decimal,localcontext
from pathlib import Path
from collections import defaultdict
import hashlib,json,time
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
FIXTURE=HERE/'transform_sensitivity_fixtures_v1.json'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def display(x):
    with localcontext() as c:
        c.prec=40
        return str(Decimal(x.numerator)/Decimal(x.denominator))
def average(xs):return sum(xs,F())/len(xs)
def g(x,t):return x/(x+t)
def dominates(a,b):return all(x<=y for x,y in zip(a,b)) and any(x<y for x,y in zip(a,b))
def support(points,target):
    """All w in[0,1] with w*dx+(1-w)*dy>=0 for every competitor."""
    lo,hi=F(),F(1);p=points[target]
    for i,z in enumerate(points):
        if i==target:continue
        dx,dy=z[0]-p[0],z[1]-p[1];slope=dx-dy
        if slope>0:lo=max(lo,-dy/slope)
        elif slope<0:hi=min(hi,-dy/slope)
        elif dy<0:return None
    return [str(lo),str(hi)] if lo<=hi else None
def grade(points,target):
    P2=not any(dominates(p,points[target]) for i,p in enumerate(points) if i!=target)
    interval=support(points,target);P4=interval is None
    return {'P2':P2,'P4':P4,'GOOD':P2 and P4,'support_weight_interval':interval}
def summary(configs):
    out={}
    for label in ('P2','P4','GOOD'):
        ids=[c['index'] for c in configs if c[label]];out[label+'_count']=len(ids);out[label+'_indices']=ids
    return out
def check_frozen():
    frozen=json.loads((HERE/'FREEZE_transform_sensitivity_v1.json').read_text())
    for name,value in frozen['files'].items():assert sha(ROOT/name)==value['sha256'],name
    return frozen
def load(protocol,expected_count):
    path=ROOT/'p9/licence/apex_dataset'/(protocol+'_results.json')
    raw=json.loads(path.read_text(),parse_float=F);groups=defaultdict(list)
    for r in raw:groups[tuple(sorted(r['params'].items()))].append(r)
    assert len(groups)==expected_count
    out=[]
    for key in sorted(groups):
        rows=sorted(groups[key],key=lambda r:r['id']);assert len(rows)==6
        lat=[F(r['metrics']['latency']) for r in rows];fail=[1-F(r['metrics']['reliability']) for r in rows]
        assert all(x>=0 for x in lat) and all(0<=x<=1 for x in fail)
        out.append({'params':dict(key),'trial_ids':[r['id'] for r in rows],'latencies':lat,'failures':fail})
    assert len({r['id'] for r in raw})==len(raw)
    return out
def toy_controls(f):
    t=f['point_transform_toy'];points=[tuple(map(F,p)) for p in t['points']];target=t['target'];tau=F(t['tau'])
    transformed=[(g(p[0],tau),p[1]) for p in points]
    before=grade(points,target);after=grade(transformed,target)
    assert before['P2'] and not before['P4'] and after['P2'] and after['P4']
    w=F(t['left_weight']);mix=[w*transformed[1][d]+(1-w)*transformed[2][d] for d in (0,1)]
    gaps=[transformed[target][d]-mix[d] for d in (0,1)]
    assert list(map(str,gaps))==t['expected_strict_gaps'] and all(z>0 for z in gaps)
    j=f['jensen_toy'];xs=list(map(F,j['latencies']));tau=F(j['tau']);a=g(average(xs),tau);b=average([g(x,tau) for x in xs]);gap=a-b
    assert [str(a),str(b),str(gap)]==[j['expected_pointbound'],j['expected_rowbound'],j['expected_gap']]
    r=f['pareto_row_transform_toy'];xs=[list(map(F,row)) for row in r['latencies']];tau=F(r['tau']);failure=F(r['failure'])
    old=[(average(row),failure) for row in xs];new=[(average([g(x,tau) for x in row]),failure) for row in xs]
    oldlabels=[grade(old,i)['P2'] for i in range(2)];newlabels=[grade(new,i)['P2'] for i in range(2)]
    assert oldlabels==r['expected_original_P2'] and newlabels==r['expected_rowbound_P2']
    return {'point_transform':{'original':before,'transformed':after,'original_points':[list(map(str,p)) for p in points],'transformed_points':[list(map(str,p)) for p in transformed],'left_weight':str(w),'strict_gaps':list(map(str,gaps))},'jensen':{'pointbound':str(a),'rowbound':str(b),'gap':str(gap)},'row_transform_pareto_reversal':{'original_points':[list(map(str,p)) for p in old],'rowbound_points':[list(map(str,p)) for p in new],'original_P2':oldlabels,'rowbound_P2':newlabels}}
def main():
    start=time.monotonic();frozen=check_frozen();f=json.loads(FIXTURE.read_text());cases=[];manifest={};jensen=[];totalrows=0
    toy=toy_controls(f)
    for protocol,count in f['protocols'].items():
        groups=load(protocol,count);path=ROOT/'p9/licence/apex_dataset'/(protocol+'_results.json')
        assert sha(path)==f['expected_data_sha256'][protocol]
        manifest[protocol]={'source':str(path.relative_to(ROOT)),'sha256':sha(path),'configurations':count,'rows':sum(len(c['latencies']) for c in groups)};totalrows+=manifest[protocol]['rows']
        original_points=[(average(c['latencies']),average(c['failures'])) for c in groups]
        originals=None
        scenarios=[('original',None)]+[(kind,tau) for tau in f['tau_ms'] for kind in ('affine','pointbound','rowbound')]
        for kind,tau in scenarios:
            points=[]
            for c,p in zip(groups,original_points):
                x=p[0] if kind=='original' else p[0]/tau if kind=='affine' else g(p[0],F(tau)) if kind=='pointbound' else average([g(l,F(tau)) for l in c['latencies']])
                points.append((x,p[1]))
            configs=[]
            for index,(c,point) in enumerate(zip(groups,points)):
                row={'index':index,'params':c['params'],'trial_ids':c['trial_ids'],'mean_latency_original':str(original_points[index][0]),'mean_failure':str(original_points[index][1]),'objective':list(map(str,point)),'objective_decimal':list(map(display,point))}|grade(points,index)
                configs.append(row)
            if originals is None:originals=configs
            changes={label:[{'index':c['index'],'before':a[label],'after':c[label]} for a,c in zip(originals,configs) if a[label]!=c[label]] for label in ('P2','P4','GOOD')}
            if kind=='affine':assert not any(changes.values())
            if kind=='pointbound':assert not changes['P2']
            if kind in ('pointbound','rowbound'):assert all(0<=p[0]<1 for p in points)
            cases.append({'protocol':protocol,'scenario':kind if tau is None else f'{kind}_tau{tau}ms','kind':kind,'tau':tau,'configs':configs,'summary':summary(configs),'changes_from_original':changes})
        for tau in f['tau_ms']:
            details=[]
            for i,c in enumerate(groups):
                a=g(original_points[i][0],F(tau));b=average([g(l,F(tau)) for l in c['latencies']]);gap=a-b
                variable=len(set(c['latencies']))>1
                assert gap>=0 and ((gap>0)==variable)
                details.append({'index':i,'pointbound':str(a),'rowbound':str(b),'gap':str(gap),'gap_decimal':display(gap),'latency_nonconstant':variable})
            jensen.append({'protocol':protocol,'tau':tau,'strict_count':sum(F(d['gap'])>0 for d in details),'equal_count':sum(F(d['gap'])==0 for d in details),'details':details})
    assert totalrows==f['expected_total_rows']==312 and len(cases)==20 and sum(len(c['configs']) for c in cases)==520
    check_frozen()
    result={'status':'PASS_EXACT_APEX_TRANSFORM_PRODUCER','date':'2026-10-23','scope':'All previously seen finite archived rows; exact deterministic objective sensitivity; not a new physical or heldout experiment','frozen_manifest_sha256':sha(HERE/'FREEZE_transform_sensitivity_v1.json'),'producer_sha256':sha(Path(__file__)),'dataset_manifest':manifest,'scenario_count_per_protocol':10,'classifications':520,'total_source_rows':totalrows,'cases':cases,'jensen':jensen,'toy':toy,'limits':['All tau values retained; no scenario selected after inspection','Positive affine scaling preserves both labels but supplies no finite global row cap','Pointbound and rowbound are new scientific objectives','Only rowbound is mean of bounded per-row penalties with known B1','Observed finite maxima are not trusted completion bounds','P2/P4 labels concern the complete archived means, not physical population means','No producer or P13 imports, external project execution, installs or acquisition runs'],'elapsed_seconds':time.monotonic()-start}
    (HERE/'transform_sensitivity_results_v1.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'classifications':result['classifications'],'cases':[{k:c[k] for k in ('protocol','scenario','summary','changes_from_original')} for c in cases],'jensen':[{k:j[k] for k in ('protocol','tau','strict_count','equal_count')} for j in jensen]},indent=2))
if __name__=='__main__':main()
