#!/usr/bin/env python3
"""Independent exact archive transformation checker; no producer imports."""
from collections import defaultdict
from decimal import Decimal, localcontext
from fractions import Fraction as F
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
DATA = ROOT / 'p9/licence/apex_dataset'
RESULT = HERE / 'transform_sensitivity_results_v1.json'
EXPECTED_RAW_SHA256 = {
    'Crystal': 'bc2c652f89a70d0723aec19cae1f2dba6d2b56523d5c0b54805520a8de072711',
    'RPL': 'c987d6583288e157139f8d6b0253c2adb91abee7642eee28fcf99db311f8f746',
}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def decimal_string(value):
    with localcontext() as ctx:
        ctx.prec = 40
        return str(Decimal(value.numerator) / Decimal(value.denominator))


def read_groups(protocol):
    path = DATA / (protocol + '_results.json')
    records = json.loads(path.read_text(), parse_float=F)
    bins = defaultdict(list)
    for record in records:
        bins[tuple(sorted(record['params'].items()))].append(record)
    keys = sorted(bins)
    groups = []
    ids = set()
    for key in keys:
        rows = sorted(bins[key], key=lambda row: row['id'])
        assert len(rows) == 6
        values = []
        for row in rows:
            assert row['id'] not in ids
            ids.add(row['id'])
            metric = row['metrics']
            latency = F(metric['latency'])
            failure = 1-F(metric['reliability'])
            assert latency >= 0 and 0 <= failure <= 1
            values.append((latency, failure))
        groups.append({'params': dict(key), 'trial_ids': [row['id'] for row in rows],
                       'rows': values, 'mean_latency': sum(x for x, y in values)/6,
                       'mean_failure': sum(y for x, y in values)/6})
    return groups, {'sha256': sha(path), 'rows': len(records), 'configs': len(groups)}


def point_for(group, kind, tau):
    latency = group['mean_latency']
    if kind == 'original':
        x = latency
    elif kind == 'affine':
        x = latency/F(tau)
    elif kind == 'pointbound':
        x = latency/(latency+F(tau))
    elif kind == 'rowbound':
        x = sum(a/(a+F(tau)) for a, b in group['rows'])/6
    else:
        raise AssertionError('Unexpected transformation kind: '+str(kind))
    return x, group['mean_failure']


def geometric_grade(points, target):
    """Unsupported iff an individual or a two-point mix improves both axes.

    For differences L=(-A,B), R=(C,-D), A,D>0 and B,C>=0,
    the open mixing interval is nonempty exactly when A*D > B*C.
    Zero B or C explicitly includes horizontal/vertical weak dominators.
    """
    ref = points[target]
    diffs = [(i, (p[0]-ref[0], p[1]-ref[1]))
             for i, p in enumerate(points) if i != target]
    nondominated = not any(x <= 0 and y <= 0 and (x < 0 or y < 0)
                           for i, (x, y) in diffs)
    witness = None
    for i, (x, y) in diffs:
        if x < 0 and y < 0:
            witness = {'indices': [i], 'weights': ['1'], 'gaps': [str(-x), str(-y)]}
            break
    if witness is None:
        left = [(i, -x, y) for i, (x, y) in diffs if x < 0 and y >= 0]
        right = [(i, x, -y) for i, (x, y) in diffs if x >= 0 and y < 0]
        for i, A, B in left:
            for j, C, D in right:
                if A*D > B*C:
                    lo = C/(A+C)
                    hi = D/(B+D)
                    weight = (lo+hi)/2
                    gaps = [weight*A-(1-weight)*C, (1-weight)*D-weight*B]
                    assert all(gap > 0 for gap in gaps)
                    witness = {'indices': [i, j], 'weights': [str(weight), str(1-weight)],
                               'gaps': list(map(str, gaps))}
                    break
            if witness is not None:
                break
    unsupported = witness is not None
    return {'P2': nondominated, 'P4': unsupported, 'GOOD': nondominated and unsupported}, witness


def validate_support_certificate(points, target, interval, unsupported):
    if unsupported:
        assert interval is None
        return
    assert interval is not None and len(interval) == 2
    lo, hi = map(F, interval)
    assert 0 <= lo <= hi <= 1
    x0, y0 = points[target]
    diffs = [(x-x0, y-y0) for i, (x, y) in enumerate(points) if i != target]
    assert all(w*x+(1-w)*y >= 0 for w in (lo, hi) for x, y in diffs)
    # Feasibility plus an active constraint with the indicated slope proves
    # each non-domain endpoint is the exact extremum of the closed interval.
    if lo > 0:
        assert any(x-y > 0 and lo*x+(1-lo)*y == 0 for x, y in diffs)
    if hi < 1:
        assert any(x-y < 0 and hi*x+(1-hi)*y == 0 for x, y in diffs)


def summary(labels):
    return {key: value for prop in ('P2', 'P4', 'GOOD')
            for key, value in ((prop+'_count', sum(row[prop] for row in labels)),
                               (prop+'_indices', [i for i, row in enumerate(labels) if row[prop]]))}


def changes(before, after):
    return {prop: [{'index': i, 'before': a[prop], 'after': b[prop]}
                   for i, (a, b) in enumerate(zip(before, after)) if a[prop] != b[prop]]
            for prop in ('P2', 'P4', 'GOOD')}


def boundary_controls():
    fixtures = [
        ('strictly_below_chord_supported', [('1', '2/5'), ('0', '1'), ('2', '0')], (True, False)),
        ('scalar_tie_supported', [('1', '1/2'), ('0', '1'), ('2', '0')], (True, False)),
        ('axis_supported', [('0', '1/2'), ('0', '1'), ('2', '0')], (True, False)),
        ('two_weak_axis_dominators', [('1', '1'), ('0', '1'), ('1', '0')], (False, True)),
        ('strict_dominator', [('1', '1'), ('0', '0')], (False, True)),
        ('duplicate_supported', [('1', '1'), ('1', '1')], (True, False)),
    ]
    for name, points, expected in fixtures:
        label, witness = geometric_grade([tuple(map(F, p)) for p in points], 0)
        assert (label['P2'], label['P4']) == expected, name
    return len(fixtures)


def check_frozen():
    frozen = json.loads((HERE/'FREEZE_transform_sensitivity_v1.json').read_text())
    for name, value in frozen['files'].items():
        assert sha(ROOT/name) == value['sha256'], name
        assert (ROOT/name).stat().st_size == value['bytes'], name
    return frozen


def main():
    frozen = check_frozen()
    before_hashes = {protocol: sha(DATA/(protocol+'_results.json')) for protocol in ('Crystal', 'RPL')}
    assert before_hashes == EXPECTED_RAW_SHA256
    before_source = sha(Path(__file__))
    result = json.loads(RESULT.read_text())
    archives = {}; manifests = {}
    for protocol in ('Crystal', 'RPL'):
        archives[protocol], manifests[protocol] = read_groups(protocol)
    assert manifests['Crystal']['rows'] == 96 and manifests['Crystal']['configs'] == 16
    assert manifests['RPL']['rows'] == 216 and manifests['RPL']['configs'] == 36
    expected_keys = {(protocol, kind, tau) for protocol in archives
                     for kind, tau in [('original', None)] +
                     [(kind, tau) for tau in (10, 100, 1000)
                      for kind in ('affine', 'pointbound', 'rowbound')]}
    case_by_key = {}; classified = {}; independent_witnesses = []
    for case in result['cases']:
        key = (case['protocol'], case['kind'], case['tau'])
        assert key in expected_keys and key not in case_by_key
        case_by_key[key] = case
        protocol, kind, tau = key
        groups = archives[protocol]
        points = [point_for(group, kind, tau) for group in groups]
        labels = []
        assert len(case['configs']) == len(groups)
        for i, (config, group) in enumerate(zip(case['configs'], groups)):
            assert config['index'] == i and config['params'] == group['params']
            assert config['trial_ids'] == group['trial_ids']
            assert F(config['mean_latency_original']) == group['mean_latency']
            assert F(config['mean_failure']) == group['mean_failure']
            assert tuple(map(F, config['objective'])) == points[i]
            assert config['objective_decimal'] == [decimal_string(v) for v in points[i]]
            label, witness = geometric_grade(points, i)
            assert all(config[prop] == label[prop] for prop in label)
            validate_support_certificate(points, i, config['support_weight_interval'], label['P4'])
            labels.append(label)
            if witness is not None:
                independent_witnesses.append({'protocol': protocol, 'scenario': case['scenario'],
                                              'index': i, **witness})
        assert case['summary'] == summary(labels)
        classified[key] = labels
    assert set(case_by_key) == expected_keys
    comparisons = []
    for key, case in case_by_key.items():
        protocol, kind, tau = key
        base = classified[(protocol, 'original', None)]
        assert case['changes_from_original'] == changes(base, classified[key])
        if kind == 'affine':
            assert classified[key] == base
        if kind == 'pointbound':
            assert all(a['P2'] == b['P2'] for a, b in zip(base, classified[key]))
        comparisons.append({'protocol': protocol, 'scenario': case['scenario'],
                            'kind': kind, 'tau': tau, 'summary': summary(classified[key]),
                            'changes_from_original': changes(base, classified[key])})
    expected_jensen = []
    for protocol, groups in archives.items():
        for tau in (10, 100, 1000):
            details = []
            for index, group in enumerate(groups):
                a = point_for(group, 'pointbound', tau)[0]
                b = point_for(group, 'rowbound', tau)[0]
                gap = a-b
                assert gap >= 0
                latencies = [x for x, y in group['rows']]
                assert (gap == 0) == (min(latencies) == max(latencies))
                details.append({'index': index, 'pointbound': str(a), 'rowbound': str(b),
                                'gap': str(gap), 'gap_decimal': decimal_string(gap),
                                'latency_nonconstant': min(latencies) != max(latencies)})
            expected_jensen.append({'protocol': protocol, 'tau': tau,
                                    'strict_count': sum(F(d['gap']) > 0 for d in details),
                                    'equal_count': sum(F(d['gap']) == 0 for d in details),
                                    'details': details})
    assert result['jensen'] == expected_jensen
    original_toy = [(F(1), F(2, 5)), (F(0), F(1)), (F(2), F(0))]
    transformed_toy = [(x/(x+1), y) for x, y in original_toy]
    assert geometric_grade(original_toy, 0)[0] == {'P2': True, 'P4': False, 'GOOD': False}
    assert geometric_grade(transformed_toy, 0)[0] == {'P2': True, 'P4': True, 'GOOD': True}
    weight = F(1, 3)
    gaps = [transformed_toy[0][j]-(weight*transformed_toy[1][j]+(1-weight)*transformed_toy[2][j]) for j in (0, 1)]
    assert gaps == [F(1, 18), F(1, 15)]
    toy = result['toy']['point_transform']
    assert [tuple(map(F, p)) for p in toy['original_points']] == original_toy
    assert [tuple(map(F, p)) for p in toy['transformed_points']] == transformed_toy
    for name, points in (('original', original_toy), ('transformed', transformed_toy)):
        lab, witness = geometric_grade(points, 0)
        assert all(toy[name][prop] == lab[prop] for prop in lab)
        validate_support_certificate(points, 0, toy[name]['support_weight_interval'], lab['P4'])
    assert F(toy['left_weight']) == weight and list(map(F, toy['strict_gaps'])) == gaps
    assert result['toy']['jensen'] == {'pointbound': '1/2', 'rowbound': '1/3', 'gap': '1/6'}
    pareto_toy = result['toy']['row_transform_pareto_reversal']
    original_pareto_points = [(F(50), F(1, 5)), (F(40), F(1, 5))]
    rowbound_pareto_points = [(F(5, 11), F(1, 5)), (F(4, 5), F(1, 5))]
    assert [tuple(map(F, p)) for p in pareto_toy['original_points']] == original_pareto_points
    assert [tuple(map(F, p)) for p in pareto_toy['rowbound_points']] == rowbound_pareto_points
    assert [geometric_grade(original_pareto_points, i)[0]['P2'] for i in range(2)] == pareto_toy['original_P2'] == [False, True]
    assert [geometric_grade(rowbound_pareto_points, i)[0]['P2'] for i in range(2)] == pareto_toy['rowbound_P2'] == [True, False]
    for protocol, manifest in manifests.items():
        assert result['dataset_manifest'][protocol]['sha256'] == manifest['sha256']
        assert result['dataset_manifest'][protocol]['rows'] == manifest['rows']
        assert result['dataset_manifest'][protocol]['configurations'] == manifest['configs']
    assert result['scenario_count_per_protocol'] == 10 and result['classifications'] == 520
    assert result['total_source_rows'] == 312
    assert result['frozen_manifest_sha256'] == sha(HERE/'FREEZE_transform_sensitivity_v1.json')
    assert all(sha(DATA/(p+'_results.json')) == h for p, h in before_hashes.items())
    assert sha(Path(__file__)) == before_source
    check_frozen()
    out = {'status': 'PASS_INDEPENDENT_EXACT_TRANSFORM_SENSITIVITY_CHECK',
           'producer_imported_or_executed': False, 'checker_sha256': before_source,
           'producer_result_sha256': sha(RESULT), 'dataset_manifest': manifests,
           'protocol_scenarios': len(case_by_key), 'candidate_classifications': sum(len(v) for v in classified.values()),
           'boundary_controls': boundary_controls(), 'jensen_checks': sum(len(j['details']) for j in expected_jensen),
           'all_affine_labels_preserved': True, 'all_point_transform_P2_labels_preserved': True,
           'toy_exact_strict_gaps': list(map(str, gaps)),
           'toy_decimal_strict_gaps': list(map(decimal_string, gaps)),
           'independent_unsupportedness_witnesses': independent_witnesses,
           'comparisons': comparisons,
           'limits': ['Exact finite archived means; no new physical runs or population inference',
                      'All archived rows were previously inspected; no held-out data',
                      'Nonlinear transformations define new objectives and do not supply a physical latency cap',
                      'Point-transform and row-transform objectives differ by Jensen concavity',
                      'No producer, P13, external project or old analysis module imported']}
    (HERE/'check_transform_sensitivity_results_v1.json').write_text(json.dumps(out, indent=2)+'\n')
    print(json.dumps({key: out[key] for key in ('status', 'protocol_scenarios', 'candidate_classifications',
                                             'boundary_controls', 'jensen_checks')}, indent=2))


if __name__ == '__main__':
    main()
