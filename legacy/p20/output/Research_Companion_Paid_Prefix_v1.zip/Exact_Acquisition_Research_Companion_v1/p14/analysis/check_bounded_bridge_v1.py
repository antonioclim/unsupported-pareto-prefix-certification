#!/usr/bin/env python3
"""Own frozen native finite audit of the bounded/unbounded certificate bridge.

Imports only the prior independent closed-support-interval oracle. The new
unbounded state test uses the established candidate/pair-census certificate
characterization, with all comparisons and enumeration written here.
"""
from fractions import Fraction as Q
from itertools import combinations, product
from pathlib import Path
import hashlib
import importlib.util
import json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
INPUT = HERE/'bounded_bridge_fixtures_v1.json'
FREEZE = HERE/'bounded_bridge_FREEZE_v1.json'
OUTPUT = HERE/'bounded_bridge_check_v1.json'
ORACLE = ROOT/'p13/theory/bounded_comparator_independent_check.py'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def frozen():
    for path, digest in json.loads(FREEZE.read_text())['sha256'].items():
        assert sha(ROOT/path) == digest, path


def main():
    frozen()
    spec = importlib.util.spec_from_file_location('closed_interval_oracle', ORACLE)
    oracle = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(oracle)
    records = []
    for case in json.loads(INPUT.read_text())['cases']:
        rows = [[tuple(Q(x) for x in r) for r in g] for g in case['rows']]
        target, B = case['target'], Q(case['B'])
        K, N = len(rows), len(rows[0])
        assert all(len(g) == N for g in rows)
        others = [g for g in range(K) if g != target]

        def force_unbounded(vector):
            if vector[target] != N:
                return False
            boxes = oracle.corners(rows, vector, B)
            p = boxes[target][0]
            if any(oracle.dominates(boxes[g][0], p) for g in others):
                return False
            known = [boxes[g][0] for g in others if vector[g] == N]
            return oracle.supporting_interval(p, known) is None

        states = true_states = pair_checks = bridge_state_checks = 0
        cb = cu = None
        cb_optima = cu_optima = 0
        for vector in product(range(N+1), repeat=K):
            states += 1
            cost = sum(vector)
            if force_unbounded(vector):
                if cu is None or cost < cu:
                    cu, cu_optima = cost, 1
                elif cost == cu:
                    cu_optima += 1
            if not oracle.force_true(rows, target, vector, B):
                continue
            true_states += 1
            if cb is None or cost < cb:
                cb, cb_optima = cost, 1
            elif cost == cb:
                cb_optima += 1
            assert 2*vector[target] > N
            assert cost >= 3*N+K-2-vector[target]
            assert all(vector[target]+vector[g] >= N+1 for g in others)
            boxes = oracle.corners(rows, vector, B)
            p = boxes[target][0]
            witness_found = False
            for ga, gb in combinations(others, 2):
                if oracle.supporting_interval(p, [boxes[ga][1], boxes[gb][1]]) is not None:
                    continue
                witness_found = True
                pair_checks += 1
                assert 2*vector[target]+vector[ga]+vector[gb] > 3*N
                completed = list(vector)
                completed[target] = completed[ga] = completed[gb] = N
                assert force_unbounded(completed)
                assert sum(completed) <= cost+N-1
                bridge_state_checks += 1
            assert witness_found
        assert (cb is None) == (cu is None)
        if cb is not None:
            assert 2*N+K-2 <= cb <= cu <= cb+N-1
        if case.get('sharp_family'):
            assert cb == 2*N+K-2
            assert cu == 3*N+K-3
            assert cu-cb == N-1
            vector = [0]*K
            stopped = None
            for n in range(N):
                for g in range(K):
                    vector[g] += 1
                    if oracle.force_true(rows, target, vector, B):
                        stopped = sum(vector)
                        break
                if stopped is not None:
                    break
            assert stopped == K*N
        else:
            stopped = None
        records.append({'id': case['id'], 'K': K, 'N': N, 'prefix_states': states,
            'bounded_TRUE_states': true_states, 'bounded_minimum': cb,
            'unbounded_minimum': cu, 'bounded_minimizer_count': cb_optima,
            'unbounded_minimizer_count': cu_optima,
            'gap': None if cb is None else cu-cb,
            'strict_pair_checks': pair_checks, 'bridge_state_checks': bridge_state_checks,
            'round_robin_cost_if_sharp_family': stopped})
    frozen()
    report = {'status': 'PASS_EXACT_FINITE_BOUNDED_BRIDGE_AUDIT',
        'input_sha256': sha(INPUT), 'source_sha256': sha(Path(__file__)),
        'freeze_sha256': sha(FREEZE), 'case_count': len(records),
        'prefix_states': sum(r['prefix_states'] for r in records),
        'bounded_TRUE_states': sum(r['bounded_TRUE_states'] for r in records),
        'strict_pair_checks': sum(r['strict_pair_checks'] for r in records),
        'results': records,
        'scope': ['Own standard-library exact rational code; no external code or packages.',
            'P13 independent closed-interval oracle read without modification.',
            'Unbounded state predicate uses established candidate/pair-census theorem.',
            'Every bounded TRUE state and every strict pair tested on listed finite inputs.',
            'Finite implementation evidence; universal proof separately frozen.',
            'No bounded minimax equality or physical-performance claim.']}
    OUTPUT.write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps({k: report[k] for k in ('status', 'case_count',
        'prefix_states', 'bounded_TRUE_states', 'strict_pair_checks')}, separators=(',', ':')))


if __name__ == '__main__':
    main()
