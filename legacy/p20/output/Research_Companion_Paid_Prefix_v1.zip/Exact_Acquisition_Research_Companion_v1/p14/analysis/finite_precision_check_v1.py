#!/usr/bin/env python3
"""Independent native audit of twelve dyadic archives and exact search policy.

Only prior independent closed-interval oracle is imported. Own policy uses
strict determinant geometry; legal negative completions check finite grid.
"""
from fractions import Fraction as Q
from itertools import combinations, permutations, product
from pathlib import Path
import hashlib
import importlib.util
import json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
INPUT = HERE/'finite_precision_fixtures_v1.json'
FREEZE = HERE/'finite_precision_FREEZE_v1.json'
OUTPUT = HERE/'finite_precision_results_v1.json'
ORACLE = ROOT/'p13/theory/bounded_comparator_independent_check.py'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def frozen():
    for p, digest in json.loads(FREEZE.read_text())['sha256'].items():
        assert sha(ROOT/p) == digest, p


def dominates(x, y):
    return x[0] <= y[0] and x[1] <= y[1] and x != y


def strict_pair(p, u, v):
    if not (u[0] < p[0] and u[1] > p[1] and v[0] > p[0] and v[1] < p[1]):
        u, v = v, u
    if not (u[0] < p[0] and u[1] > p[1] and v[0] > p[0] and v[1] < p[1]):
        return False
    return (p[0]-u[0])*(p[1]-v[1]) > (u[1]-p[1])*(v[0]-p[0])


def means(rows):
    return [tuple((g[0][d]+g[1][d])/2 for d in range(2)) for g in rows]


def full_good(rows):
    pts = means(rows)
    return not any(dominates(p, pts[0]) for p in pts[1:]) and any(
        strict_pair(pts[0], pts[a], pts[b]) for a, b in combinations(range(1,6),2))


def own_policy(rows, left_order, right_order):
    counts = [2,1,1,1,1,1]
    p = tuple(Q(x) for x in ('1','1/4'))
    match = (rows[0] == [p,p]
        and all(rows[g][0] == (Q(0),Q(1)) for g in (1,2))
        and all(rows[g][0] == (Q(3),Q(0)) for g in (3,4,5)))
    if not match:
        return {'counts':[2]*6,'answer':full_good(rows),'fallback':True}
    points = means(rows)
    # The observed first rows make P2 safe on the entire product domain.
    for g in left_order:
        counts[g] = 2
        if points[g][1] < Q(21,32):
            break
    for g in right_order:
        counts[g] = 2
        known = [h for h in range(1,6) if counts[h] == 2]
        if any(strict_pair(p, points[a], points[b]) for a,b in combinations(known,2)):
            return {'counts':counts,'answer':True,'fallback':False}
    return {'counts':[2]*6,'answer':full_good(rows),'fallback':True}


def main():
    frozen()
    spec = importlib.util.spec_from_file_location('independent_intervals', ORACLE)
    oracle = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(oracle)
    data = json.loads(INPUT.read_text())
    records = []
    negative_checks = policy_runs = fallback_runs = 0
    for case in data['central_cases']:
        rows = [[tuple(Q(x) for x in r) for r in g] for g in case['rows']]
        assert all(x*8 == int(x*8) and y*8 == int(y*8)
            and 0 <= x <= 3 and 0 <= y <= 1 for g in rows for x,y in g)
        truth = oracle.exhaustive(rows, 0, Q(3))
        assert truth['states'] == 729 and truth['minimum'] == 9
        pts = means(rows)
        edges = [(a,b) for a,b in combinations(range(1,6),2)
                 if strict_pair(pts[0],pts[a],pts[b])]
        assert len(edges) == 1
        ga,gb = edges[0]
        if ga not in (1,2):
            ga,gb = gb,ga
        assert ga in (1,2) and gb in (3,4,5)
        lam = Q(7,18)
        margins = [pts[0][d]-lam*pts[ga][d]-(1-lam)*pts[gb][d] for d in range(2)]
        assert margins == [Q(1,144),Q(1,144)]
        # Explicit legal GRID counterexample for every continuous-nonTRUE
        # prefix: this proves the finite-grid comparator is not smaller.
        for vector in product(range(3), repeat=6):
            if oracle.force_true(rows,0,vector,Q(3)):
                continue
            bad = [list(g) for g in rows]
            if vector[0] < 2:
                for n in range(vector[0],2):
                    bad[0][n] = (Q(3),Q(1))
            else:
                unseen = next((g for g in range(1,6) if vector[g] == 0), None)
                if unseen is not None:
                    bad[unseen] = [(Q(0),Q(0))]*2
                else:
                    for g in range(1,6):
                        if vector[g] == 1:
                            bad[g][1] = (Q(3),Q(1))
            assert all(bad[g][:vector[g]] == rows[g][:vector[g]] for g in range(6))
            assert all(x*8 == int(x*8) and y*8 == int(y*8)
                and 0 <= x <= 3 and 0 <= y <= 1 for g in bad for x,y in g)
            assert not full_good(bad)
            assert not oracle.force_true(bad,0,[2]*6,Q(3))
            negative_checks += 1
        costs = []
        residuals = []
        for lo in permutations((1,2)):
            for ro in permutations((3,4,5)):
                run = own_policy(rows,lo,ro)
                assert run['answer'] and not run['fallback']
                assert oracle.force_true(rows,0,run['counts'],Q(3))
                cost = sum(run['counts'])
                costs.append(cost)
                expected_tails = lo.index(ga)+1+ro.index(gb)+1
                assert cost == 7+expected_tails
                residuals.append(cost-7)
                policy_runs += 1
        average = sum(map(Q,costs))/len(costs)
        assert average == Q(21,2)
        assert sum(map(Q,residuals))/len(residuals) == Q(7,2)
        records.append({'id':case['id'],'prefix_states':729,
            'bounded_minimum':truth['minimum'],'bounded_TRUE_states':truth['TRUE_states'],
            'grid_negative_completions':729-truth['TRUE_states'],
            'strict_pair':list(edges[0]),'policy_runs':len(costs),
            'mean_paid':str(average),'ratio':str(average/truth['minimum'])})
    # Noncentral inputs independently exercise actual full-census fallback.
    fallback_records = []
    for case in data['fallback_cases']:
        rows = [[tuple(Q(x) for x in r) for r in g] for g in case['rows']]
        truth = oracle.force_true(rows,0,[2]*6,Q(3))
        for lo in permutations((1,2)):
            for ro in permutations((3,4,5)):
                run = own_policy(rows,lo,ro)
                assert run['answer'] == truth
                if run['answer']:
                    assert oracle.force_true(rows,0,run['counts'],Q(3))
                else:
                    assert run['counts'] == [2]*6
                fallback_runs += 1
        fallback_records.append({'id':case['id'],'full_truth':truth})
    # One central assignment, all 2^10 corners of the legally clipped tail
    # perturbation product. This is a witness/P2 audit, not full C* enumeration.
    rows = [[tuple(Q(x) for x in r) for r in g] for g in data['central_cases'][0]['rows']]
    pts = means(rows)
    ga,gb = next((a,b) for a in (1,2) for b in (3,4,5)
                 if strict_pair(pts[0],pts[a],pts[b]))
    eps = Q(1,288)
    intervals = []
    for g in range(1,6):
        for d in range(2):
            old = rows[g][1][d]
            intervals.append((max(Q(0),old-eps),min(Q(3 if d == 0 else 1),old+eps)))
    min_margin = None
    corner_count = 0
    for mask in product((0,1),repeat=10):
        perturbed = [list(g) for g in rows]
        for g in range(1,6):
            perturbed[g][1] = tuple(intervals[2*(g-1)+d][mask[2*(g-1)+d]] for d in range(2))
        now = means(perturbed)
        margin = min(now[0][d]-Q(7,18)*now[ga][d]-Q(11,18)*now[gb][d] for d in range(2))
        assert margin >= Q(1,192)
        min_margin = margin if min_margin is None else min(min_margin,margin)
        assert now[gb][0] < 2 and now[gb][1] < Q(5,8)
        assert now[ga][1] < Q(21,32)
        assert all(now[g][1] > Q(21,32) for g in (1,2) if g != ga)
        cert = [2,1,1,1,1,1]
        cert[ga] = cert[gb] = 2
        assert oracle.force_true(perturbed,0,cert,Q(3))
        corner_count += 1
    frozen()
    report = {'status':'PASS_INDEPENDENT_FINITE_PRECISION_AUDIT',
        'source_sha256':sha(Path(__file__)),'input_sha256':sha(INPUT),
        'freeze_sha256':sha(FREEZE),'central_archives':len(records),
        'central_prefix_states':729*len(records),'grid_negative_completions':negative_checks,
        'central_policy_runs':policy_runs,'fallback_runs':fallback_runs,
        'perturbation_corners':corner_count,'minimum_checked_fixed_mix_margin':str(min_margin),
        'central_results':records,'fallback_results':fallback_records,
        'scope':['Own exact rational determinant policy and legal-grid counterexamples.',
            'Imports prior independent closed-interval oracle, never new author code.',
            'Finite-grid negative completions explicitly preserve observations.',
            'Perturbation corners verify witnesses/P2, not exhaustive C* at every corner.',
            'Full-domain correctness is established by certificate/fallback proof; finite cases validate code.',
            'No global grid/B3/margin minimax or historical novelty claim.']}
    OUTPUT.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:report[k] for k in ('status','central_archives','central_prefix_states',
        'grid_negative_completions','central_policy_runs','fallback_runs',
        'perturbation_corners','minimum_checked_fixed_mix_margin')},separators=(',',':')))


if __name__ == '__main__':
    main()
