#!/usr/bin/env python3
"""Exact setup-cost confirmation using an immutable independent P16 oracle."""
from pathlib import Path
from fractions import Fraction as Q
from functools import lru_cache
from itertools import product
import hashlib,importlib.util,json
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 freeze=json.loads((HERE/'FREEZE_v1.json').read_text())
 for name,h in freeze['sha256'].items():assert sha(ROOT/name)==h,name
 s=importlib.util.spec_from_file_location('p16_independent',ROOT/'p16/analysis/independent_finite_check_v1.py');oracle=importlib.util.module_from_spec(s);s.loader.exec_module(oracle)
 fixture=json.loads((HERE/'fixtures_v1.json').read_text())
 worlds=[[[tuple(Q(x) for x in r) for r in g] for g in w['rows']] for w in fixture['worlds']]
 for w,rows in zip(fixture['worlds'],worlds):
  true=[list(n) for n in product(range(4),repeat=3) if oracle.forced(rows,n)]
  assert true==w['expected_TRUE_prefixes']
  assert min(sum(n) for n in true)==w['C_star']
 results=[]
 for text in fixture['setup_values']:
  F=Q(text);q=2*(F+8)/(3*F+23);prior=[q,1-q];den=[F+8,F+7];visits=0
  @lru_cache(None)
  def V(ids,n):
   nonlocal visits
   visits+=1
   if oracle.forced(worlds[ids[0]],n):
    assert all(oracle.forced(worlds[i],n) for i in ids);return Q(0)
   mass=sum((prior[i] for i in ids),Q(0));step=sum((prior[i]/den[i] for i in ids),Q(0))/mass;options=[]
   for g in range(3):
    if n[g]==3:continue
    branches={}
    for i in ids:branches.setdefault(worlds[i][g][n[g]],[]).append(i)
    nn=list(n);nn[g]+=1
    options.append(step+sum((sum((prior[i] for i in branch),Q(0))/mass*V(tuple(branch),tuple(nn)) for branch in branches.values()),Q(0)))
   assert options;return min(options)
  setup=F*sum((prior[i]/den[i] for i in range(2)),Q(0));query=V((0,1),(0,0,0));optimal=1+Q(2)/(3*F+23)
  assert setup+query==optimal and q>Q(2,3)
  bounds={'C7':(F+9-2*q)/(F+7),'C8_partial':(F+8+q)/(F+8),'C8_full_only':(F+9-q/2)/(F+8),'C9':Q(1)}
  assert max(bounds.values())==optimal
  branch=[(F+q*9+(1-q)*8)/(F+8),(F+q*7+(1-q)*9)/(F+7)]
  assert branch==[optimal,optimal]
  det=1+Q(1)/(F+8);assert det<(F+9)/(F+7)
  results.append({'F':str(F),'A_probability':str(q),'ratio_prior':[str(x) for x in prior],'randomised_exact':str(optimal),'deterministic_exact':str(det),'Bayes_query_ratio':str(query),'setup_ratio_term':str(setup),'Bellman_states':visits,'class_upper_ratios':{k:str(v) for k,v in bounds.items()},'canonical_world_policy_ratios':[str(x) for x in branch]})
 for name,h in freeze['sha256'].items():assert sha(ROOT/name)==h,name
 out={'status':'PASS_EXACT_SETUP_COST_CONTROLS','source_sha256':sha(Path(__file__)),'setup_values_checked':len(results),'prefix_states_per_parameter':128,'records':results,'scope':['Universal realF>=0 theorem is analytic, not proved by finite parameter checks','Only earlier independent P16 prefix oracle imported read-only','Common compulsory public uninformative setup charged equally to algorithm and certificate','No triangle equality, physical cost or historical novelty asserted']}
 (HERE/'results_v1.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
