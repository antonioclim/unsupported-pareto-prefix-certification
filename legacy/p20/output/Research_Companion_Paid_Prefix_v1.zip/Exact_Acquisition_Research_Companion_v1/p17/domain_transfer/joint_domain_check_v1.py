#!/usr/bin/env python3
"""Own exact finite joint-row-domain controls, no project/oracle imports."""
from fractions import Fraction as Q
from itertools import product
from pathlib import Path
import hashlib,json

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent.parent
INPUT=HERE/'joint_domain_fixtures_v1.json'
FREEZE=HERE/'joint_domain_FREEZE_v1.json'
OUTPUT=HERE/'joint_domain_results_v1.json'

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def frozen():
    for name,h in json.loads(FREEZE.read_text())['sha256'].items():
        assert sha(ROOT/name)==h,name
def dom(x,y):return all(x[d]<=y[d] for d in range(2)) and x!=y
def support(p,others):
    low,high=Q(0),Q(1)
    for q in others:
        dx,dy=q[0]-p[0],q[1]-p[1];slope=dx-dy
        if slope>0:low=max(low,-dy/slope)
        elif slope<0:high=min(high,-dy/slope)
        elif dy<0:return False
        if low>high:return False
    return True
def good(rows):
    pts=[tuple(sum((r[d] for r in group),Q(0))/len(group) for d in range(2)) for group in rows]
    return not any(dom(q,pts[0]) for q in pts[1:]) and not support(pts[0],pts[1:])
def rowbounds(domains):
    return [[(tuple(min(p[d] for p in S) for d in range(2)),
              tuple(max(p[d] for p in S) for d in range(2))) for S in group] for group in domains]
def corners(prefixes,bounds):
    out=[]
    for prefix,b in zip(prefixes,bounds):
        N=len(b);n=len(prefix)
        s=[sum((r[d] for r in prefix),Q(0)) for d in range(2)]
        low=tuple((s[d]+sum((v[0][d] for v in b[n:]),Q(0)))/N for d in range(2))
        high=tuple((s[d]+sum((v[1][d] for v in b[n:]),Q(0)))/N for d in range(2))
        out.append((low,high))
    return out
def forced_corner(prefixes,bounds):
    b=corners(prefixes,bounds)
    return not any(dom(v[0],b[0][1]) for v in b[1:]) and not support(b[0][0],[v[1] for v in b[1:]])
def negative(prefixes,bounds):
    b=corners(prefixes,bounds)
    culprit=next((i for i in range(1,len(b)) if dom(b[i][0],b[0][1])),None)
    rows=[]
    for g,(prefix,bs) in enumerate(zip(prefixes,bounds)):
        upper=(g==0) if culprit is not None else (g!=0)
        rows.append(tuple(prefix)+tuple(v[1 if upper else 0] for v in bs[len(prefix):]))
    assert not good(rows)
    return rows
def legal(rows,domains):return all(r in S for group,dg in zip(rows,domains) for r,S in zip(group,dg))
def parse_domains(raw):return [[tuple(tuple(Q(x) for x in p) for p in S) for S in group] for group in raw]

def main():
    frozen();data=json.loads(INPUT.read_text());records=[]
    for case in data['systematic_cases']:
        domains=parse_domains(case['domains']);sizes=list(map(len,domains));bounds=rowbounds(domains)
        assert all(ell in S and up in S for dg,bg in zip(domains,bounds) for S,(ell,up) in zip(dg,bg))
        sequences=[list(product(*group)) for group in domains]
        vectors=list(product(*(range(N+1) for N in sizes)))
        forcing={};tables=positives=incidences=0
        for rows in product(*sequences):
            actual=good(rows);tables+=1;positives+=actual
            for n in vectors:
                key=tuple(group[:k] for group,k in zip(rows,n))
                forcing[key]=forcing.get(key,True) and actual
                incidences+=1
        assert positives>0,case['id']
        robust=negative_count=0
        for prefixes,finite_true in forcing.items():
            assert forced_corner(prefixes,bounds)==finite_true,(case['id'],prefixes)
            robust+=finite_true
            if not finite_true:
                counter=negative(prefixes,bounds);assert legal(counter,domains)
                assert all(g[:len(p)]==p for g,p in zip(counter,prefixes))
                negative_count+=1
        records.append({'id':case['id'],'mode':'ALL_FULL_TABLES_AND_PREFIX_TRANSCRIPTS',
            'full_tables':tables,'positive_full_tables':positives,'distinct_transcripts':len(forcing),
            'completion_prefix_incidences':incidences,'robust_TRUE_transcripts':robust,
            'legal_joint_extreme_FALSE_witnesses':negative_count})
    controls=[]
    for case in data['missing_endpoint_controls']:
        domains=parse_domains(case['domains']);actual=[tuple(tuple(Q(x) for x in r) for r in group) for group in case['actual_rows']]
        assert legal(actual,domains) and good(actual)
        sizes=list(map(len,domains));bounds=rowbounds(domains)
        unit=[[( (Q(0),Q(0)),(Q(1),Q(1)) ) for _ in group] for group in domains]
        true_finite=[];true_unit=[];examined=0;differences=[]
        for n in product(*(range(N+1) for N in sizes)):
            prefixes=tuple(g[:k] for g,k in zip(actual,n))
            choices=[]
            for g,(group,ng) in enumerate(zip(domains,n)):
                choices.append(list(product(*( (actual[g][r],) if r<ng else S for r,S in enumerate(group) ))))
            all_good=True
            for rows in product(*choices):
                all_good=good(rows) and all_good;examined+=1
            assert forced_corner(prefixes,bounds)==all_good,(case['id'],n)
            unit_true=forced_corner(prefixes,unit)
            if all_good:true_finite.append(list(n))
            if unit_true:true_unit.append(list(n))
            if unit_true!=all_good:differences.append(list(n))
            if list(n)==case['designated_prefix']:
                assert all_good and not unit_true
                assert not legal(negative(prefixes,unit),domains)
        finite_min=min(map(sum,true_finite));unit_min=min(map(sum,true_unit))
        assert finite_min==case['expected_finite_minimum']
        assert unit_min==case['expected_unit_minimum']
        controls.append({'id':case['id'],'prefix_states':len(list(product(*(range(N+1) for N in sizes)))),
            'exact_compatible_completions_examined':examined,'finite_minimum':finite_min,
            'unit_square_minimum':unit_min,'finite_TRUE_prefixes':true_finite,
            'unit_TRUE_prefixes':true_unit,'forcing_differences':differences,
            'designated_unit_FALSE_witness_is_illegal':True,
            'own_attained_orderbox_comparison':'PASS_EVERY_PREFIX'})
    frozen()
    result={'status':'PASS_EXACT_JOINT_ROW_DOMAIN_TRANSFER_CONTROLS',
        'source_sha256':sha(Path(__file__)),'input_sha256':sha(INPUT),'freeze_sha256':sha(FREEZE),
        'systematic_results':records,'missing_endpoint_controls':controls,
        'scope':['Own stdlib exact rational code, no old oracle/project imports.',
            'Finite robustTRUE aggregated from actual GOOD over all compatible completions.',
            'Joint within-row domains, independent rows/groups.',
            'Missing-unit-endpoint controls intentionally compare different envelopes.',
            'Closure-only infinite-domain counterexample proved separately, not finitely enumerated.',
            'No robustFALSE or global minimax equality inferred from finite controls.']}
    OUTPUT.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,separators=(',',':')))
if __name__=='__main__':main()
