# P17 small-catalogue replay

Run with Python standard library:

```sh
python p17/applied_replay/small_catalogue_replay_v1.py
```

For byte-reproducible replay, choose fresh paths with
`--output /path/replay.json --csv /path/replay.csv`.
Frozen sources and inputs are checked before execution. Existing results are
preserved. No P16 file is imported or changed.

The suite selects32positive and32negative archives per domain, enumerates all
64prefixes, and compares mixture/deterministic/full-census/cheapest-next
policies under five public fixed charge schedules. JSON contains every
tablecode, mean, prefix decision, query path and exact comparison. CSV is the
flat per-archive/tariff/policy view. Full-data labels/determinants and client
weight-interval tests are cross-checked.

Square and quarter-grid triangle wire dictionaries each contain15rows and
use four logical numeric payload bits. The certificate domains remain
continuous: square or0<=failure<=cost<=1. A tested-grid class count is not a
continuous-domain minimax theorem. Prices are abstract public accounting
units independent of values, not calibrated energy charges. Identifiers,
headers, framing and deployment overhead are excluded.

Read the protocol for the deterministic balanced selection method and all
limits. All adverse comparisons and failures are retained.

