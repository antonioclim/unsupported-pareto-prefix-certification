#!/usr/bin/env python3
"""Frozen exact small-catalogue replay; Python standard library only."""
import argparse
import csv
import hashlib
import io
import itertools
import json
from fractions import Fraction as Q
from pathlib import Path

HERE = Path(__file__).resolve().parent
GROUPS = ("a", "L", "R")
PREFIXES = tuple(itertools.product(range(4), repeat=3))


def check(value, why):
    if not value:
        raise AssertionError(why)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def codebook(name):
    if name == "square":
        return tuple((c, f) for c in map(Q, ("0", "3/8", "5/8", "7/8", "1"))
                     for f in map(Q, ("0", "7/8", "1")))
    if name == "triangle":
        return tuple((Q(c, 4), Q(f, 4)) for c in range(5) for f in range(c + 1))
    raise ValueError("unknown public domain")


def encode(row, book):
    return format(book.index(tuple(row)), "04b")


def decode(bits, book):
    if len(bits) != 4 or any(x not in "01" for x in bits) or int(bits, 2) == 15:
        raise ValueError("invalid four-bit row")
    return book[int(bits, 2)]


def mean(rows):
    return tuple(sum((r[j] for r in rows), Q()) / 3 for j in (0, 1))


def point_good(a, others):
    # Independent complete-point determinant formulation for K=3.
    if any(all(p[j] <= a[j] for j in (0, 1)) and p != a for p in others):
        return False
    left, right = sorted(others)
    if not (left[0] < a[0] < right[0] and left[1] > a[1] > right[1]):
        return False
    return ((right[0] - a[0]) * (left[1] - a[1])
            + (a[0] - left[0]) * (right[1] - a[1])) < 0


def boxes(seen):
    answer = {}
    for g in GROUPS:
        low = mean(seen[g])
        high = tuple(x + Q(3 - len(seen[g]), 3) for x in low)
        answer[g] = low, high
    return answer


def client_true(seen):
    # Client implementation: closed weight-interval feasibility.
    b = boxes(seen)
    a_low, a_up = b["a"]
    for g in ("L", "R"):
        p = b[g][0]
        if p[0] <= a_up[0] and p[1] <= a_up[1] and p != a_up:
            return False
    lo, hi = Q(), Q(1)
    for g in ("L", "R"):
        p = b[g][1]
        dc, df = p[0] - a_low[0], p[1] - a_low[1]
        slope = dc - df
        if slope == 0:
            if df < 0:
                return True
        elif slope > 0:
            lo = max(lo, -df / slope)
        else:
            hi = min(hi, -df / slope)
    return lo > hi


def oracle_true(table, counts):
    # Retrospective comparator implementation: explicit corners + determinant.
    # It imports no client policy and no P13--P16 oracle.
    lows, highs = {}, {}
    for g, n in zip(GROUPS, counts):
        observed = table[g][:n]
        lows[g] = tuple(sum((r[j] for r in observed), Q()) / 3 for j in (0, 1))
        highs[g] = tuple(x + Q(3 - n, 3) for x in lows[g])
    u = highs["a"]
    for g in ("L", "R"):
        l = lows[g]
        if l[0] <= u[0] and l[1] <= u[1] and (l[0] < u[0] or l[1] < u[1]):
            return False
    return point_good(lows["a"], (highs["L"], highs["R"]))


def label(table):
    return point_good(mean(table["a"]), (mean(table["L"]), mean(table["R"])))


def table_key(table):
    return tuple(tuple(table[g]) for g in GROUPS)


def parse_table(table):
    return {g: tuple(tuple(map(Q, row)) for row in table[g]) for g in GROUPS}


def permutations(table):
    choices = [sorted(set(itertools.permutations(table[g]))) for g in GROUPS]
    for rows in itertools.product(*choices):
        answer = dict(zip(GROUPS, rows))
        yield answer
        yield {"a": answer["a"], "L": answer["R"], "R": answer["L"]}


class LCG:
    def __init__(self, seed):
        self.state = seed

    def draw(self, upper):
        self.state = (1664525 * self.state + 1013904223) % (2 ** 32)
        return (self.state >> 16) % upper


def catalogue(domain, cfg):
    book = codebook(domain)
    rng = LCG(cfg["public_seed"])
    positives, negatives, used = [], [], set()

    def add(table, origin, bucket):
        key = table_key(table)
        if key in used:
            return False
        check(all(row in book for g in GROUPS for row in table[g]), "illegal table row")
        used.add(key)
        bucket.append((table, origin))
        return True

    seeds = [parse_table(t) for t in cfg["mandatory_positive_seeds"].values()]
    for table in seeds:
        check(label(table), "mandatory positive seed is FALSE")
        add(table, "mandatory_analytic_positive", positives)
    structured = []
    structured_keys = set()
    for seed in seeds:
        for table in permutations(seed):
            key = table_key(table)
            if key not in structured_keys:
                structured_keys.add(key)
                structured.append(table)
    # Deterministic Fisher--Yates, explicitly defined integer generator.
    for i in range(len(structured) - 1, 0, -1):
        j = rng.draw(i + 1)
        structured[i], structured[j] = structured[j], structured[i]
    for table in structured:
        if len(positives) >= cfg["structured_positive_target"]:
            break
        add(table, "permuted_analytic_positive", positives)
    for t in cfg["mandatory_negative_seeds"].values():
        table = parse_table(t)
        check(not label(table), "mandatory negative seed is TRUE")
        add(table, "mandatory_negative", negatives)
    draws = 0
    random_positive = 0
    while draws < cfg["maximum_random_draws"] and (
            len(positives) < cfg["positive_target"] or len(negatives) < cfg["negative_target"]):
        draws += 1
        table = {g: tuple(book[rng.draw(15)] for _ in range(3)) for g in GROUPS}
        if label(table):
            if len(positives) < cfg["positive_target"] and add(table, "LCG_positive", positives):
                random_positive += 1
        elif len(negatives) < cfg["negative_target"]:
            add(table, "LCG_negative", negatives)
    fill = 0
    for table in structured:
        if len(positives) >= cfg["positive_target"]:
            break
        fill += int(add(table, "declared_structured_budget_fill", positives))
    check(len(positives) == cfg["positive_target"], "positive quota not filled")
    check(len(negatives) == cfg["negative_target"], "negative quota not filled")
    records = [(f"{domain}_P{i:03}", t, origin) for i, (t, origin) in enumerate(positives)]
    records += [(f"{domain}_F{i:03}", t, origin) for i, (t, origin) in enumerate(negatives)]
    return records, {"random_draws": draws, "random_positives_selected": random_positive,
                     "structured_budget_fill": fill, "positive": len(positives),
                     "negative": len(negatives), "structured_pool": len(structured)}


class Server:
    def __init__(self, table, book):
        self.__table = table
        self.__book = book
        self.__counts = {g: 0 for g in GROUPS}

    def next(self, group):
        if group not in GROUPS or self.__counts[group] == 3:
            raise ValueError("unknown or exhausted group")
        n = self.__counts[group]
        self.__counts[group] += 1
        return group, n + 1, encode(self.__table[group][n], self.__book)


class Client:
    def __init__(self, request, book, charges):
        self.__request, self.book, self.charges = request, book, charges
        self.seen = {g: [] for g in GROUPS}
        self.log = []

    def query(self, group, phase):
        g, index, bits = self.__request(group)
        check(g == group and index == len(self.seen[g]) + 1, "non-prefix response")
        row = decode(bits, self.book)
        self.seen[g].append(row)
        self.log.append({"group": g, "index": index, "bits": bits, "phase": phase})

    def p2_safe(self, g):
        b = boxes(self.seen)
        l, u = b[g][0], b["a"][1]
        return not (l[0] <= u[0] and l[1] <= u[1] and l != u)

    def full(self):
        return all(len(self.seen[g]) == 3 for g in GROUPS)

    def fill(self, g, n, phase, stop=True):
        while len(self.seen[g]) < n:
            self.query(g, phase)
            if stop and client_true(self.seen):
                return True
        return False

    def census(self, stop=True):
        for g in GROUPS:
            if self.fill(g, 3, "census", stop):
                return
        check(self.full(), "incomplete fallback")


def run(table, book, policy, charges, order=("L", "R")):
    server = Server(table, book)
    c = Client(server.next, book, charges)
    if policy == "full":
        c.census(stop=False)
    elif policy == "greedy":
        while not c.full():
            available = [g for g in GROUPS if len(c.seen[g]) < 3]
            g = min(available, key=lambda x: (charges[x][len(c.seen[x])], GROUPS.index(x)))
            c.query(g, "cheapest_public_next_charge")
            if client_true(c.seen):
                break
    elif policy == "B":
        for g, n in (("a", 2), ("L", 3), ("R", 3)):
            c.fill(g, n, "B233", stop=False)
        if not client_true(c.seen):
            c.census()
    else:
        stopped = c.fill("a", 3, "candidate_census")
        if not stopped:
            for g in ("L", "R"):
                while not c.p2_safe(g) and len(c.seen[g]) < 3:
                    c.query(g, "P2_screen")
                    if client_true(c.seen):
                        stopped = True
                        break
                if stopped:
                    break
        if not stopped and policy == "A":
            for g in ("L", "R"):
                if c.fill(g, 2, "raise_to_two"):
                    stopped = True
                    break
            if not stopped:
                for g in order:
                    if c.fill(g, 3, "fair_tail"):
                        stopped = True
                        break
        if not stopped:
            c.census()
    answer = client_true(c.seen)
    check(answer or c.full(), "FALSE returned without full fallback")
    check(answer == label(table), "wrong final label")
    counts = [len(c.seen[g]) for g in GROUPS]
    check(not answer or oracle_true(table, counts), "stopped TRUE without comparator certificate")
    observed = {g: 0 for g in GROUPS}
    for item in c.log:
        g = item["group"]
        observed[g] += 1
        check(item["index"] == observed[g], "query index skipped")
    return {"answer": answer, "queries": len(c.log), "numeric_payload_bits": 4 * len(c.log),
            "counts": counts, "log": c.log}


def charge_of(log, prices):
    return sum((Q(prices[x["group"]][x["index"] - 1]) for x in log), Q())


def prefix_charge(counts, prices):
    return sum((sum((Q(v) for v in prices[g][:n]), Q()) for g, n in zip(GROUPS, counts)), Q())


def execute(cfg):
    headers = ["domain", "archive", "label", "C_unit", "tariff", "C_weighted",
               "policy", "expected_queries", "expected_charge", "charge_ratio"]
    stream = io.StringIO(newline="")
    writer = csv.writer(stream, lineterminator="\n")
    writer.writerow(headers)
    all_tables, summaries = [], {}
    total_states = total_rows = 0
    all_codec_controls = {}
    for domain, generation in cfg["domains"].items():
        book = codebook(domain)
        check(len(book) == 15 and (Q(), Q()) in book and (Q(1), Q(1)) in book, "bad codebook")
        for i, row in enumerate(book):
            check(decode(encode(row, book), book) == row, "roundtrip")
            check(int(encode(row, book), 2) == i, "code order")
        for invalid in ("1111", "", "000", "00000", "ab01"):
            try:
                decode(invalid, book)
            except ValueError:
                pass
            else:
                raise AssertionError("invalid code accepted")
        all_codec_controls[domain] = {
            "valid_roundtrips": 15, "invalid15_rejected": True,
            "rows": [{"code": i, "bits": format(i, "04b"), "row": list(map(str, row))}
                     for i, row in enumerate(book)]}
        records, gen_record = catalogue(domain, generation)
        counts_by_C = {}
        tariff_summary = {name: {p: {"ratios": [], "strictly_worse_than_mix": 0}
                                 for p in ("mix", "det", "full", "greedy")}
                          for name in cfg["tariffs"]}
        for archive_id, table, origin in records:
            actual = label(table)
            truths = []
            for counts in PREFIXES:
                value = oracle_true(table, counts)
                seen = {g: list(table[g][:n]) for g, n in zip(GROUPS, counts)}
                check(value == client_true(seen), "determinant/interval prefix disagreement")
                truths.append({"counts": list(counts), "TRUE": value})
            total_states += 64
            good_states = [tuple(x["counts"]) for x in truths if x["TRUE"]]
            check(bool(good_states) == actual, "full-label/certificate disagreement")
            Cunit = min(map(sum, good_states)) if actual else None
            if actual:
                counts_by_C[str(Cunit)] = counts_by_C.get(str(Cunit), 0) + 1
            unit = cfg["tariffs"]["unit"]
            paths = {
                "A_LR": run(table, book, "A", unit, ("L", "R")),
                "A_RL": run(table, book, "A", unit, ("R", "L")),
                "B": run(table, book, "B", unit),
                "det": run(table, book, "det", unit),
                "full": run(table, book, "full", unit),
            }
            evaluations = []
            for tariff, prices in cfg["tariffs"].items():
                paths["greedy_" + tariff] = run(table, book, "greedy", prices)
                Cw = min(prefix_charge(n, prices) for n in good_states) if actual else None
                minima = [list(n) for n in good_states if prefix_charge(n, prices) == Cw] if actual else []
                mix_cost = sum((w * charge_of(paths[p]["log"], prices) for p, w in
                                (("A_LR", Q(8, 23)), ("A_RL", Q(8, 23)), ("B", Q(7, 23)))), Q())
                mix_queries = sum((w * paths[p]["queries"] for p, w in
                                   (("A_LR", Q(8, 23)), ("A_RL", Q(8, 23)), ("B", Q(7, 23)))), Q())
                costs = {"mix": (mix_queries, mix_cost)}
                for policy, path_key in (("det", "det"), ("full", "full"), ("greedy", "greedy_" + tariff)):
                    costs[policy] = Q(paths[path_key]["queries"]), charge_of(paths[path_key]["log"], prices)
                for policy, (queries, cost) in costs.items():
                    ratio = cost / Cw if actual else None
                    if actual:
                        check(ratio >= 1, "policy cost below valid hindsight minimum")
                        tariff_summary[tariff][policy]["ratios"].append(ratio)
                        tariff_summary[tariff][policy]["strictly_worse_than_mix"] += int(cost > mix_cost)
                    writer.writerow([domain, archive_id, "TRUE" if actual else "FALSE",
                                     Cunit if actual else "", tariff, str(Cw) if actual else "",
                                     policy, str(queries), str(cost), str(ratio) if actual else ""])
                    total_rows += 1
                    evaluations.append({"tariff": tariff, "policy": policy,
                                        "C_weighted": str(Cw) if actual else None,
                                        "minimum_prefixes": minima if policy == "mix" else None,
                                        "expected_queries": str(queries), "expected_charge": str(cost),
                                        "ratio": str(ratio) if actual else None})
            all_tables.append({
                "id": archive_id, "domain": domain, "origin": origin, "label": actual,
                "table_codes": {g: [int(encode(r, book), 2) for r in table[g]] for g in GROUPS},
                "means": {g: list(map(str, mean(table[g]))) for g in GROUPS},
                "C_unit": Cunit, "prefix_states": truths, "paths": paths,
                "evaluations": evaluations})
        if domain == "square":
            check({"7", "8", "9"} <= set(counts_by_C), "square C7/8/9 coverage missing")
        else:
            check({"8", "9"} <= set(counts_by_C), "triangle C8/9 coverage missing")
        for tariff, policies in tariff_summary.items():
            for policy, entry in policies.items():
                values = entry.pop("ratios")
                entry["maximum_observed_ratio"] = str(max(values))
                entry["mean_positive_ratio"] = str(sum(values, Q()) / len(values))
        summaries[domain] = {"generation": gen_record, "positive_C_unit_classes": counts_by_C,
                             "tariff_policy_summary": tariff_summary}
    csv_text = stream.getvalue()
    result = {
        "schema": "p17-small-catalogue-replay-v1", "status": "PASS_EXACT_FINITE_REPLAY_CONTROLS",
        "declared_metadata_stamp": cfg["declared_metadata_stamp"],
        "catalogue_tables": len(all_tables), "prefix_states": total_states, "CSV_rows": total_rows,
        "public_tariffs": cfg["tariffs"], "mixture_weights": {"A_LR": "8/23", "A_RL": "8/23", "B": "7/23"},
        "codec_controls": all_codec_controls, "summaries": summaries, "catalogue": all_tables,
        "CSV_sha256": hashlib.sha256(csv_text.encode()).hexdigest(),
        "scope": cfg["scope"]}
    return result, csv_text


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--output", type=Path, default=HERE / "small_catalogue_results_v1.json")
    p.add_argument("--csv", type=Path, default=HERE / "small_catalogue_comparison_v1.csv")
    args = p.parse_args()
    if args.output.exists() or args.csv.exists():
        raise SystemExit("Preserve existing outputs; use new --output and --csv paths.")
    exit_code = 0
    csv_text = ""
    try:
        frozen = json.loads((HERE / "small_catalogue_FREEZE_v1.json").read_text())
        for name, digest in frozen["sha256"].items():
            check(sha(HERE / name) == digest, "freeze mismatch: " + name)
        cfg = json.loads((HERE / "small_catalogue_fixtures_v1.json").read_text())
        result, csv_text = execute(cfg)
    except Exception as e:
        exit_code = 1
        result = {"schema": "p17-small-catalogue-replay-v1", "status": "FAILED",
                  "error_type": type(e).__name__, "error": str(e)}
    result["source_sha256"] = sha(__file__)
    result["fixture_sha256"] = sha(HERE / "small_catalogue_fixtures_v1.json")
    result["freeze_sha256"] = sha(HERE / "small_catalogue_FREEZE_v1.json")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.csv.parent.mkdir(parents=True, exist_ok=True)
    args.csv.write_text(csv_text)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({k: result.get(k) for k in ["status", "catalogue_tables", "prefix_states", "CSV_rows"]}))
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())

