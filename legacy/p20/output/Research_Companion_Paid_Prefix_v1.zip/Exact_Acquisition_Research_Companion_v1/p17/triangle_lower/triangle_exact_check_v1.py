#!/usr/bin/env python3
"""Own exact corroboration of triangle K3N3 paid-prefix optimality."""
import hashlib
import itertools
import json
import random
from collections import Counter
from fractions import Fraction as F
from pathlib import Path

HERE=Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def bounds(table,ns):
    low=[];up=[]
    for rows,n in zip(table,ns):
        p=tuple(sum((r[d] for r in rows[:n]),F(0))/3 for d in (0,1))
        low.append(p);up.append(tuple(v+F(3-n,3) for v in p))
    return low,up


def dom(p,q):
    return p[0]<=q[0] and p[1]<=q[1] and p!=q


def analyse(table,ns):
    low,up=bounds(table,ns)
    for g in (1,2):
        if dom(low[g],up[0]):return {'TRUE':False,'reason':'P2','offender':g}
    lo,hi=F(0),F(1)
    for p in up[1:]:
        dx,dy=p[0]-low[0][0],p[1]-low[0][1]
        slope=dx-dy
        if slope>0:lo=max(lo,-dy/slope)
        elif slope<0:hi=min(hi,-dy/slope)
        elif dy<0:return {'TRUE':True}
    if lo>hi:return {'TRUE':True}
    return {'TRUE':False,'reason':'P4','weight':((lo+hi)/2,1-(lo+hi)/2)}


def actual_good(table):
    # Separate full-point determinant implementation: does not call analyse.
    p,q,r=[tuple(sum((row[d] for row in rows),F(0))/3 for d in (0,1)) for rows in table]
    if dom(q,p) or dom(r,p):return False
    d=(q[0]-p[0],q[1]-p[1]);e=(r[0]-p[0],r[1]-p[1])
    if d[0]>0 and d[1]<0:d,e=e,d
    return d[0]<0<e[0] and e[1]<0<d[1] and (-d[0])*(-e[1])>d[1]*e[0]


def legal(table):
    return all(F(0)<=r[1]<=r[0]<=F(1) for rows in table for r in rows)


def false_completion(table,ns,d):
    fills=[(F(0),F(0))]*3
    if d['reason']=='P2':fills[0]=(F(1),F(1))
    else:fills[1]=fills[2]=(F(1),F(1))
    out=tuple(tuple(rows[:n])+tuple([fills[g]]*(3-n)) for g,(rows,n) in enumerate(zip(table,ns)))
    assert legal(out) and not actual_good(out)
    assert all(out[g][:n]==table[g][:n] for g,n in enumerate(ns))
    if d['reason']=='P2':
        low,_=bounds(out,(3,3,3));assert dom(low[d['offender']],low[0])
    else:
        low,_=bounds(out,(3,3,3));w=d['weight']
        assert min(w)>=0 and sum(w)>0
        score=lambda p:sum((x*y for x,y in zip(w,p)),F(0))
        assert all(score(q)>=score(low[0]) for q in low[1:])
    return out


def policy(table):
    # The policy reads only table[g][ns[g]]; all decisions depend on bounds
    # of rows already read. No actual_good, C*, or future value is consulted.
    ns=[0,0,0];trace=[]
    def read(g):
        assert ns[g]<3
        observed=table[g][ns[g]]
        trace.append((g,ns[g],observed));ns[g]+=1
    def complete():
        for g in range(3):
            while ns[g]<3:read(g)
        return analyse(table,tuple(ns))['TRUE'],len(trace),tuple(ns),'fallback'
    while ns[0]<3:read(0)
    p=bounds(table,ns)[0][0]
    for g in (1,2):
        while dom(bounds(table,ns)[0][g],p) and ns[g]<3:read(g)
        if dom(bounds(table,ns)[0][g],p):return complete()
    if analyse(table,ns)['TRUE']:return True,len(trace),tuple(ns),'screen'
    low,_=bounds(table,ns)
    nw=[g for g in (1,2) if low[g][1]>p[1] and low[g][0]<p[0]]
    se=[g for g in (1,2) if low[g][0]>p[0] and low[g][1]<p[1]]
    if len(nw)!=1 or len(se)!=1 or nw==se:return complete()
    compulsory=se[0] if p[0]-p[1]>F(1,3) else nw[0]
    other=3-compulsory
    while ns[compulsory]<3:
        read(compulsory)
        if analyse(table,ns)['TRUE']:return True,len(trace),tuple(ns),'compulsory'
    while ns[other]<3:
        read(other)
        if analyse(table,ns)['TRUE']:return True,len(trace),tuple(ns),'final_search'
    return analyse(table,ns)['TRUE'],len(trace),tuple(ns),'full'


def verify_true_states(table,trues):
    assert trues and all(n[0]==3 for n in trues)
    low,_=bounds(table,(3,3,3));p=low[0]
    nw=[g for g in (1,2) if low[g][0]<p[0]<low[3-g][0] and low[g][1]>p[1]>low[3-g][1]]
    assert len(nw)==1
    compulsory=3-nw[0] if p[0]-p[1]>F(1,3) else nw[0]
    assert all(n[compulsory]==3 for n in trues)
    return min(map(sum,trues))


def main():
    fp=HERE/'triangle_exact_fixtures_v1.json';fixture=json.loads(fp.read_text())
    records=[];negatives=[];reasons=Counter();fixture_prefixes=0
    for entry in fixture['fixtures']:
        rows=tuple(tuple(tuple(F(x) for x in r) for r in group) for group in entry['rows'])
        for swapped in (False,True):
            table=(rows[0],rows[2],rows[1]) if swapped else rows
            assert legal(table) and actual_good(table)==entry['GOOD']
            trues=[]
            for ns in itertools.product(range(4),repeat=3):
                fixture_prefixes+=1;d=analyse(table,ns)
                if d['TRUE']:trues.append(ns);continue
                completed=false_completion(table,ns,d);reasons[d['reason']]+=1
                item={'fixture':entry['id'],'rivals_swapped':swapped,'prefix':list(ns),'reason':d['reason'],
                      'rows':[[[str(v) for v in r] for r in group] for group in completed]}
                if 'offender' in d:item['offender']=d['offender']
                if 'weight' in d:item['support_weight']=[str(v) for v in d['weight']]
                negatives.append(item)
            answer,cost,end,branch=policy(table)
            assert answer==entry['GOOD'] and cost==sum(end)<=9
            result={'id':entry['id'],'rivals_swapped':swapped,'GOOD':answer,'paid_cost':cost,'end_prefix':list(end),'branch':branch,
                    'TRUE_prefixes':[list(v) for v in trues]}
            if answer:
                cstar=verify_true_states(table,trues)
                assert cstar==entry['C_star']==cost;result['C_star']=cstar
            else:assert not trues
            records.append(result)
    plan=fixture['confirmation_plan'];den=plan['sample_grid_denominator']
    alphabet=tuple((F(c,den),F(f,den)) for c in range(den+1) for f in range(c+1))
    rng=random.Random(plan['sample_seed']);sample_true=0;sample_prefixes=0;cert_counts=Counter();branches=Counter()
    for _ in range(plan['sample_tables']):
        table=tuple(tuple(rng.choice(alphabet) for _ in range(3)) for _ in range(3))
        truth=actual_good(table);answer,cost,end,branch=policy(table)
        assert answer==truth and cost==sum(end)<=9;branches[branch]+=1
        if truth:
            sample_true+=1
            trues=[ns for ns in itertools.product(range(4),repeat=3) if analyse(table,ns)['TRUE']]
            sample_prefixes+=64;cstar=verify_true_states(table,trues)
            assert cost==cstar;cert_counts[cstar]+=1
    negative_path=HERE/'triangle_negative_completions_v1.json'
    negative_path.write_text(json.dumps({'status':'ALL_REJECTED_FIXTURE_PREFIXES_HAVE_LEGAL_FALSE_COMPLETION','witnesses':negatives},indent=2)+'\n')
    out={'status':'PASS_FINITE_CORROBORATION','universal_claim_basis':'Analytic proof, not finite checks',
         'source_sha256':sha(Path(__file__)),'fixture_sha256':sha(fp),
         'proof_sha256':sha(HERE/'triangle_k3n3_exact_v2.txt'),'protocol_sha256':sha(HERE/'triangle_exact_PROTOCOL_v1.txt'),
         'fixture_archives':len(records),'fixture_prefix_states':fixture_prefixes,'fixture_results':records,
         'explicit_FALSE_completions':len(negatives),'FALSE_reason_counts':dict(reasons),
         'negative_file':negative_path.name,'negative_sha256':sha(negative_path),
         'sample':{'tables':plan['sample_tables'],'seed':plan['sample_seed'],'grid_denominator':den,'row_symbols':len(alphabet),
                   'GOOD_tables':sample_true,'FALSE_tables':plan['sample_tables']-sample_true,'prefix_states_on_GOOD':sample_prefixes,
                   'C_star_counts':dict(sorted(cert_counts.items())),'policy_branches':dict(branches)},
         'all_pass':True,'scope':'Exact on listed fixtures and fixed sample; not exhaustive full-grid or physical validation'}
    (HERE/'triangle_exact_check_v1.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k!='fixture_results'},indent=2))


if __name__=='__main__':main()
