#!/usr/bin/env python3
"""Own finite endpoint-domain check: enumerate ALL compatible completions.

No imports of prior project/oracle code. Full actual GOOD uses closed weight
intervals. Forcing TRUE is the AND of actual GOOD over all compatible finite
completions, compared afterward to the analytic continuous corner predicate.
"""
from fractions import Fraction as Q
from itertools import product
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
INPUT = HERE/'endpoint_transfer_fixtures_v1.json'
FREEZE = HERE/'endpoint_transfer_FREEZE_v1.json'
OUTPUT = HERE/'endpoint_transfer_results_v1.json'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def frozen():
    for name, digest in json.loads(FREEZE.read_text())['sha256'].items():
        assert sha(ROOT/name) == digest, name


def dominates(q,p):
    return all(q[d] <= p[d] for d in range(2)) and q != p


def supported(p, others):
    low, high = Q(0), Q(1)
    for q in others:
        dx, dy = q[0]-p[0], q[1]-p[1]
        slope = dx-dy
        if slope > 0:
            low = max(low,-dy/slope)
        elif slope < 0:
            high = min(high,-dy/slope)
        elif dy < 0:
            return False
        if low > high:
            return False
    return True


def actual_good(rows):
    means = [tuple(sum((r[d] for r in g),Q(0))/len(g) for d in range(2)) for g in rows]
    return not any(dominates(p,means[0]) for p in means[1:]) and not supported(means[0],means[1:])


def corners(prefixes, sizes):
    lower, upper = [], []
    for prefix,N in zip(prefixes,sizes):
        s = tuple(sum((r[d] for r in prefix),Q(0)) for d in range(2))
        lower.append(tuple(v/N for v in s))
        upper.append(tuple((v+N-len(prefix))/N for v in s))
    return lower,upper


def main():
    frozen()
    reports = []
    for case in json.loads(INPUT.read_text())['cases']:
        domains = [[[Q(x) for x in axis] for axis in row]
                   for group in case['alphabets'] for row in group]
        assert all(Q(0) in axis and Q(1) in axis and all(0<=x<=1 for x in axis)
                   for row in domains for axis in row)
        groups = []
        for group in case['alphabets']:
            rowpoints = [list(product(*(list(map(Q,axis)) for axis in row))) for row in group]
            groups.append(list(product(*rowpoints)))
        sizes = list(map(len,case['alphabets']))
        count_vectors = list(product(*(range(n+1) for n in sizes)))
        forcing = {}
        full_tables = positive_tables = incidences = 0
        # Full input enumeration accumulates every finite completion under
        # its exact observed prefix key; no corners are used for this step.
        for rows in product(*groups):
            good = actual_good(rows)
            full_tables += 1
            positive_tables += good
            for vector in count_vectors:
                key = tuple(rows[g][:n] for g,n in enumerate(vector))
                if key not in forcing:
                    forcing[key] = good
                elif not good:
                    forcing[key] = False
                incidences += 1
        true_prefixes = negative_witnesses = 0
        for prefixes,finite_true in forcing.items():
            lower,upper = corners(prefixes,sizes)
            culprit = next((g for g in range(1,len(groups)) if dominates(lower[g],upper[0])),None)
            corner_true = culprit is None and not supported(lower[0],upper[1:])
            assert finite_true == corner_true, (case['id'],prefixes)
            true_prefixes += finite_true
            if not corner_true:
                # Test the proof's explicit endpoint FALSE completion.
                completed = []
                for g,(prefix,N) in enumerate(zip(prefixes,sizes)):
                    endpoint = 1 if ((culprit is not None and g==0)
                                     or (culprit is None and g!=0)) else 0
                    completed.append(tuple(prefix)+((Q(endpoint),Q(endpoint)),)*(N-len(prefix)))
                assert not actual_good(completed)
                for g,rows in enumerate(completed):
                    for r,row in enumerate(rows):
                        for d,x in enumerate(row):
                            assert x in list(map(Q,case['alphabets'][g][r][d]))
                negative_witnesses += 1
        reports.append({'id':case['id'],'sizes':sizes,'full_legal_tables':full_tables,
            'positive_full_tables':positive_tables,'distinct_prefix_transcripts':len(forcing),
            'robust_TRUE_prefix_transcripts':true_prefixes,
            'completion_prefix_incidences':incidences,
            'explicit_endpoint_FALSE_witnesses':negative_witnesses})
    frozen()
    result = {'status':'PASS_EXHAUSTIVE_ENDPOINT_ALPHABET_TRUE_TRANSFER',
        'source_sha256':sha(Path(__file__)),'input_sha256':sha(INPUT),'freeze_sha256':sha(FREEZE),
        'results':reports,
        'scope':['Own exact stdlib code; no prior project or external imports.',
            'Finite forcing is computed from ALL compatible legal completions.',
            'Corner comparison occurs only after exhaustive finite forcing aggregation.',
            'Every failed corner test has a checked legal endpoint FALSE witness.',
            'Evidence is finite; universal endpoint-transfer proof is separate.',
            'No robust-FALSE equivalence or arbitrary-alphabet minimax equality claimed.']}
    OUTPUT.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,separators=(',',':')))


if __name__=='__main__':
    main()
