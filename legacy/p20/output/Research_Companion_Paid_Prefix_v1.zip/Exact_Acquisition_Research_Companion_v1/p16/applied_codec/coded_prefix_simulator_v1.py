#!/usr/bin/env python3
"""Exact, synthetic coded-prefix experiment. Python standard library only."""
import argparse
import hashlib
import json
from fractions import Fraction as Q
from pathlib import Path
from datetime import datetime, timezone

HERE = Path(__file__).resolve().parent
GROUPS = ("a", "L", "R")
N = 3
C = tuple(map(Q, ("0", "3/8", "5/8", "7/8", "1")))
F = tuple(map(Q, ("0", "7/8", "1")))
ROWS = tuple((c, f) for c in C for f in F)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def check(condition, message):
    if not condition:
        raise AssertionError(message)


def encode(row):
    row = tuple(map(Q, row))
    if row not in ROWS:
        raise ValueError("row is outside the public alphabet")
    return format(ROWS.index(row), "04b")


def decode(payload):
    if not isinstance(payload, str) or len(payload) != 4 or any(x not in "01" for x in payload):
        raise ValueError("payload must be exactly four binary digits")
    code = int(payload, 2)
    if code == 15:
        raise ValueError("code15 is reserved and invalid")
    return ROWS[code]


class CodedPrefixServer:
    """Server accepts only a group label; it chooses the next index."""
    def __init__(self, tables):
        self.__tables = {g: tuple(tuple(map(Q, r)) for r in tables[g]) for g in GROUPS}
        check(all(len(v) == N for v in self.__tables.values()), "each group must have three rows")
        for rows in self.__tables.values():
            for row in rows:
                encode(row)
        self.__cursor = {g: 0 for g in GROUPS}
        self.transcript = []

    def next_row(self, group):
        if group not in GROUPS:
            raise ValueError("unknown group")
        index = self.__cursor[group]
        if index == N:
            raise ValueError("prefix exhausted")
        payload = encode(self.__tables[group][index])
        self.__cursor[group] += 1
        record = {
            "step": len(self.transcript) + 1,
            "group": group,
            "index": index + 1,
            "payload": payload,
            "code": int(payload, 2),
            "unit_query_cost": 1,
            "numeric_payload_bits": 4,
        }
        self.transcript.append(record)
        return group, index + 1, payload


class RevealedStateClient:
    """Receives only a next-row callable and public N/alphabet."""
    def __init__(self, next_row):
        self.__request = next_row
        self.rows = {g: [] for g in GROUPS}
        self.log = []

    def query(self, group, phase):
        returned_group, index, payload = self.__request(group)
        check(returned_group == group, "response label mismatch")
        check(index == len(self.rows[group]) + 1, "response is not next in prefix")
        self.rows[group].append(decode(payload))
        self.log.append({
            "step": len(self.log) + 1, "group": group, "index": index,
            "payload": payload, "decoded_row": [str(x) for x in self.rows[group][-1]],
            "phase": phase, "prefix_counts": self.counts(),
            "queries_paid": len(self.log), "numeric_payload_bits_paid": 4 * len(self.log),
        })

    def counts(self):
        return {g: len(self.rows[g]) for g in GROUPS}

    def box(self, group):
        rows = self.rows[group]
        low = tuple(sum((r[j] for r in rows), Q()) / N for j in (0, 1))
        high = tuple(v + Q(N - len(rows), N) for v in low)
        return low, high

    def p2_safe(self, group):
        lower, _ = self.box(group)
        _, candidate_upper = self.box("a")
        return not (all(x <= y for x, y in zip(lower, candidate_upper))
                    and lower != candidate_upper)

    def robust_true(self):
        # Worst P2 corners: competitor SW versus candidate NE.
        if not all(self.p2_safe(g) for g in ("L", "R")):
            return False
        # Hardest P4 corners: candidate SW versus competitor NE.
        # Support is existence of t in closed [0,1] with d_f+t(d_c-d_f)>=0.
        candidate_lower, _ = self.box("a")
        lo, hi = Q(), Q(1)
        for group in ("L", "R"):
            _, upper = self.box(group)
            dc, df = (upper[j] - candidate_lower[j] for j in (0, 1))
            slope = dc - df
            if slope == 0:
                if df < 0:
                    return True
            elif slope > 0:
                lo = max(lo, -df / slope)
            else:
                hi = min(hi, -df / slope)
        return lo > hi

    def finish(self, answer, reason):
        check(not answer or self.robust_true(), "TRUE lacks a robust certificate")
        if not answer:
            check(all(len(v) == N for v in self.rows.values()), "FALSE requires full fallback here")
            check(not self.robust_true(), "FALSE contradicts complete data")
        return {
            "answer": answer, "stop_reason": reason, "queries": len(self.log),
            "numeric_payload_bits": 4 * len(self.log), "prefix_counts": self.counts(),
            "client_log": self.log,
        }

    def census_fallback(self):
        for group in GROUPS:
            while len(self.rows[group]) < N:
                self.query(group, "full_census_fallback")
                if self.robust_true():
                    return self.finish(True, "ROBUST_TRUE_DURING_FALLBACK")
        return self.finish(self.robust_true(), "FULL_CENSUS_TRUE" if self.robust_true()
                           else "FULL_CENSUS_FALSE")


def policy_a(client, fair_tail_order):
    # The fair order is an externally enumerated, value-independent coin outcome.
    for _ in range(N):
        client.query("a", "A_candidate_census")
        if client.robust_true():
            return client.finish(True, "ROBUST_TRUE")
    for group in ("L", "R"):
        while not client.p2_safe(group) and len(client.rows[group]) < N:
            client.query(group, "A_P2_screen")
            if client.robust_true():
                return client.finish(True, "ROBUST_TRUE")
        if not client.p2_safe(group):
            return client.census_fallback()
    if client.robust_true():
        return client.finish(True, "ROBUST_TRUE")
    for group in ("L", "R"):
        while len(client.rows[group]) < 2:
            client.query(group, "A_raise_to_two")
            if client.robust_true():
                return client.finish(True, "ROBUST_TRUE")
    for group in fair_tail_order:
        while len(client.rows[group]) < N:
            client.query(group, "A_fair_tails")
            if client.robust_true():
                return client.finish(True, "ROBUST_TRUE")
    return client.census_fallback()


def policy_b(client):
    for group, count in (("a", 2), ("L", 3), ("R", 3)):
        while len(client.rows[group]) < count:
            client.query(group, "B_candidate_two_competitor_censuses")
    if client.robust_true():
        return client.finish(True, "ROBUST_TRUE_AT_233")
    client.query("a", "B_candidate_last")
    return client.census_fallback()


def one_run(tables, policy, order=None):
    server = CodedPrefixServer(tables)
    client = RevealedStateClient(server.next_row)
    result = policy_a(client, order) if policy == "A" else policy_b(client)
    check(len(server.transcript) == result["queries"], "server/client cost mismatch")
    last = {g: 0 for g in GROUPS}
    for record in server.transcript:
        g = record["group"]
        check(record["index"] == last[g] + 1, "server index sequence violated")
        last[g] += 1
        check(record["payload"] == encode(decode(record["payload"])), "wire roundtrip")
    check(last == result["prefix_counts"], "final prefix mismatch")
    result["server_log"] = server.transcript
    return result


def codec_controls():
    for code, row in enumerate(ROWS):
        check(int(encode(row), 2) == code, "public code order mismatch")
        check(decode(encode(row)) == row, "codec roundtrip failure")
    invalid = ["1111", "", "000", "00000", "0x01", "abcd"]
    for value in invalid:
        try:
            decode(value)
        except ValueError:
            pass
        else:
            raise AssertionError("invalid wire payload accepted")
    try:
        encode((Q(1, 8), Q()))
    except ValueError:
        pass
    else:
        raise AssertionError("out-of-alphabet row accepted")
    dummy = {g: [(Q(), Q())] * N for g in GROUPS}
    server = CodedPrefixServer(dummy)
    for _ in range(N):
        server.next_row("a")
    for group in ("a", "unknown"):
        try:
            server.next_row(group)
        except ValueError:
            pass
        else:
            raise AssertionError("illegal server request accepted")
    return {
        "valid_codes_roundtripped": 15, "bits_per_numeric_row": 4,
        "invalid_code15_rejected": True, "malformed_payloads_rejected": len(invalid) - 1,
        "out_of_alphabet_row_rejected": True, "exhausted_and_unknown_group_rejected": True,
        "public_codebook": [
            {"code": i, "bits": format(i, "04b"), "row": [str(x) for x in r]}
            for i, r in enumerate(ROWS)],
    }


def verify_freeze(freeze_path):
    data = json.loads(Path(freeze_path).read_text())
    for name, expected in data["sha256"].items():
        check(digest(HERE / name) == expected, "freeze hash mismatch: " + name)
    return data


def run_suite(fixtures):
    result = {
        "schema": "p16-coded-prefix-simulator-results-v1",
        "status": "PASS_EXACT_SYNTHETIC_CODED_PREFIX_CONTROLS",
        "codec": codec_controls(), "worlds": {}, "false_controls": {},
        "scope": [
            "Synthetic rational tables, not physical measurements",
            "4-bit numeric row payload excludes IDs, indices, framing, headers, setup and retransmissions",
            "No security, OGC conformity, deployment, measured bandwidth or energy-saving claim",
            "Client corner certificates use continuous independent [0,1]^2 missing-row completions",
            "Public finite alphabet used only for wire coding; no finite-alphabet minimax equality claimed",
            "Finite controls do not prove universal minimax or universal corner equivalence",
        ],
    }
    branches = (("A_LR", "A", ("L", "R"), Q(8, 23)),
                ("A_RL", "A", ("R", "L"), Q(8, 23)),
                ("B", "B", None, Q(7, 23)))
    check(sum(x[3] for x in branches) == 1, "mixture weights do not sum to one")
    for name, world in fixtures["worlds"].items():
        runs = {}
        mean = Q()
        for label, policy, order, weight in branches:
            run = one_run(world["tables"], policy, order)
            check(run["answer"] is True, "canonical world not certified TRUE")
            run["mixture_weight"] = str(weight)
            mean += weight * run["queries"]
            runs[label] = run
        expected = Q(world["expected_mixture_queries"])
        comparator = Q(world["analytically_declared_C_star"])
        check(mean == expected, "mixture expected cost mismatch")
        check(mean / comparator == Q(25, 23), "canonical ratio mismatch")
        result["worlds"][name] = {
            "runs": runs, "expected_queries": str(mean),
            "expected_numeric_payload_bits": str(4 * mean),
            "analytically_declared_C_star": str(comparator),
            "ratio_against_declared_comparator": str(mean / comparator),
        }
    for name, tables in fixtures["full_false_controls"].items():
        runs = {}
        for label, policy, order, weight in branches:
            run = one_run(tables, policy, order)
            check(run["answer"] is False, "FALSE control labelled TRUE")
            check(run["stop_reason"] == "FULL_CENSUS_FALSE", "FALSE fallback not full")
            check(run["queries"] == 9, "FALSE control did not use all rows")
            runs[label] = run
        result["false_controls"][name] = runs
    result["run_count"] = sum(len(w["runs"]) for w in result["worlds"].values()) + sum(
        len(w) for w in result["false_controls"].values())
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fixtures", type=Path, default=HERE / "coded_prefix_fixtures_v1.json")
    parser.add_argument("--freeze", type=Path, default=HERE / "coded_prefix_FREEZE_v1.json")
    parser.add_argument("--output", type=Path, default=HERE / "coded_prefix_results_v1.json")
    args = parser.parse_args()
    if args.output.exists():
        raise SystemExit("Output exists; preserve it and choose a new --output path.")
    status = 0
    try:
        freeze = verify_freeze(args.freeze)
        check(args.fixtures.resolve() == (HERE / "coded_prefix_fixtures_v1.json").resolve(),
              "this frozen suite requires the canonical fixture file")
        fixtures = json.loads(args.fixtures.read_text())
        result = run_suite(fixtures)
        result["freeze"] = {"path": args.freeze.name, "sha256": digest(args.freeze),
                            "status": freeze["status"]}
    except Exception as exc:
        status = 1
        result = {"schema": "p16-coded-prefix-simulator-results-v1", "status": "FAILED",
                  "error_type": type(exc).__name__, "error": str(exc)}
    result["executed_at_utc"] = datetime.now(timezone.utc).isoformat()
    result["script_sha256"] = digest(__file__)
    result["fixture_sha256"] = digest(args.fixtures)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"status": result["status"], "output": str(args.output),
                      "run_count": result.get("run_count")}, indent=2))
    return status


if __name__ == "__main__":
    raise SystemExit(main())

