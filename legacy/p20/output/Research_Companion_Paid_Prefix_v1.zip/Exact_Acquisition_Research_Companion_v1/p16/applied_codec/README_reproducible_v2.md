# Reproducible codec simulator v2

Frozen v1 remains preserved. Version2 changes timestamp handling only.
For deterministic replay, read `executed_at_utc` from
`coded_prefix_results_v2.json` and run:

```sh
python p16/applied_codec/coded_prefix_simulator_v2.py --executed-at-utc STAMP --output /path/to/new-result.json
```

Use that exact stamp in place of `STAMP`. The new result must be byte identical
to the canonical v2 result. `SOURCE_DATE_EPOCH` is also supported; the explicit
flag takes precedence. With neither, the script records current time normally.
Existing outputs are never overwritten.

`executed_at_utc` is controlled replay metadata when supplied explicitly.
The separate execution record retains actual audit time. Code, fixtures and
protocol were frozen before first v2 execution. Scientific computation,
wire codebook, policies, controls and full query logs are unchanged from v1.

The finite public codebook describes only four logical numeric payload bits.
Continuous product completions remain in the certificate check. All physical,
security, deployment and standards claims remain excluded as in the v1 README.
