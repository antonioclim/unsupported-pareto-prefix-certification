# Coded prefix simulator

A standalone Python standard-library illustration of paid prefix observations
for the specified synthetic A/D archives. Run from any directory:

```sh
python p16/applied_codec/coded_prefix_simulator_v1.py
```

The default output is `coded_prefix_results_v1.json`. Existing results are
preserved. For a separate replay, use `--output /path/to/replay.json`.
The script validates the frozen code/fixtures/protocol hashes before checking
the codec and running all18 policy/control paths.

The server accepts a group label and returns its next indexed four-bit row.
The client sees only responses and uses exact rational continuous-box
certificates. Results include complete server/client logs and exact mixture
costs. The analytic comparator values8/7 are declared fixture inputs.

Four bits represent only a numeric row from the public15-row codebook.
Group identifiers, indices, headers, framing, setup and retransmissions are
excluded. The completion checker retains continuous product[0,1]^2 tails;
the codebook does not establish a finite-alphabet minimax theorem.

This is synthetic local computation. It establishes no physical communication,
security, deployment, OGC conformity or measured resource-saving result.
See the frozen protocol for precise policy and test scope.

