#!/usr/bin/env python3
"""Own exact finite-alphabet confirmation with explicit FALSE completions."""
import hashlib
import itertools
import json
from fractions import Fraction as F
from functools import lru_cache
from pathlib import Path

ROOT=Path(__file__).resolve().parent


def bounds(table,ns):
    low=[];up=[]
    for group,n in zip(table,ns):
        p=tuple(sum(r[d] for r in group[:n])/3 for d in (0,1))
        low.append(p);up.append(tuple(v+F(3-n,3) for v in p))
    return low,up


def dom(p,q):return p[0]<=q[0] and p[1]<=q[1] and p!=q


def analyse(table,ns):
    low,up=bounds(table,ns)
    for g in (1,2):
        if dom(low[g],up[0]):return {'TRUE':False,'reason':'P2','offender':g}
    lo,hi=F(0),F(1)
    for p in up[1:]:
        dx,dy=p[0]-low[0][0],p[1]-low[0][1];s=dx-dy
        if s>0:lo=max(lo,-dy/s)
        elif s<0:hi=min(hi,-dy/s)
        elif dy<0:return {'TRUE':True}
    if lo>hi:return {'TRUE':True}
    t=(lo+hi)/2
    return {'TRUE':False,'reason':'P4','weight':(t,1-t)}


def actual_good(table):
    # Independent full-point two-witness determinant test, rather than
    # reusing the support-interval prefix implementation.
    p,q,r=[tuple(sum(row[d] for row in group)/3 for d in (0,1)) for group in table]
    if dom(q,p) or dom(r,p):return False
    d,e=(q[0]-p[0],q[1]-p[1]),(r[0]-p[0],r[1]-p[1])
    if d[0]>0 and d[1]<0:d,e=e,d
    return d[0]<0 and d[1]>0 and e[0]>0 and e[1]<0 and (-d[0])*(-e[1])>d[1]*e[0]


def false_completion(table,ns,diagnosis):
    fills=[(F(0),F(0))]*3
    if diagnosis['reason']=='P2':fills[0]=(F(1),F(1))
    else:fills[1]=fills[2]=(F(1),F(1))
    completed=tuple(tuple(group[:n])+tuple([fills[g]]*(3-n)) for g,(group,n) in enumerate(zip(table,ns)))
    assert all(completed[g][:ns[g]]==table[g][:ns[g]] for g in range(3))
    assert not actual_good(completed)
    low,up=bounds(completed,(3,3,3))
    if diagnosis['reason']=='P2':assert dom(low[diagnosis['offender']],low[0])
    else:
        w=diagnosis['weight'];assert all(x>=0 for x in w) and sum(w)>0
        score=lambda x:sum(a*b for a,b in zip(w,x))
        assert all(score(x)>=score(low[0]) for x in low[1:])
    return completed


def main():
    fixture_path=ROOT/'dyadic_exact_fixtures_v1.json'
    f=json.loads(fixture_path.read_text())
    C=tuple(F(x) for x in f['cost_alphabet']);Fset=tuple(F(x) for x in f['failure_alphabet'])
    assert F(0) in C and F(1) in C and F(0) in Fset and F(1) in Fset
    worlds=[tuple(tuple(tuple(F(x) for x in row) for row in group) for group in w['rows']) for w in f['worlds']]
    legal=lambda table:all(row[0] in C and row[1] in Fset for group in table for row in group)
    negatives=[];world_results=[];reason_counts={'P2':0,'P4':0}
    for source,table in zip(f['worlds'],worlds):
        assert legal(table) and actual_good(table)
        trues=[]
        for ns in itertools.product(range(4),repeat=3):
            diagnosis=analyse(table,ns)
            if diagnosis['TRUE']:trues.append(list(ns));continue
            completed=false_completion(table,ns,diagnosis);assert legal(completed)
            reason_counts[diagnosis['reason']]+=1
            entry={'world':source['id'],'prefix':list(ns),'reason':diagnosis['reason'],
                   'rows':[[[str(x) for x in row] for row in group] for group in completed]}
            if 'offender' in diagnosis:entry['offender']=diagnosis['offender']
            if 'weight' in diagnosis:entry['support_weight']=[str(x) for x in diagnosis['weight']]
            negatives.append(entry)
        assert trues==source['expected_TRUE_prefixes']
        minimum=min(map(sum,trues));assert minimum==source['expected_C_B']
        world_results.append({'id':source['id'],'C_finite':minimum,'TRUE_prefixes':trues})
    assert len(negatives)==f['expected_negative_prefixes']
    weights=tuple(F(w['raw_cost_prior']) for w in f['worlds']);assert sum(weights)==1
    root_actions={}

    @lru_cache(None)
    def V(ns,ids):
        if analyse(worlds[ids[0]],ns)['TRUE']:return F(0)
        mass=sum(weights[q] for q in ids);actions={}
        for g in range(3):
            if ns[g]==3:continue
            buckets={}
            for q in ids:buckets.setdefault(worlds[q][g][ns[g]],[]).append(q)
            nn=tuple(n+(j==g) for j,n in enumerate(ns))
            actions[g]=1+sum(sum(weights[q] for q in bucket)/mass*V(nn,tuple(bucket)) for bucket in buckets.values())
        assert actions
        if ns==(0,0,0):root_actions.update({str(g):str(v) for g,v in actions.items()})
        return min(actions.values())

    raw=V((0,0,0),(0,1));assert raw==F(f['expected_raw_Bayes_cost'])
    ratio_mass=sum(F(w['ratio_weight'])/w['expected_C_B'] for w in f['worlds'])
    assert ratio_mass==F(3,23) and raw*ratio_mass==F(f['expected_ratio_value'])
    # Direct positive robust mixture checks, exact and strictly separated.
    low,up=bounds(worlds[0],(2,3,3));lam=F(17,28)
    mix=tuple(lam*up[1][d]+(1-lam)*up[2][d] for d in (0,1))
    assert tuple(low[0][d]-mix[d] for d in (0,1))==(F(1,224),F(1,672))
    low,up=bounds(worlds[1],(3,3,1));lam=F(4,5)
    mix=tuple(lam*up[1][d]+(1-lam)*up[2][d] for d in (0,1))
    assert mix==(F(23,120),F(9,10)) and all(mix[d]<low[0][d] for d in (0,1))
    witness_path=ROOT/'dyadic_negative_completions_v1.json'
    witness_path.write_text(json.dumps({'status':'ALL_REJECTED_PREFIXES_HAVE_ADMISSIBLE_FALSE_COMPLETION','witnesses':negatives},indent=2)+'\n')
    out={'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
         'fixture_sha256':hashlib.sha256(fixture_path.read_bytes()).hexdigest(),
         'worlds':world_results,'prefix_states_enumerated':128,'explicit_FALSE_completions':len(negatives),
         'FALSE_reason_counts':reason_counts,'negative_witness_file':witness_path.name,
         'negative_witness_sha256':hashlib.sha256(witness_path.read_bytes()).hexdigest(),
         'Bellman_states':V.cache_info().currsize,'raw_Bayes_cost':str(raw),'ratio_mass':str(ratio_mass),
         'ratio_value':str(raw*ratio_mass),'root_action_values':root_actions,
         'cost_levels':len(C),'failure_levels':len(Fset),'product_row_symbols':len(C)*len(Fset),
         'joint_row_payload_bits':4,'discovery_provenance':f['discovery_provenance'],'all_pass':True,
         'scope':'Exact finite-alphabet witness/Bayes confirmation; universal transfer proved analytically.'}
    (ROOT/'dyadic_exact_check_v1.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))


if __name__=='__main__':main()
