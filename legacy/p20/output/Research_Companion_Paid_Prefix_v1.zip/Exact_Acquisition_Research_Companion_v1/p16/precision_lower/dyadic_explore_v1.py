#!/usr/bin/env python3
"""Exploratory exact checks of analytically selected dyadic replacements.
Not preregistered discovery; no search/minimality over all grids is claimed.
"""
import hashlib
import itertools
import json
from fractions import Fraction as F
from pathlib import Path

ROOT=Path(__file__).resolve().parent


def true_prefix(table,ns):
    low=[];up=[]
    for group,n in zip(table,ns):
        p=tuple(sum(r[d] for r in group[:n])/3 for d in (0,1))
        low.append(p);up.append(tuple(v+F(3-n,3) for v in p))
    if any(p[0]<=up[0][0] and p[1]<=up[0][1] and p!=up[0] for p in low[1:]):return False
    lo,hi=F(0),F(1)
    for p in up[1:]:
        dx,dy=p[0]-low[0][0],p[1]-low[0][1];s=dx-dy
        if s>0:lo=max(lo,-dy/s)
        elif s<0:hi=min(hi,-dy/s)
        elif dy<0:return True
    return lo>hi


def tables(a,b,l,r,s,t,u,v):
    common=[[(a,b)]*2,[(F(0),l)]*2,[(r,F(0)),(s,F(0))]]
    return [tuple(tuple(common[g]+[tail[g]]) for g in range(3)) for tail in
            [[(F(0),F(0)),(F(0),t),(u,F(0))],
             [(F(0),v),(F(0),t),(F(1),F(1))]]]


def main():
    candidates={'sixteenth':tables(F(7,16),F(14,16),F(15,16),F(15,16),F(9,16),F(1),F(7,16),F(14,16)),
                'eighth':tables(F(3,8),F(7,8),F(1),F(7,8),F(5,8),F(7,8),F(3,8),F(1))}
    cases=[]
    for name,worlds in candidates.items():
        descriptions=[]
        for label,table in zip(('A','D'),worlds):
            assert all(0<=v<=1 for group in table for row in group for v in row)
            trues=[ns for ns in itertools.product(range(4),repeat=3) if true_prefix(table,ns)]
            descriptions.append({'id':label,'rows':[[[str(v) for v in row] for row in group] for group in table],
                                 'C_B':min(map(sum,trues)),'TRUE_prefixes':[list(s) for s in trues]})
        cases.append({'candidate':name,'worlds':descriptions})
    out={'status':'EXPLORATORY_COMPLETE_NOT_PREREGISTERED','source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
         'cases':cases,'scope':'Selected dyadic candidates only; no global smallest-grid claim.'}
    (ROOT/'dyadic_explore_v1.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({x['candidate']:[{k:w[k] for k in ('id','C_B','TRUE_prefixes')} for w in x['worlds']] for x in cases},indent=2))


if __name__=='__main__':main()
