#!/usr/bin/env python3
"""Independent exhaustive compatible-completion and exact Bellman controls."""
from fractions import Fraction as Q
from itertools import product
from functools import lru_cache
from pathlib import Path
import hashlib,json
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dominates(a,b):return all(x<=y for x,y in zip(a,b)) and a!=b
def unsupported(p,others):
    # A supporting nonnegative weight is (t,1-t), 0<=t<=1.
    lo,hi=Q(0),Q(1)
    for q in others:
        b=p[1]-q[1];a=p[0]-q[0]-b
        if a>0:hi=min(hi,-b/a)
        elif a<0:lo=max(lo,-b/a)
        elif b>0:return True
    return lo>hi
def good(points):return not any(dominates(p,points[0]) for p in points[1:]) and unsupported(points[0],points[1:])
def corners(rows,n):
    N=len(rows[0]);out=[]
    for g,k in zip(rows,n):
        low=tuple(sum((r[d] for r in g[:k]),Q(0))/N for d in (0,1))
        up=tuple(x+Q(N-k,N) for x in low);out.append((low,up))
    return out
def forced(rows,n):
    b=corners(rows,n)
    return not any(dominates(v[0],b[0][1]) for v in b[1:]) and unsupported(b[0][0],[v[1] for v in b[1:]])
def means(rows):return [tuple(sum((r[d] for r in g),Q(0))/len(g) for d in (0,1)) for g in rows]
def witness(rows,n):
    b=corners(rows,n)
    bad=next((i for i in (1,2) if dominates(b[i][0],b[0][1])),None)
    if bad is not None:fill=[(Q(1),Q(1)),(Q(0),Q(0)),(Q(0),Q(0))]
    else:fill=[(Q(0),Q(0)),(Q(1),Q(1)),(Q(1),Q(1))]
    return [g[:k]+[f]*(len(g)-k) for g,k,f in zip(rows,n,fill)]
def main():
    freeze=json.loads((HERE/'FREEZE_v1.json').read_text())
    for p,h in freeze['sha256'].items():assert digest(ROOT/p)==h,p
    fixture=json.loads((HERE/'fixtures_v1.json').read_text())
    levels=[Q(x) for x in fixture['exhaustive_levels']]
    pts=list(product(levels,repeat=2));observed={};relations=0;fullpositive=0
    # The aggregate is explicitly over every legal compatible complete table.
    for points in product(pts,repeat=3):
        g=good(points);fullpositive+=int(g)
        for mask in product((0,1),repeat=3):
            key=tuple(p if m else None for p,m in zip(points,mask))
            observed[key]=observed.get(key,True) and g;relations+=1
    robustpositives=0
    for key,answer in observed.items():
        rows=[[p if p is not None else (Q(0),Q(0))] for p in key]
        n=tuple(int(p is not None) for p in key)
        assert forced(rows,n)==answer,(key,answer)
        robustpositives+=int(answer)
        if not answer:
            w=witness(rows,n)
            assert not good(means(w))
            assert all(w[i][:n[i]]==rows[i][:n[i]] for i in range(3))
            assert all(x in levels for group in w for row in group for x in row)
    worlds=[[[tuple(Q(x) for x in r) for r in group] for group in w['rows']] for w in fixture['worlds']]
    C={Q(x) for x in fixture['cost_levels']};F={Q(x) for x in fixture['failure_levels']}
    records=[];negativewitnesses=0
    for f,rows in zip(fixture['worlds'],worlds):
        true=[]
        for n in product(range(4),repeat=3):
            if forced(rows,n):true.append(list(n))
            else:
                w=witness(rows,n);assert not good(means(w))
                assert all(w[i][:n[i]]==rows[i][:n[i]] for i in range(3))
                assert all(x in C and y in F for group in w for x,y in group)
                negativewitnesses+=1
        assert true==f['expected_TRUE_prefixes']
        cb=min(sum(n) for n in true);assert cb==f['C_star']
        records.append({'world':f['id'],'TRUE_prefixes':true,'C_star':cb,'means':[[str(x) for x in p] for p in means(rows)]})
    prior=[Q(16,23),Q(7,23)];denom=[Q(8),Q(7)];visits=0
    @lru_cache(None)
    def bellman(ids,n):
        nonlocal visits
        visits+=1
        if forced(worlds[ids[0]],n):
            assert all(forced(worlds[i],n) for i in ids);return Q(0)
        mass=sum((prior[i] for i in ids),Q(0))
        step=sum((prior[i]/denom[i] for i in ids),Q(0))/mass
        options=[]
        for g in range(3):
            if n[g]==3:continue
            branches={}
            for i in ids:branches.setdefault(worlds[i][g][n[g]],[]).append(i)
            nn=list(n);nn[g]+=1
            options.append(step+sum((sum((prior[i] for i in branch),Q(0))/mass*bellman(tuple(branch),tuple(nn)) for branch in branches.values()),Q(0)))
        assert options;return min(options)
    value=bellman((0,1),(0,0,0));assert value==Q(25,23)
    for p,h in freeze['sha256'].items():assert digest(ROOT/p)==h,p
    out={'status':'PASS','source_sha256':digest(Path(__file__)),'method':'direct all-compatible-completion aggregation before corner comparison; independent support interval and endpoint countercompletion checker',
         'N1_complete_tables':len(pts)**3,'N1_GOOD_complete_tables':fullpositive,'N1_distinct_prefix_transcripts':len(observed),'N1_completion_prefix_relations':relations,'N1_robust_TRUE_transcripts':robustpositives,
         'dyadic_prefix_states':128,'dyadic_explicit_FALSE_completions':negativewitnesses,'worlds':records,'ratio_Bellman':str(value),'ratio_Bellman_states':visits,
         'limitations':['Synthetic exact controls, not physical measurements','Finite control enumeration does not replace the analytic universal theorem','N1 completion domain is fully enumerated; N3 full domain is not enumerated','No producer or historical oracle imported']}
    (HERE/'results_v1.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
