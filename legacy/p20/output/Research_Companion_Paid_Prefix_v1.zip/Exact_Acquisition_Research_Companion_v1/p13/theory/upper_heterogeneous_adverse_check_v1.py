#!/usr/bin/env python3
"""Exact adverse control for pure balanced versus P12 padded scheduling."""
from fractions import Fraction as F
from itertools import permutations
from pathlib import Path
import hashlib,json
HERE=Path(__file__).resolve().parent
INPUT=HERE/'upper_heterogeneous_adverse_fixture_v1.json'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dominates(a,b):return a[0]<=b[0] and a[1]<=b[1] and a!=b
def mean(rows):return tuple(sum(row[j] for row in rows)/len(rows) for j in (0,1))
def schedule(word,L,R):
    a=b=0;out=[]
    for side in word:
        if side=='L':out.append(L[a]);a+=1
        else:out.append(R[b]);b+=1
    return out
def main():
    f=json.loads(INPUT.read_text());sourcehash=sha(Path(__file__));inputhash=sha(INPUT)
    N=f['N'];p=mean([[F(x) for x in row] for row in f['candidate_rows']]);hs={};rs={};means={};sides={};thresholds={}
    for c in f['competitors']:
        label=c['label'];rows=[[F(x) for x in row] for row in c['rows']]
        assert len(rows)==N and all(x>=0 and 0<=y<=1 for x,y in rows)
        z=mean(rows);assert not dominates(z,p);means[label]=z;sides[label]=c['side']
        low=[F(),F()]
        assert dominates(tuple(low),p)
        h=None
        for t,row in enumerate(rows,1):
            low=[low[j]+row[j]/N for j in (0,1)]
            if h is None and not dominates(tuple(low),p):h=t
        hs[label]=h;rs[label]=N-h
        dx,dy=z[0]-p[0],z[1]-p[1]
        threshold=dy/(-dx) if sides[label]=='L' else (-dy)/dx
        assert threshold==F(c['threshold']);thresholds[label]=threshold
    labels=[c['label'] for c in f['competitors']]
    assert [hs[x] for x in labels]==f['expected_h']
    L=[x for x in labels if sides[x]=='L'];R=[x for x in labels if sides[x]=='R']
    edges={(l,r) for l in L for r in R if thresholds[l]<thresholds[r]}
    W=set(f['unique_witness']);assert edges=={tuple(f['unique_witness'])}
    H=N+sum(hs.values());C=H+sum(rs[x] for x in W)
    assert H==F(f['expected_H']) and C==F(f['expected_Cstar'])
    def cost(order):
        seen=set();paid=H
        for x in order:
            if x is not None:seen.add(x);paid+=rs[x]
            if W<=seen:return paid
        raise AssertionError('Missing witness')
    new_orders=[schedule(f['new_balanced_word'],l,r) for l in permutations(L) for r in permutations(R)]
    old_orders=[schedule(word,l,r) for l in permutations(L+[None]) for r in permutations(R) for word in ('LRLRLR','RLRLRL')]
    new=F(sum(cost(o) for o in new_orders),len(new_orders));old=F(sum(cost(o) for o in old_orders),len(old_orders))
    assert new==F(f['expected_new_cost']) and old==F(f['expected_old_padded_cost'])
    assert new-old==F(f['expected_new_minus_old'])>0
    assert new==C+F(5,6)*rs['L1']+F(1,2)*(rs['R1']+rs['R2'])
    assert old==C+F(23,36)*(rs['L1']+rs['R1']+rs['R2'])
    assert sha(INPUT)==inputhash and sha(Path(__file__))==sourcehash
    result={'status':'PASS_EXACT_HETEROGENEOUS_ADVERSE_CONTROL','fixture_sha256':inputhash,'source_sha256':sourcehash,'K':f['K'],'N':N,'h':hs,'residuals':rs,'H':str(H),'Cstar':str(C),'new_schedule_count':len(new_orders),'old_schedule_count':len(old_orders),'new_expected_cost':str(new),'old_expected_cost':str(old),'new_minus_old':str(new-old),'new_nonwitness_inclusion':{'L1':'5/6','R1':'1/2','R2':'1/2'},'old_nonwitness_inclusion':{'L1':'23/36','R1':'23/36','R2':'23/36'},'scope':'Exact rational own archive and exhaustive virtual schedules. Global minimax improvement does not imply per-instance policy dominance.'}
    (HERE/'upper_heterogeneous_adverse_results_v1.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
