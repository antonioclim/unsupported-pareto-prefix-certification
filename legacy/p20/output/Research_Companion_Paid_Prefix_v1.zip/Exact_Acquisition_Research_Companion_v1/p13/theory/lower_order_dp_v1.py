#!/usr/bin/env python3
"""Own exact comparison-observation Bayes DP; no external packages.

The state retains the sorted queried labels. Worlds are all independent
within-side rank assignments. Each query reveals its insertion position.
The solver does not use a count-state transition formula or a fixed word.
"""
import hashlib
import itertools
import json
from fractions import Fraction
from functools import lru_cache
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CASES = [(m, n) for m in range(1, 4) for n in range(m, 7) if m+n <= 7]


def solve(m, n):
    k = m+n
    left_ranks = (n-1,) + tuple(range(n+1, k))
    right_ranks = tuple(range(n-1)) + (n,)
    worlds = tuple(l+r for l in itertools.permutations(left_ranks)
                   for r in itertools.permutations(right_ranks))
    root_actions = None

    @lru_cache(None)
    def compatible(observed):
        return tuple(i for i, ranks in enumerate(worlds)
                     if tuple(sorted(observed, key=lambda j: ranks[j])) == observed)

    @lru_cache(None)
    def value(observed):
        nonlocal root_actions
        if any(observed[i] < m and observed[j] >= m
               for i in range(len(observed))
               for j in range(i+1, len(observed))):
            return Fraction(0)
        ids = compatible(observed)
        assert ids and len(observed) < k
        actions = {}
        for label in range(k):
            if label in observed:
                continue
            buckets = {}
            for world_id in ids:
                ranks = worlds[world_id]
                next_observed = tuple(sorted(observed+(label,), key=lambda j: ranks[j]))
                buckets[next_observed] = buckets.get(next_observed, 0)+1
            actions[label] = Fraction(1) + sum(
                Fraction(number, len(ids))*value(next_observed)
                for next_observed, number in buckets.items())
        if not observed:
            root_actions = {str(label): str(v) for label, v in actions.items()}
        return min(actions.values())

    optimum = value(())
    # Algebraic target is checked only after the independent finite solver.
    target = Fraction(m) + Fraction(n+1, 2) - Fraction(m*m-1, 6*n)
    return {"m": m, "n": n, "worlds": len(worlds),
            "optimum": str(optimum), "target": str(target),
            "agrees": optimum == target, "root_action_values": root_actions,
            "value_states": value.cache_info().currsize,
            "posterior_states": compatible.cache_info().currsize}


def main():
    cases = [solve(m, n) for m, n in CASES]
    result = {"method": "exact Fraction Bellman DP on all rank-assignment worlds",
              "observation": "relative insertion position only",
              "stop": "first observed strict L<R pair",
              "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "cases": cases, "all_agree": all(c["agrees"] for c in cases)}
    out = ROOT / "lower_order_dp_v1.json"
    out.write_text(json.dumps(result, indent=2)+"\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
