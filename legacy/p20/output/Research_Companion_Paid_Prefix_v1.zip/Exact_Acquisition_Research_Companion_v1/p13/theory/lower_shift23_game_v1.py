#!/usr/bin/env python3
"""Own exact Bayesian edge-certificate game; no external project code.

Full values are exposed by a vertex query. The stopping condition requires
an actual observed strict L<R pair, independently of the all-positive prior.
"""
from fractions import Fraction as Q
from functools import lru_cache
from itertools import permutations
from pathlib import Path
import hashlib,json,time

LEFT=(1,3)
RIGHT=(-2,0,2)

def worlds(M,left=LEFT,right=RIGHT):
    rows=[]
    for t in range(1,M+1):
        for a in permutations(left):
            for b in permutations(right):rows.append(tuple(2*t+v for v in a+b))
    assert len(rows)==len(set(rows))
    assert all(sum(x<y for x in w[:len(left)] for y in w[len(left):])==1 for w in rows)
    return tuple(rows)

def game(M,left=LEFT,right=RIGHT,retain_first=True):
    inputs=worlds(M,left,right);m=len(left);k=m+len(right)
    root=[None]*k;first={}
    @lru_cache(None)
    def value(observed):
        if any(observed[i] is not None and observed[j] is not None and observed[i]<observed[j]
               for i in range(m) for j in range(m,k)):return Q()
        posterior=[w for w in inputs if all(v is None or v==w[i] for i,v in enumerate(observed))]
        assert posterior
        actions={}
        for i,v in enumerate(observed):
            if v is not None:continue
            buckets={}
            for w in posterior:buckets[w[i]]=buckets.get(w[i],0)+1
            cost=Q(1)
            for x,n in buckets.items():
                updated=list(observed);updated[i]=x
                cost+=Q(n,len(posterior))*value(tuple(updated))
            actions[i]=cost
        assert actions
        result=min(actions.values())
        if sum(v is not None for v in observed)<=1:
            first[observed]={'posterior':len(posterior),'value':str(result),'actions':{str(i):str(v) for i,v in actions.items()}}
        return result
    V=value(tuple(root))
    output={'M':M,'left_offsets':list(left),'right_offsets':list(right),'worlds':len(inputs),
            'optimal_expected_vertex_queries':str(V),'above_old_half_residual':V>Q(k+2,2),
            'old_half_residual_queries':str(Q(k+2,2)),'states_cached':value.cache_info().currsize,
            'root_actions':first[tuple(root)]['actions']}
    if retain_first:
        output['first_states']=[{'observed':list(obs),**r} for obs,r in sorted(first.items(),key=lambda x:str(x[0])) if sum(v is not None for v in obs)==1]
    return output

def main():
    started=time.monotonic()
    results=[]
    for M in (1,2,3,4,8,16,32):
        r=game(M);results.append(r)
        print(json.dumps({k:r[k] for k in ('M','worlds','optimal_expected_vertex_queries','root_actions','states_cached')}),flush=True)
    out={'status':'EXACT_FINITE_GAME_ENUMERATION_COMPLETE','date':'2026-10-23',
         'scope':['Native exact rational finite prior; not an asymptotic proof or physical experiment.',
                  'Stopping must exhibit observed L<R; prior positivity is not a public Boolean promise.',
                  'Root action choices include all five vertices and all numeric value information.'],
         'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
         'results':results,'elapsed_seconds':time.monotonic()-started}
    Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({'status':out['status'],'elapsed_seconds':out['elapsed_seconds']}))

if __name__=='__main__':main()
