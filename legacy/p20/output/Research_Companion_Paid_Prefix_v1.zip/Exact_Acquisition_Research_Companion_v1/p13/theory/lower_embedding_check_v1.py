#!/usr/bin/env python3
"""Own exact finite checks of the fixed common-prefix lower embedding."""
import hashlib
import itertools
import json
from fractions import Fraction as F
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CASES = [(m, n) for m in range(1, 4) for n in range(m, 6) if m+n <= 6]
NS = (2, 3, 7)
THRESHOLD_SETS = ("consecutive", "powers_two")


def phi(z, N):
    return (F(3, 5)+z/(5*(z+1)))/N


def rows(side, t, N):
    if side == "L":
        return ((F(0), F(1)),)+((F(0), F(0)),)*(N-2)+((F(0), N*t-F(1, 2)),)
    f = F(1, 2*N)
    return ((F(3*N, 2), F(0)),)+((F(0), F(0)),)*(N-2)+((N*(f/t-F(1, 2)), F(0)),)


def check_world(N, m, n, thresholds):
    k = m+n
    f = F(1, 2*N)
    archives = [rows("L" if i < m else "R", t, N) for i, t in enumerate(thresholds)]
    for i, archive in enumerate(archives):
        assert len(archive) == N
        assert all(c >= 0 and 0 <= e <= 1 for c, e in archive)
        c = sum(x[0] for x in archive)/N
        e = sum(x[1] for x in archive)/N
        if i < m:
            assert (c, e) == (0, f+thresholds[i])
            assert sum(x[1] for x in archive[:1])/N > f
        else:
            assert (c, e) == (1+f/thresholds[i], 0)
            assert sum(x[0] for x in archive[:1])/N > 1
        assert (c < 1 and e > f) or (c > 1 and e < f)
        assert all(row == (0, 0) for row in archive[1:-1])
    edges = [(i, j) for i in range(m) for j in range(m, k)
             if thresholds[i] < thresholds[j]]
    assert len(edges) == 1
    H = N+k
    assert H+2*(N-1) == 3*N+k-2
    noedge_subsets = 0
    for mask in range(1 << k):
        observed = [i for i in range(k) if mask & (1 << i)]
        if any(i in observed and j in observed for i, j in edges):
            continue
        noedge_subsets += 1
        # Direct compatible FALSE completion inside the same bounded open
        # threshold interval, preserving every observed tail and common row.
        lo, hi = F(3, 5*N), F(4, 5*N)
        left_observed = [thresholds[i] for i in observed if i < m]
        right_observed = [thresholds[i] for i in observed if i >= m]
        lower = max([lo]+right_observed)
        upper = min([hi]+left_observed)
        assert lower < upper
        cut = (lower+upper)/2
        completed = [thresholds[i] if i in observed else
                     ((cut+hi)/2 if i < m else (lo+cut)/2)
                     for i in range(k)]
        assert all(lo < t < hi for t in completed)
        assert not any(completed[i] < completed[j]
                       for i in range(m) for j in range(m, k))
        # A nonnegative weighted sum explicitly supports the candidate:
        # lambda=(s,1), max_R(v)<=s<=min_L(u).
        s = (max(completed[m:])+min(completed[:m]))/2
        assert all(t >= s for t in completed[:m])
        assert all(t <= s for t in completed[m:])
        for i in range(k):
            amended = rows("L" if i < m else "R", completed[i], N)
            assert amended[0] == archives[i][0]
            assert amended[1:-1] == archives[i][1:-1]
            if i in observed:
                assert amended == archives[i]
            assert all(c >= 0 and 0 <= e <= 1 for c, e in amended)
    return noedge_subsets


def main():
    reports = []
    for N in NS:
        for m, n in CASES:
            k = m+n
            for name in THRESHOLD_SETS:
                zs = tuple(F(i+1 if name == "consecutive" else 2**i) for i in range(k))
                ts = tuple(phi(z, N) for z in zs)
                left = (ts[n-1],)+ts[n+1:]
                right = ts[:n-1]+(ts[n],)
                world_count = subset_count = 0
                for l in itertools.permutations(left):
                    for r in itertools.permutations(right):
                        subset_count += check_world(N, m, n, l+r)
                        world_count += 1
                reports.append({"N": N, "m": m, "n": n, "thresholds": name,
                                "worlds_checked": world_count,
                                "noedge_subsets_with_FALSE_completion": subset_count})
    result = {"source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "all_pass": True, "cases": reports,
              "total_worlds": sum(x["worlds_checked"] for x in reports),
              "total_noedge_subsets": sum(x["noedge_subsets_with_FALSE_completion"] for x in reports)}
    (ROOT/"lower_embedding_check_v1.json").write_text(json.dumps(result, indent=2)+"\n")
    print(json.dumps({k: v for k, v in result.items() if k != "cases"}, indent=2))


if __name__ == "__main__":
    main()
