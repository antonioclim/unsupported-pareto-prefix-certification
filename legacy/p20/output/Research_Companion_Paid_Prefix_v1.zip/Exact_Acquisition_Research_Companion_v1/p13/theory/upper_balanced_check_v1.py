#!/usr/bin/env python3
"""Own exact balanced-side scheduling checks; no producer or external imports."""
from fractions import Fraction as Q
from itertools import combinations,permutations,product
from pathlib import Path
import hashlib,json,time
HERE=Path(__file__).resolve().parent
INPUT=HERE/'upper_balanced_fixtures_v1.json'

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def words(m,n):
    for left in combinations(range(m+n),m):
        left=set(left);yield ''.join('L' if i in left else 'R' for i in range(m+n))
def balanced(m,n):
    a=b=0;out=[]
    while a<m or b<n:
        if a<m and (b==n or a<=b):out.append('L');a+=1
        else:out.append('R');b+=1
    return ''.join(out)
def sums(w):
    a=b=SL=SR=0
    for s in w:
        if s=='L':SL+=a*b;a+=1
        else:SR+=a*b;b+=1
    return SL,SR
def delta(m,n):
    m,n=sorted((m,n));return Q(m)+Q(n-3,2)-Q(m*m-1,6*n)
def global_delta(K):return Q(4*K-13,6)+(Q(1,3*(K-1)) if K%2 else Q())
def schedule(w,L,R):
    a=b=0;order=[]
    for side in w:
        if side=='L':order.append(L[a]);a+=1
        else:order.append(R[b]);b+=1
    return order

def main():
    start=time.monotonic();f=json.loads(INPUT.read_text());inputhash=sha(INPUT);codehash=sha(Path(__file__))
    wordcount=partitions=0
    for q in f['exhaustive_word_total_sizes']:
        for m in range(1,q//2+1):
            n=q-m;w=balanced(m,n);best=sum(sums(w));expected=Q(m*n*(n-1),2)+Q(m**3-m,6)
            assert best==expected
            scores=[]
            for other in words(m,n):
                score=sum(sums(other));scores.append(score);assert score<=best
                a=b=0;survival=Q()
                for side in other:
                    survival+=1-Q(a*b,m*n)
                    if side=='L':a+=1
                    else:b+=1
                assert survival==Q(q)-Q(score,m*n);wordcount+=1
            assert best==max(scores) and Q(q-2)-Q(best,m*n)==delta(m,n);partitions+=1
    labelled=0;inclusions=0;labelcases=[]
    for m,n in f['labelled_side_counts']:
        w=balanced(m,n);SL,SR=sums(w);orders=[schedule(w,L,R) for L in permutations(range(m)) for R in permutations(range(m,m+n))]
        W={0,m};counts={i:0 for i in range(m+n) if i not in W};costsum=0
        for order in orders:
            stop=max(order.index(i) for i in W)+1;costsum+=stop
            for i in counts:counts[i]+=i in order[:stop]
            labelled+=1
        for i,count in counts.items():
            v=Q(count,len(orders));formula=1-Q(SL,m*(m-1)*n) if i<m else 1-Q(SR,n*(n-1)*m)
            assert v==formula;inclusions+=1
        E=Q(costsum,len(orders));assert E==2+delta(m,n)
        labelcases.append({'m':m,'n':n,'word':w,'orders':len(orders),'exact_expected_queries':str(E),'delta':str(delta(m,n)),'inclusion':{str(i):str(Q(c,len(orders))) for i,c in counts.items()}})
    hstates=horders=knownsaved=0
    for m,n in f['weighted_h_side_counts']:
        w=balanced(m,n);orders=[schedule(w,L,R) for L in permutations(range(m)) for R in permutations(range(m,m+n))]
        SL,SR=sums(w);pL=1-Q(SL,m*(m-1)*n);pR=1-Q(SR,n*(n-1)*m)
        for N in f['weighted_h_N_values']:
            D=m+n+1+3*N-3
            for hs in product(range(1,N+1),repeat=m+n):
                rs=[N-h for h in hs];H=N+sum(hs)
                for a in range(m):
                    for b in range(m,m+n):
                        W={a,b};C=H+sum(rs[i] for i in W);total=0
                        for order in orders:
                            available={i for i,r in enumerate(rs) if r==0};cost=H
                            if not W<=available:
                                for i in order:
                                    if i in available:continue
                                    available.add(i);cost+=rs[i]
                                    if W<=available:break
                            total+=cost;horders+=1
                        E=Q(total,len(orders));weighted=C+pL*sum(rs[i] for i in range(m) if i not in W)+pR*sum(rs[i] for i in range(m,m+n) if i not in W)
                        assert E<=weighted<=C+delta(m,n)*(N-1)
                        assert E/C<=1+delta(m,n)*Q(N-1,D)
                        if any(rs[i]==0 for i in W) and E<weighted:knownsaved+=1
                        hstates+=1
    globalcases=[]
    lo,hi=f['global_K_range']
    for K in range(lo,hi+1):
        q=K-1;d=global_delta(K);vals=[delta(m,q-m) for m in range(1,q//2+1)]
        assert d==max(vals)
        if K>=5:
            old=(K-3)*(Q(2,3)-Q(1,12*(K-3)));assert d==old if K==5 else d<old
        for N in f['global_N_values']:
            ratio=1+d*Q(N-1,K+3*N-3)
            if K==3:assert ratio==1
            if K==4:assert ratio==Q(7*N+1,6*N+2)
            if K==5:assert ratio==Q(17*N+3,12*N+8)
            if N==1:assert ratio==1
        if K in [3,4,5,6,7,8,16,36,80]:globalcases.append({'K':K,'delta':str(d),'N6_ratio_upper':str(1+d*Q(5,K+15))})
    ps=[]
    for w in words(2,3):
        SL,SR=sums(w);ps.append((Q(SL,6),Q(SR,12),w))
    best=max(min(a,b) for a,b,w in ps)
    for i,(a,b,w) in enumerate(ps):
        for c,d,z in ps[i+1:]:
            denominator=(a-b)-(c-d)
            if denominator:
                lam=(d-c)/denominator
                if 0<=lam<=1:best=max(best,lam*a+(1-lam)*c)
    assert best==Q(3,8)
    assert Q(3,4)*Q(1,3)+Q(1,4)*Q(1,2)==Q(3,8)
    assert Q(3,4)*Q(5,12)+Q(1,4)*Q(1,4)==Q(3,8)
    assert sha(INPUT)==inputhash and sha(Path(__file__))==codehash
    result={'status':'PASS_EXACT_COUNT_BALANCED_UPPER_CHECKS','input_sha256':inputhash,'source_sha256':codehash,'exhaustive_side_partitions':partitions,'exhaustive_side_words':wordcount,'labelled_schedule_outcomes':labelled,'nonwitness_inclusion_checks':inclusions,'weighted_h_and_witness_states':hstates,'weighted_labelled_order_outcomes':horders,'known_witness_strict_savings_states':knownsaved,'labelled_cases':labelcases,'global_K_count':hi-lo+1,'global_examples':globalcases,'side23_best_static_max_inclusion':'5/8','elapsed_seconds':time.monotonic()-start,'scope':['Exact own mathematical fixtures only','No producer module or external code imported','No Monte Carlo, physical measurement or historical-priority claim','This file proves/checks an upper bound; static schedule optimum is not a general adaptive lower bound']}
    (HERE/'upper_balanced_results_v1.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ['status','exhaustive_side_partitions','exhaustive_side_words','labelled_schedule_outcomes','weighted_h_and_witness_states','weighted_labelled_order_outcomes','known_witness_strict_savings_states','elapsed_seconds']},indent=2))

if __name__=='__main__':main()
