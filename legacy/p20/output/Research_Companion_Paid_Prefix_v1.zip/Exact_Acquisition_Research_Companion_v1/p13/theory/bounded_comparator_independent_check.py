#!/usr/bin/env python3
"""Independent exhaustive bounded-prefix fixture audit; no producer imports.

Uses closed scalarisation intervals rather than convex-mixture code. This is
an exact finite audit, not the proof of the all-input comparator identity.
"""
from fractions import Fraction as Q
from itertools import product
from pathlib import Path
import hashlib,json,time

HERE=Path(__file__).resolve().parent
INPUT=HERE/'bounded_comparator_independent_fixtures_v1.json'
OUTPUT=HERE/'bounded_comparator_independent_check.json'

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def dominates(x,y):
    return all(a<=b for a,b in zip(x,y)) and any(a<b for a,b in zip(x,y))

def supporting_interval(candidate,competitors):
    low,high=Q(0),Q(1)
    for point in competitors:
        dx,dy=(point[j]-candidate[j] for j in range(2))
        slope=dx-dy
        if slope==0:
            if dy<0:return None
        elif slope>0:low=max(low,-dy/slope)
        else:high=min(high,-dy/slope)
        if low>high:return None
    return [low,high]

def corners(rows,counts,B):
    output=[]
    for group,n in zip(rows,counts):
        N=len(group);s=[sum((r[j] for r in group[:n]),Q(0)) for j in range(2)]
        output.append((tuple(v/N for v in s),((s[0]+(N-n)*B)/N,(s[1]+N-n)/N)))
    return output

def force_true(rows,target,counts,B):
    bs=corners(rows,counts,B);la,ua=bs[target]
    others=[i for i in range(len(rows)) if i!=target]
    if any(dominates(bs[i][0],ua) for i in others):return False
    return supporting_interval(la,[bs[i][1] for i in others]) is None

def exhaustive(rows,target,B):
    true=[];states=0
    for counts in product(*(range(len(g)+1) for g in rows)):
        states+=1
        if force_true(rows,target,counts,B):true.append(list(counts))
    cost=min((sum(v) for v in true),default=None)
    return {'states':states,'TRUE_states':len(true),'minimum':cost,
            'minimizers':[v for v in true if sum(v)==cost]}

def main():
    start=time.monotonic();data=json.loads(INPUT.read_text());frozen=sha(INPUT)
    records=[]
    for case in data['cases']:
        rows=[[tuple(Q(v) for v in r) for r in g] for g in case['rows']]
        B=Q(case['B']);assert B>0
        assert all(0<=x<=B and 0<=y<=1 for g in rows for x,y in g)
        report=exhaustive(rows,case['target'],B)
        assert report['minimum']==case['expected_minimum'],(case['id'],report)
        if 'expected_minimizers' in case:assert report['minimizers']==case['expected_minimizers'],(case['id'],report)
        records.append({'id':case['id'],**report})
    # Exhaust all N=1 three-point catalogues on a 4x4 rational coordinate grid.
    # All groups are necessarily observed at any positive state in this case;
    # the scalar test still includes zero coordinates, ties and duplicates.
    vals=[Q(0),Q(1,2),Q(3,4),Q(1)]
    points=list(product(vals,repeat=2));n1positive=0;n1states=0
    for catalogue in product(points,repeat=3):
        rows=[[p] for p in catalogue]
        actual=not any(dominates(p,catalogue[0]) for p in catalogue[1:]) and supporting_interval(catalogue[0],catalogue[1:]) is None
        report=exhaustive(rows,0,Q(1));n1states+=report['states']
        assert report['minimum']==(3 if actual else None)
        if actual:
            n1positive+=1;assert report['minimizers']==[[1,1,1]]
    assert sha(INPUT)==frozen
    result={'status':'PASS_INDEPENDENT_EXHAUSTIVE_BOUNDED_PREFIX_FIXTURES',
      'input_sha256':frozen,'source_sha256':sha(Path(__file__)),
      'targeted_cases':len(records),'targeted_prefix_states':sum(r['states'] for r in records),
      'targeted_results':records,'N1_catalogues':len(points)**3,
      'N1_prefix_states':n1states,'N1_positive_catalogues':n1positive,
      'scope':['Own standard-library Fraction code; no producer or external imports.',
       'Closed support intervals independently preserve axes and ties.',
       'Exhaustive states only for stated fixtures and finite N1 grid; universal proof separate.',
       'Minimum is a hindsight TRUE certificate, not online discovery or physical cost.'],
      'elapsed_seconds':time.monotonic()-start}
    OUTPUT.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ('status','targeted_cases','targeted_prefix_states','N1_catalogues','N1_prefix_states','N1_positive_catalogues','elapsed_seconds')}))

if __name__=='__main__':main()
