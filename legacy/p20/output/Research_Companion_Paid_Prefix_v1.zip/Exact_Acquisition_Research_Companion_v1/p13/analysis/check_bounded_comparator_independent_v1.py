#!/usr/bin/env python3
"""Independent exhaustive verification; NEVER imports the new producer.

The previously frozen oracle uses closed scalarisation-support intervals.
This runner reads producer JSON only and checks both costs and certificates.
"""
from fractions import Fraction as Q
from pathlib import Path
import hashlib
import importlib.util
import json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
INPUT = HERE / 'bounded_comparator_fixtures_v1.json'
FREEZE = HERE / 'bounded_comparator_FREEZE_v1.json'
PRODUCED = HERE / 'bounded_comparator_results_v1.json'
OUTPUT = HERE / 'bounded_comparator_check_v1.json'
ORACLE = HERE.parent / 'theory/bounded_comparator_independent_check.py'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def frozen():
    data = json.loads(FREEZE.read_text())
    for name, digest in data['sha256'].items():
        assert sha(ROOT/name) == digest, name
    return data


def main():
    manifest = frozen()
    spec = importlib.util.spec_from_file_location('independent_closed_intervals', ORACLE)
    oracle = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(oracle)
    inputs = json.loads(INPUT.read_text())['cases']
    produced = json.loads(PRODUCED.read_text())
    assert produced['source_sha256'] == manifest['sha256'][
        'p13/analysis/bounded_comparator_v1.py']
    assert produced['input_sha256'] == sha(INPUT)
    assert produced['freeze_sha256'] == sha(FREEZE)
    assert len(inputs) == len(produced['results'])
    checked = []
    for case, report in zip(inputs, produced['results']):
        assert case['id'] == report['id']
        rows = [[tuple(Q(v) for v in r) for r in g] for g in case['rows']]
        target, B = case['target'], Q(case['B'])
        truth = oracle.exhaustive(rows, target, B)
        if 'expected_minimum' in case:
            assert truth['minimum'] == case['expected_minimum'], case['id']
            assert truth['minimizers'] == case['expected_minimizers'], case['id']
        for method in ('dense', 'staircase'):
            actual = report[method]
            assert actual['minimum'] == truth['minimum'], (case['id'], method)
            assert actual['minimizers'] == truth['minimizers'], (case['id'], method)
            assert [c['prefixes'] for c in actual['certificates']] == truth['minimizers']
            for cert in actual['certificates']:
                vector = cert['prefixes']
                boxes = oracle.corners(rows, vector, B)
                assert oracle.force_true(rows, target, vector, B)
                assert sum(vector) == cert['cost'] == truth['minimum']
                ga, gb = cert['pair_groups']
                assert ga != gb and target not in (ga, gb)
                weight = Q(cert['lambda_first'])
                assert 0 < weight < 1
                p, u, v = boxes[target][0], boxes[ga][1], boxes[gb][1]
                assert list(map(Q, cert['candidate_lower'])) == list(p)
                assert list(map(Q, cert['first_upper'])) == list(u)
                assert list(map(Q, cert['second_upper'])) == list(v)
                mixture = [weight*u[d]+(1-weight)*v[d] for d in range(2)]
                assert mixture == list(map(Q, cert['strict_mixture']))
                assert all(mixture[d] < p[d] for d in range(2))
                # Also independently certify the reported h thresholds,
                # including equality being safe and h=0 being legal.
                base = cert['P2_minimum_prefixes']
                assert base[target] == vector[target]
                for g in range(len(rows)):
                    if g == target:
                        continue
                    found = None
                    for n in range(len(rows[g])+1):
                        trial = list(vector)
                        trial[g] = n
                        low = oracle.corners(rows, trial, B)[g][0]
                        if not oracle.dominates(low, boxes[target][1]):
                            found = n
                            break
                    assert base[g] == found
                    assert vector[g] >= base[g]
                    if g not in (ga, gb):
                        assert vector[g] == base[g]
        checked.append({'id': case['id'], **truth,
            'dense_strict_mixture_calls': report['dense']['work_counts'][
                'strict_mixture_evaluations'],
            'staircase_strict_mixture_calls': report['staircase']['work_counts'][
                'strict_mixture_evaluations']})
    frozen()
    result = {
        'status': 'PASS_INDEPENDENT_EXHAUSTIVE_DENSE_AND_STAIRCASE',
        'schema': 'bounded-comparator-independent-check-v1',
        'input_sha256': sha(INPUT), 'producer_result_sha256': sha(PRODUCED),
        'verifier_source_sha256': sha(Path(__file__)),
        'oracle_source_sha256': sha(ORACLE), 'freeze_sha256': sha(FREEZE),
        'case_count': len(checked),
        'prefix_states': sum(r['states'] for r in checked),
        'results': checked,
        'scope': [
            'Independent exhaustive all-prefix verification for stated finite fixtures.',
            'Oracle uses closed scalarisation intervals, not mixture feasibility.',
            'Verifier imports no producer code; producer output is read as data.',
            'Every emitted optimum and rational mixture certificate was checked.',
            'Files frozen before execution remained unchanged.',
            'Universal correctness rests on the separate proof, not finite tests.']}
    OUTPUT.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({'status': result['status'], 'cases': result['case_count'],
                      'prefix_states': result['prefix_states'],
                      'new_case_results': checked[-3:]}, separators=(',', ':')))


if __name__ == '__main__':
    main()
