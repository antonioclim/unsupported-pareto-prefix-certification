#!/usr/bin/env python3
"""Own exact bounded TRUE-certificate producers; no oracle imports.

Dense pair grids and genuine monotone staircases implement the same proven
pair-plus-P2-threshold identity. Inputs are complete archived row tables;
this is a hindsight certificate comparator, not an acquisition policy.
"""
from fractions import Fraction as Q
from itertools import combinations
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
INPUT = HERE / 'bounded_comparator_fixtures_v1.json'
FREEZE = HERE / 'bounded_comparator_FREEZE_v1.json'
OUTPUT = HERE / 'bounded_comparator_results_v1.json'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check_freeze():
    manifest = json.loads(FREEZE.read_text())
    for name, digest in manifest['sha256'].items():
        assert sha(ROOT / name) == digest, ('frozen-file-changed', name)
    return manifest


def strict_mixture(u, v, p):
    """Return rational lambda with lambda*u+(1-lambda)*v < p, or None.

    This uses direct strict mixture inequalities, independently of the
    checker, which intersects closed scalarisation-support intervals.
    """
    low, high = Q(0), Q(1)
    for coordinate in range(2):
        intercept = v[coordinate] - p[coordinate]
        slope = u[coordinate] - v[coordinate]
        if slope == 0:
            if intercept >= 0:
                return None
        elif slope > 0:
            high = min(high, -intercept / slope)
        else:
            low = max(low, -intercept / slope)
        if low >= high:
            return None
    weight = (low + high) / 2
    assert 0 < weight < 1
    assert all(weight*u[d]+(1-weight)*v[d] < p[d] for d in range(2))
    return weight


def make_prefixes(rows, B):
    """Cumulative sums, with a separate known denominator for every group."""
    arrays = []
    for group in rows:
        N = len(group)
        assert N > 0
        sx, sy = Q(0), Q(0)
        lower, upper = [], []
        for n in range(N + 1):
            lower.append((sx/N, sy/N))
            upper.append(((sx+(N-n)*B)/N, (sy+N-n)/N))
            if n < N:
                x, y = group[n]
                assert 0 <= x <= B and 0 <= y <= 1
                sx += x
                sy += y
        arrays.append((lower, upper))
    return arrays


def safe_lower(lower, candidate_upper):
    # A point is safe iff it is strictly worse in at least one coordinate,
    # or exactly equal in BOTH. One equality plus one improvement is unsafe.
    return lower == candidate_upper or any(lower[d] > candidate_upper[d]
                                           for d in range(2))


def solve(rows, target, B, method):
    assert B > 0
    assert method in ('dense', 'staircase')
    assert 0 <= target < len(rows)
    boxes = make_prefixes(rows, B)
    competitors = [g for g in range(len(rows)) if g != target]
    sizes = [len(g) for g in rows]
    best, records = None, []
    counts = {'P2_safety_evaluations': 0, 'strict_mixture_evaluations': 0,
              'candidate_prefixes': sizes[target]+1,
              'P2_feasible_candidate_prefixes': 0, 'pair_sweeps': 0}

    def predicate(ga, na, gb, nb, p):
        counts['strict_mixture_evaluations'] += 1
        return strict_mixture(boxes[ga][1][na], boxes[gb][1][nb], p)

    def consider(cost, base, ga, na, gb, nb, weight):
        nonlocal best, records
        if weight is None or (best is not None and cost > best):
            return
        # Compact descriptors only. Prefix-vector/witness expansion happens
        # after the core sweep and is output-sensitive diagnostic work.
        descriptor = (base, ga, na, gb, nb, weight)
        if best is None or cost < best:
            best, records = cost, [descriptor]
        else:
            records.append(descriptor)

    for candidate_n in range(sizes[target]+1):
        p = boxes[target][0][candidate_n]
        candidate_upper = boxes[target][1][candidate_n]
        h = [0] * len(rows)
        h[target] = candidate_n
        feasible = True
        for group in competitors:
            first = None
            for n, low in enumerate(boxes[group][0]):
                counts['P2_safety_evaluations'] += 1
                if safe_lower(low, candidate_upper):
                    first = n
                    break
            if first is None:
                feasible = False
                break
            h[group] = first
        if not feasible:
            continue
        counts['P2_feasible_candidate_prefixes'] += 1
        base, base_cost = tuple(h), sum(h)
        for ga, gb in combinations(competitors, 2):
            counts['pair_sweeps'] += 1
            if method == 'dense':
                for na in range(h[ga], sizes[ga]+1):
                    for nb in range(h[gb], sizes[gb]+1):
                        weight = predicate(ga, na, gb, nb, p)
                        consider(base_cost+na-h[ga]+nb-h[gb],
                                 base, ga, na, gb, nb, weight)
            else:
                nb = sizes[gb]
                for na in range(h[ga], sizes[ga]+1):
                    # If the current maximum is initially FALSE, the lower
                    # cell is FALSE too. Retaining nb still allows a later
                    # na to become feasible. No dense-grid fallback exists.
                    while nb > h[gb]:
                        previous = predicate(ga, na, gb, nb-1, p)
                        if previous is None:
                            break
                        nb -= 1
                    weight = predicate(ga, na, gb, nb, p)
                    consider(base_cost+na-h[ga]+nb-h[gb],
                             base, ga, na, gb, nb, weight)

    # Optional all-minimizer diagnostics. For each fixed first prefix, only
    # the smallest feasible second prefix can be globally optimal, so the
    # staircase already retained every optimum. No grid revisit is needed.
    certificates = {}
    for base, ga, na, gb, nb, weight in records:
        vector = list(base)
        vector[ga], vector[gb] = na, nb
        key = tuple(vector)
        if key in certificates:
            continue
        p = boxes[target][0][vector[target]]
        u, v = boxes[ga][1][na], boxes[gb][1][nb]
        mixed = [weight*u[d]+(1-weight)*v[d] for d in range(2)]
        certificates[key] = {
            'prefixes': vector, 'cost': sum(vector),
            'P2_minimum_prefixes': list(base), 'pair_groups': [ga, gb],
            'lambda_first': str(weight), 'candidate_lower': list(map(str, p)),
            'first_upper': list(map(str, u)), 'second_upper': list(map(str, v)),
            'strict_mixture': list(map(str, mixed))}
    ordered = sorted(certificates)
    return {'minimum': best, 'minimizers': [list(v) for v in ordered],
            'certificates': [certificates[v] for v in ordered],
            'work_counts': counts,
            'diagnostic_minimizer_count': len(ordered)}


def main():
    check_freeze()
    cases = json.loads(INPUT.read_text())['cases']
    reports = []
    for case in cases:
        rows = [[tuple(Q(v) for v in row) for row in group]
                for group in case['rows']]
        B = Q(case['B'])
        dense = solve(rows, case['target'], B, 'dense')
        staircase = solve(rows, case['target'], B, 'staircase')
        assert (dense['minimum'], dense['minimizers']) == (
            staircase['minimum'], staircase['minimizers']), case['id']
        reports.append({'id': case['id'], 'group_sizes': list(map(len, rows)),
                        'dense': dense, 'staircase': staircase})
    check_freeze()
    result = {
        'status': 'PASS_DENSE_STAIRCASE_AGREEMENT',
        'schema': 'bounded-comparator-results-v1',
        'source_sha256': sha(Path(__file__)), 'input_sha256': sha(INPUT),
        'freeze_sha256': sha(FREEZE), 'case_count': len(reports),
        'scope': [
            'Native exact rational producer; no oracle/external imports.',
            'Known B and independent continuous row completion domains.',
            'Fixed complete tables; hindsight TRUE certificate costs only.',
            'Staircase has no dense-grid or all-prefix fallback.',
            'Core common-N minimum/one-certificate arithmetic bound O(K^2 N^2).',
            'All-minimizer diagnostics require additional output-sensitive work/storage.',
            'Predicate counts are deterministic work counts, not performance claims.',
            'No physical, statistical, historical-priority or online-optimality claim.'],
        'results': reports}
    OUTPUT.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({'status': result['status'], 'cases': len(reports),
                      'results': [{'id': r['id'],
                          'minimum': r['staircase']['minimum'],
                          'minimizers': r['staircase']['minimizers']}
                          for r in reports]}, separators=(',', ':')))


if __name__ == '__main__':
    main()
