#!/usr/bin/env python3
"""Supplemental exhaustive finite grid: native producers vs independent oracle.

Protocol frozen in this source: N=1, K=1,2,3, target0, B=1; all ordered
catalogues on {0,1/2,3/4,1}^2. No random data or expected positive counts.
"""
from fractions import Fraction as Q
from itertools import product
from pathlib import Path
import hashlib
import importlib.util
import json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
FREEZE = HERE / 'bounded_comparator_grid_FREEZE_v1.json'
OUTPUT = HERE / 'bounded_comparator_grid_check_v1.json'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check_freeze():
    data = json.loads(FREEZE.read_text())
    for name, digest in data['sha256'].items():
        assert sha(ROOT/name) == digest, name


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def main():
    check_freeze()
    producer = module('native_pair_producer', HERE/'bounded_comparator_v1.py')
    oracle = module('independent_interval_oracle',
        HERE.parent/'theory/bounded_comparator_independent_check.py')
    values = [Q(0), Q(1,2), Q(3,4), Q(1)]
    points = list(product(values, repeat=2))
    records = []
    for K in (1, 2, 3):
        catalogues = states = positives = dense_calls = stair_calls = 0
        for catalogue in product(points, repeat=K):
            rows = [[p] for p in catalogue]
            truth = oracle.exhaustive(rows, 0, Q(1))
            catalogues += 1
            states += truth['states']
            positives += truth['minimum'] is not None
            for method in ('dense', 'staircase'):
                result = producer.solve(rows, 0, Q(1), method)
                assert result['minimum'] == truth['minimum'], (catalogue, method)
                assert result['minimizers'] == truth['minimizers'], (catalogue, method)
                calls = result['work_counts']['strict_mixture_evaluations']
                if method == 'dense':
                    dense_calls += calls
                else:
                    stair_calls += calls
        records.append({'K': K, 'N': 1, 'catalogues': catalogues,
            'prefix_states': states, 'positive_catalogues': positives,
            'dense_strict_mixture_calls': dense_calls,
            'staircase_strict_mixture_calls': stair_calls})
    check_freeze()
    report = {'status': 'PASS_EXHAUSTIVE_FINITE_GRID_BOTH_PRODUCERS',
        'grid': list(map(str, values)), 'target': 0, 'B': '1',
        'catalogues': sum(r['catalogues'] for r in records),
        'prefix_states': sum(r['prefix_states'] for r in records),
        'freeze_sha256': sha(FREEZE), 'source_sha256': sha(Path(__file__)),
        'results': records,
        'scope': 'Finite implementation evidence only; universal proof separate.'}
    OUTPUT.write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(report, separators=(',', ':')))


if __name__ == '__main__':
    main()
